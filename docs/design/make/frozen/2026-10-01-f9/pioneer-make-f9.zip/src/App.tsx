import { useCallback, useEffect, useLayoutEffect, useRef, useState } from 'react'
import { DEFAULT_WORKSPACES, type Session, type Workspace, newSession, seedSessions } from './pioneer/data'
import { isActive, reduce, speed, type Action } from './pioneer/flow'
import SessionView from './pioneer/Session'
import Library from './pioneer/Library'
import PetHost from './pioneer/Pet'
import Notes from './pioneer/Notes'
import Settings from './pioneer/Settings'
import { DEFAULT_PREFS, corrupt, load, resetProto, save, type Prefs } from './pioneer/store'
import { DemoControls, Palette, QuitDialog, QuitScreen, Shortcuts, StatusBar, Taskbar, TitleBar, type Demo, type Preset, type Win } from './pioneer/Shell'
import { Button, Icon } from './pioneer/ui'

type Toast = { id: number; text: string; undo?: () => void }
const TICK = { slow: 2200, normal: 1300, fast: 600 }

export default function App() {
  const boot = useRef(load()).current
  const d = boot.data
  const restoreTabs = d?.prefs.restoreTabs ?? true
  const [sessions, setSessions] = useState<Session[]>(d?.sessions ?? seedSessions())
  const [workspaces, setWorkspaces] = useState<Workspace[]>(d?.workspaces ?? DEFAULT_WORKSPACES)
  const [openIds, setOpenIds] = useState<string[]>(d ? (restoreTabs ? d.openIds : []) : ['s-live', 's-tiles', 's-recon'])
  const [active, setActive] = useState<string>(d && restoreTabs ? d.active : 'home')
  const [closed, setClosed] = useState<string[]>(d?.closed ?? [])
  const [grants, setGrants] = useState<Record<string, string[]>>(d?.grants ?? {})
  const [prefs, setPrefsState] = useState<Prefs>(d?.prefs ?? DEFAULT_PREFS)
  const [firstUse, setFirstUse] = useState(d?.firstUse ?? false)
  const [corruptBanner, setCorruptBanner] = useState(boot.status === 'corrupt')

  const [win, setWin] = useState<Win>('normal')
  const [focused, setFocused] = useState(true)
  const [preset, setPreset] = useState<Preset>('wide')
  const [toasts, setToasts] = useState<Toast[]>([])
  const [overlay, setOverlay] = useState<null | 'palette' | 'keys' | 'notes' | 'quit' | 'settings'>(null)
  const [settingsTab, setSettingsTab] = useState<'look' | 'data'>('look')
  const [tray, setTray] = useState(false)
  const [typing, setTyping] = useState(false)
  const [demo, setDemoState] = useState<Demo>({ failRun: false, failVerify: false, saveFail: false })
  const [demoOpen, setDemoOpen] = useState(false)
  const [connected, setConnected] = useState(true)
  const [saveState, setSaveState] = useState<'ok' | 'error' | 'pending'>('ok')
  const [stopArmed, setStopArmed] = useState(false)
  const composerRef = useRef<HTMLTextAreaElement>(null)
  const winRef = useRef<HTMLDivElement>(null)
  const [size, setSize] = useState({ w: 1200, h: 800 })
  const setDemo = (p: Partial<Demo>) => setDemoState(x => ({ ...x, ...p }))
  const setPrefs = (p: Partial<Prefs>) => setPrefsState(x => ({ ...x, ...p }))
  speed.k = prefs.speed === 'fast' ? 0.5 : prefs.speed === 'slow' ? 1.6 : 1

  /* ───── persistence ───── */
  const snapshot = () => ({ v: 5 as const, sessions, workspaces, openIds, active, closed, grants, prefs, firstUse })
  const snapRef = useRef(snapshot); snapRef.current = snapshot
  const doSave = useCallback(() => setSaveState(save(snapRef.current(), demo.saveFail) ? 'ok' : 'error'), [demo.saveFail])
  useEffect(() => {
    setSaveState(s => (s === 'error' ? s : 'pending'))
    const t = setTimeout(doSave, 400)
    return () => clearTimeout(t)
  }, [sessions, workspaces, openIds, active, closed, grants, prefs, firstUse, doSave])

  useLayoutEffect(() => {
    const el = winRef.current
    if (!el) return
    const ro = new ResizeObserver(([e]) => setSize({ w: e.contentRect.width, h: e.contentRect.height }))
    ro.observe(el)
    return () => ro.disconnect()
  }, [win])
  const narrow = size.w < 900
  const short = size.h < 620

  const toast = useCallback((text: string, undo?: () => void) => {
    const id = Date.now() + Math.random()
    setToasts(t => [...t.slice(-2), { id, text, undo }])
    setTimeout(() => setToasts(t => t.filter(x => x.id !== id)), 6000)
  }, [])

  const act = useCallback((id: string, a: Action) => setSessions(ss => ss.map(s => (s.id === id ? reduce(s, a) : s))), [])

  /* ───── simulated executor: runs independently of tabs and windows ───── */
  const demoRef = useRef(demo); demoRef.current = demo
  useEffect(() => {
    if (win === 'quit' || !connected) return
    const t = setInterval(() => {
      const now = Date.now()
      setSessions(ss => ss.map(s => (isActive(s) ? reduce(s, { t: 'tick', failRun: demoRef.current.failRun, failVerify: demoRef.current.failVerify, now }) : s)))
    }, TICK[prefs.speed])
    return () => clearInterval(t)
  }, [win, connected, prefs.speed])
  // injected failures are one-shot
  useEffect(() => {
    if (demo.failRun && sessions.some(s => s.phase === 'failed')) setDemo({ failRun: false })
    if (demo.failVerify && sessions.some(s => s.phase === 'verifyFailed')) setDemo({ failVerify: false })
  }, [sessions])
  // losing the executor connection makes in-flight work "unknown" — never silently continues
  useEffect(() => { if (!connected) setSessions(ss => ss.map(s => reduce(s, { t: 'disconnect' }))) }, [connected])
  useEffect(() => { setStopArmed(false) }, [active])

  const cur = sessions.find(s => s.id === active)
  const curWs = cur && workspaces.find(w => w.id === cur.workspace)
  const running = sessions.filter(isActive)

  const openSession = (id: string) => { setOpenIds(o => (o.includes(id) ? o : [...o, id])); setClosed(c => c.filter(x => x !== id)); setActive(id) }
  const newTask = (ws?: string, text = '') => {
    const w = workspaces.find(x => x.id === ws && !x.unavailable) ?? workspaces.find(x => !x.unavailable)
    if (!w) { setActive('home'); return }
    const s = newSession(text ? text.slice(0, 16) : '新会话', w.id)
    s.draft = text
    setSessions(x => [...x, s]); setOpenIds(o => [...o, s.id]); setActive(s.id)
    setTimeout(() => composerRef.current?.focus(), 40)
  }
  const closeTab = (id: string) => {
    const s = sessions.find(x => x.id === id)
    if (!s) return
    const idx = openIds.indexOf(id)
    const rest = openIds.filter(x => x !== id)
    setOpenIds(rest); setClosed(c => [...c.filter(x => x !== id), id])
    if (active === id) setActive(rest[Math.min(idx, rest.length - 1)] ?? 'home')
    toast(`已关闭「${s.title}」${isActive(s) ? '，任务仍在后台进行' : '，会话保存在工作区'}`, () => openSession(id))
  }
  const reopen = (id = closed[closed.length - 1]) => { if (id) openSession(id) }
  const reorder = (from: string, to: string) => setOpenIds(o => { const a = o.filter(x => x !== from); a.splice(o.indexOf(to), 0, from); return a })
  const moveTab = (dir: -1 | 1) => setOpenIds(o => { const i = o.indexOf(active); const j = i + dir; if (i < 0 || j < 0 || j >= o.length) return o; const a = [...o];[a[i], a[j]] = [a[j], a[i]]; return a })
  const closeWindow = () => { setWin('closed'); setOverlay(null); toast(running.length ? `窗口已关闭。Pioneer 在托盘中，${running.length} 个任务继续进行` : '窗口已关闭。Pioneer 仍在托盘，点任务栏图标可重新打开') }
  const doQuit = () => { setSessions(ss => ss.map(s => reduce(s, { t: 'stop' }))); setOverlay(null); setTray(false); setWin('quit') }
  const askQuit = () => { if (running.length || saveState === 'error') { if (win !== 'normal' && win !== 'maximized' && win !== 'fullscreen') setWin('normal'); setOverlay('quit') } else doQuit() }
  const restore = () => { setWin('normal'); setTray(false); setFocused(true) }
  const setGrant = (perm: string, on: boolean) => cur && setGrants(g => {
    const list = g[cur.workspace] ?? []
    return { ...g, [cur.workspace]: on ? [...new Set([...list, perm])] : list.filter(x => x !== perm) }
  })
  /* ───── demo mode: the simulated desktop, taskbar and test controls exist only when explicitly turned on ───── */
  const demoMode = prefs.demo
  const toggleDemo = () => {
    const on = !prefs.demo
    setPrefs({ demo: on })
    if (!on) { setWin(w => (w === 'fullscreen' ? w : 'normal')); setPreset('wide'); setDemo({ failRun: false, failVerify: false, saveFail: false }) }
    toast(on ? '已进入演示模式：模拟桌面、任务栏与异常注入可用' : '已退出演示模式')
  }
  // window lights simulate OS behaviour; outside demo mode there is no desktop to land on, so they enter demo mode first
  const viaDemo = (f: () => void) => () => { if (!prefs.demo) { setPrefs({ demo: true }); toast('窗口关闭与最小化在演示模式中模拟，已进入演示模式') } f() }
  const togglePet = () => setPrefs({ pet: { ...prefs.pet, state: prefs.pet.state === 'out' ? 'tucked' : 'out' } })

  /* ───── keyboard: Alt-based in the browser to avoid Ctrl+W/N/T/Q conflicts ───── */
  const escAt = useRef(0)
  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if (!['normal', 'maximized', 'fullscreen'].includes(win)) return
      if (e.isComposing) return
      const tag = (e.target as HTMLElement).tagName
      const inField = tag === 'INPUT' || tag === 'TEXTAREA'
      const code = e.code
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); setOverlay(o => (o === 'palette' ? null : 'palette')); return }
      if (e.key === 'F11') { e.preventDefault(); setWin(w => (w === 'fullscreen' ? 'normal' : 'fullscreen')); return }
      if (e.altKey && !e.ctrlKey) {
        const m: Record<string, () => void> = {
          KeyN: () => newTask(cur?.workspace), KeyW: () => cur && closeTab(cur.id), KeyQ: askQuit,
          Digit0: () => setActive('home'),
          Backslash: () => cur && active !== 'home' && window.dispatchEvent(new Event('pioneer:panels')), Slash: () => setOverlay('keys'), Comma: () => setOverlay('settings'),
        }
        if (e.shiftKey && code === 'KeyT') { e.preventDefault(); reopen(); return }
        if (e.shiftKey && code === 'KeyD') { e.preventDefault(); toggleDemo(); return }
        if (e.shiftKey && code === 'ArrowLeft') { e.preventDefault(); moveTab(-1); return }
        if (e.shiftKey && code === 'ArrowRight') { e.preventDefault(); moveTab(1); return }
        if (!e.shiftKey && m[code]) { e.preventDefault(); m[code](); return }
      }
      if (e.key === 'Escape') {
        if (overlay) { setOverlay(null); return }
        if (inField) return
        if (cur?.phase === 'running') {
          // two presses within 1.5 s — a single stray Esc never stops a task
          if (stopArmed && Date.now() - escAt.current < 1500) { act(cur.id, { t: 'stop' }); setStopArmed(false) }
          else { setStopArmed(true); escAt.current = Date.now() }
          return
        }
        if (stopArmed) { setStopArmed(false); return }
        if (win === 'fullscreen') setWin('normal')
      }
    }
    window.addEventListener('keydown', h)
    return () => window.removeEventListener('keydown', h)
  })

  /* ───── pet yielding (host decides; decoration never conveys status) ───── */
  const decision = cur && active !== 'home' && ['permission', 'failed', 'disconnected', 'reconciled', 'verifyFailed'].includes(cur.phase)
  const petReason = decision ? '需要你做决定' : undefined
  const petOnHome = prefs.pet.state === 'out' && active === 'home'

  const dims = !demoMode ? { width: '100%', height: '100%' } : win === 'normal'
    ? preset === 'wide' ? { width: 'min(1320px, calc(100% - 48px))', height: 'min(820px, calc(100% - 40px))' }
      : preset === 'narrow' ? { width: 'min(720px, calc(100% - 48px))', height: 'min(800px, calc(100% - 40px))' }
        : { width: 'min(1120px, calc(100% - 48px))', height: 'min(540px, calc(100% - 40px))' }
    : { width: '100%', height: '100%' }

  const resetAll = () => { resetProto(); location.reload() }
  const visible = ['normal', 'maximized', 'fullscreen'].includes(win)

  return (
    <div className={`h-full flex flex-col overflow-hidden ${prefs.motion === 'off' ? 'motion-off' : ''}`} style={{ background: demoMode ? 'radial-gradient(120% 90% at 20% 0%, #dfe1dc 0%, #c9cbc8 55%, #b9bcba 100%)' : undefined }}>
      <div className="relative flex-1 min-h-0 grid place-items-center" onMouseDown={e => { if (e.target === e.currentTarget) { setFocused(false); setTray(false) } }}>
        {win === 'quit' && <QuitScreen onRelaunch={() => { setWin('normal'); setFocused(true) }} sessions={sessions} />}
        {(win === 'closed' || win === 'minimized') && (
          <div className="text-center text-ink/60 text-[13px] pointer-events-none">
            <div className="font-mono text-[11px] uppercase tracking-wider mb-1">Windows 桌面 · 原型模拟</div>
            {win === 'minimized' ? '窗口已最小化到任务栏' : '窗口已关闭 · 应用仍在托盘运行'}
            {running.length > 0 && <div className="mt-1">{running.length} 个任务在后台进行</div>}
          </div>
        )}
        {demoMode && win === 'normal' && !focused && <div className="absolute top-3 right-4 font-mono text-[10.5px] text-ink/50 pointer-events-none">桌面已获得焦点 · 窗口处于非活动状态</div>}

        {visible && (
          <div ref={winRef} style={dims} onMouseDown={() => setFocused(true)}
            className={`${win === 'fullscreen' ? 'fixed inset-0 z-40' : 'relative'} flex flex-col bg-canvas overflow-hidden transition-[width,height] duration-300 ${win === 'normal' && demoMode ? (focused ? 'rounded-[12px] shadow-[0_0_0_1px_rgba(44,53,71,.14),0_30px_80px_-20px_rgba(37,44,59,.45)]' : 'rounded-[12px] shadow-[0_0_0_1px_rgba(44,53,71,.1),0_12px_30px_-16px_rgba(37,44,59,.3)]') : ''}`}
            role="application" aria-label="Pioneer（原型）">
            <TitleBar win={win} setWin={w => (w === 'minimized' ? viaDemo(() => setWin(w))() : setWin(w))} focused={focused} closeWindow={viaDemo(closeWindow)}
              sessions={sessions} openIds={openIds} active={active} setActive={setActive} closeTab={closeTab}
              reorder={reorder} rename={(id, t) => act(id, { t: 'rename', title: t })}
              closed={closed.map(id => sessions.find(s => s.id === id)).filter(Boolean) as Session[]} reopen={reopen}
              onNew={() => newTask(cur?.workspace)} narrow={narrow} pet={prefs.pet.state} togglePet={togglePet}
              onNotes={() => setOverlay('notes')} onPalette={() => setOverlay('palette')} onSettings={() => { setSettingsTab('look'); setOverlay('settings') }} />

            {corruptBanner && (
              <div role="alert" className="shrink-0 flex flex-wrap items-center gap-2 px-4 py-2 bg-gold-soft border-b border-gold/40 text-[13px]">
                <Icon name="alert" size={14} className="text-gold" />
                <span className="flex-1 min-w-[240px]">本地数据无法读取，已原样备份为 <span className="font-mono text-[12px]">pioneer-proto-v5.corrupt</span>，并载入示例数据。</span>
                <Button size="sm" variant="quiet" onClick={() => setCorruptBanner(false)}>知道了</Button>
              </div>
            )}

            <div className="relative flex-1 min-h-0 flex flex-col">
              {active === 'home' || !cur || !curWs ? (
                <Library sessions={sessions} workspaces={workspaces} openIds={openIds} narrow={narrow} short={short} petVisible={petOnHome} firstUse={firstUse}
                  onOpen={openSession} onNew={(ws, t) => newTask(ws, t)}
                  onAddWs={w => { setWorkspaces(x => [...x, w]); setFirstUse(false); toast(`已添加工作区「${w.name}」（模拟，未访问磁盘）`) }}
                  onPatchWs={(id, patch) => setWorkspaces(x => (patch ? x.map(w => (w.id === id ? { ...w, ...patch } : w)) : x.filter(w => w.id !== id)))} />
              ) : (
                <SessionView s={cur} ws={curWs} dispatch={a => act(cur.id, a)} narrow={narrow} short={short}
                  grants={grants[cur.workspace] ?? []} setGrant={setGrant} enterSends={prefs.enterSends}
                  onTyping={setTyping} composerRef={composerRef} stopArmed={stopArmed} armStop={b => { setStopArmed(b); escAt.current = Date.now() }} />
              )}
              <PetHost prefs={prefs.pet} setPrefs={p => setPrefsState(x => ({ ...x, pet: { ...x.pet, ...p } }))} typing={typing} reason={petReason} hidden={!!overlay} />

              {overlay === 'palette' && <Palette close={() => setOverlay(null)} run={k => {
                setOverlay(null)
                ;({
                  home: () => setActive('home'), new: () => newTask(cur?.workspace),
                  dock: () => cur && active !== 'home' && window.dispatchEvent(new Event('pioneer:panels')), demo: toggleDemo, reopen: () => reopen(), keys: () => setOverlay('keys'), notes: () => setOverlay('notes'),
                  settings: () => setOverlay('settings'), pet: () => setPrefs({ pet: { ...prefs.pet, state: prefs.pet.state === 'off' ? 'out' : 'off' } }),
                  full: () => setWin(w => (w === 'fullscreen' ? 'normal' : 'fullscreen')), quit: askQuit,
                } as Record<string, () => void>)[k]?.()
              }} />}
              {overlay === 'keys' && <Shortcuts close={() => setOverlay(null)} />}
              {overlay === 'notes' && <Notes close={() => setOverlay(null)} />}
              {overlay === 'settings' && <Settings initial={settingsTab} prefs={prefs} set={setPrefs} toggleDemo={toggleDemo} close={() => setOverlay(null)} onReset={resetAll} connected={connected} setConnected={setConnected} />}
              {overlay === 'quit' && <QuitDialog running={running} unsaved={saveState === 'error'} cancel={() => setOverlay(null)} quit={doQuit} close={closeWindow} />}
            </div>
            <StatusBar cur={cur} ws={active === 'home' ? undefined : curWs} short={short} running={running.length} save={saveState} retry={doSave} connected={connected} onKeys={() => setOverlay('keys')} />
          </div>
        )}

        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-[70] flex flex-col gap-2 items-center pointer-events-none" aria-live="polite">
          {toasts.map(t => (
            <div key={t.id} className="anim-rise pointer-events-auto flex items-center gap-3 rounded-xl bg-navy text-paper pl-4 pr-2 h-10 text-[13px] shadow-lg max-w-[90vw]">
              <span className="truncate">{t.text}</span>
              {t.undo && <button onClick={() => { t.undo!(); setToasts(x => x.filter(y => y.id !== t.id)) }} className="ring-focus h-7 px-2.5 rounded-md bg-paper/10 hover:bg-paper/20 font-medium shrink-0">撤销 <span className="opacity-60 font-mono text-[11px]">Alt⇧T</span></button>}
            </div>
          ))}
        </div>

        {demoMode && win !== 'fullscreen' && (
          <DemoControls open={demoOpen} setOpen={setDemoOpen} preset={preset} setPreset={p => { setPreset(p); setWin('normal') }}
            cur={active === 'home' ? undefined : cur} disconnect={() => cur && act(cur.id, { t: 'disconnect' })} demo={demo} setDemo={setDemo}
            corrupt={() => { corrupt(); location.reload() }} firstUse={firstUse} setFirstUse={b => { setFirstUse(b); setActive('home') }}
            reset={() => { setSettingsTab('data'); setOverlay('settings'); if (!visible) setWin('normal') }} />
        )}
      </div>

      {demoMode && win !== 'fullscreen' && <Taskbar win={win} restore={restore} minimize={() => setWin('minimized')} running={running.length} tray={tray} setTray={setTray} askQuit={askQuit}
        demoOpen={demoOpen} toggleDemoPanel={() => setDemoOpen(!demoOpen)} exitDemo={toggleDemo} />}
    </div>
  )
}
