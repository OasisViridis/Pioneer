import { useEffect, useLayoutEffect, useRef, useState } from 'react'
import type { Edge, Layout, ModuleId, PNode } from './data'
import { MODULES, findGroup, groups, type Op } from './layout'
import { Icon } from './ui'

type G = Extract<PNode, { k: 'group' }>
type Over = { group: string; edge: Edge }
type Ctx = {
  L: Layout; op: (o: Op) => void; render: (m: ModuleId) => React.ReactNode; badge: (m: ModuleId) => string | undefined
  short: boolean; single: boolean; drag: ModuleId | null; over: Over | null; startDrag: (m: ModuleId, e: React.PointerEvent) => void
}

/**
 * Composable panel workbench (Premiere-style). Module = what (conversation, context, changes…);
 * panel = a tab holding one module; group = tabs sharing a frame; layout = split tree of groups.
 * Everything you can drag here you can also do from a tab's menu (⋯, right-click, Shift+F10) or the 面板 menu.
 */
export default function Workbench({ L, op, render, badge, short }: { L: Layout; op: (o: Op) => void; render: Ctx['render']; badge: Ctx['badge']; short: boolean }) {
  const ref = useRef<HTMLDivElement>(null)
  const [w, setW] = useState(1000)
  const [drag, setDrag] = useState<ModuleId | null>(null)
  const [over, setOver] = useState<Over | null>(null)
  const [ghost, setGhost] = useState<{ x: number; y: number } | null>(null)
  useLayoutEffect(() => {
    const ro = new ResizeObserver(([e]) => setW(e.contentRect.width))
    ref.current && ro.observe(ref.current)
    return () => ro.disconnect()
  }, [])
  // compact: too narrow for side-by-side panels to stay readable — the conversation keeps the full width,
  // other panels slide over it as a sheet. The split tree is untouched and returns when the window widens.
  const stacked = w < 860 && groups(L.root).length > 1

  const startDrag = (m: ModuleId, e: React.PointerEvent) => {
    if (e.button !== 0 || stacked) return
    const sx = e.clientX, sy = e.clientY
    let on = false, last: Over | null = null
    const mv = (ev: PointerEvent) => {
      if (!on && Math.abs(ev.clientX - sx) + Math.abs(ev.clientY - sy) < 6) return
      if (!on) { on = true; setDrag(m); document.body.dataset.paneldrag = '1' }
      setGhost({ x: ev.clientX, y: ev.clientY })
      last = hit(ev.clientX, ev.clientY)
      setOver(last)
    }
    const end = (commit: boolean) => {
      window.removeEventListener('pointermove', mv); window.removeEventListener('pointerup', up); window.removeEventListener('keydown', esc, true)
      delete document.body.dataset.paneldrag
      if (on && commit && last) op({ op: 'move', m, group: last.group, edge: last.edge })
      setDrag(null); setOver(null); setGhost(null)
    }
    const up = () => end(true)
    const esc = (ev: KeyboardEvent) => { if (ev.key === 'Escape') { ev.stopPropagation(); end(false) } }
    window.addEventListener('pointermove', mv); window.addEventListener('pointerup', up); window.addEventListener('keydown', esc, true)
  }

  const ctx: Ctx = { L, op, render, badge, short, single: groups(L.root).length === 1 && groups(L.root)[0].tabs.length === 1, drag, over, startDrag }
  return (
    <div ref={ref} className="flex-1 min-h-0 min-w-0 flex bg-silver/40 relative" data-workbench>
      {stacked ? <Compact c={ctx} w={w} /> : <NodeView n={L.root} c={ctx} />}
      {drag && ghost && (
        <div className="fixed z-[80] pointer-events-none -translate-x-1/2 -translate-y-[130%] h-7 px-2.5 rounded-md bg-navy text-paper text-[12px] inline-flex items-center gap-1.5 shadow-lg" style={{ left: ghost.x, top: ghost.y }}>
          <Icon name={MODULES[drag].icon} size={12} />{MODULES[drag].label}
          <span className="opacity-60 text-[11px]">{over ? EDGE_LABEL[over.edge] : '拖到面板上'} · Esc 取消</span>
        </div>
      )}
    </div>
  )
}

const EDGE_LABEL: Record<Edge, string> = { center: '合并为标签', left: '放到左侧', right: '放到右侧', top: '放到上方', bottom: '放到下方' }

function hit(x: number, y: number): Over | null {
  const el = document.elementsFromPoint(x, y).find(e => (e as HTMLElement).closest?.('[data-group]')) as HTMLElement | undefined
  const g = el?.closest('[data-group]') as HTMLElement | null
  if (!g) return null
  if (el!.closest('[data-tabs]')) return { group: g.dataset.group!, edge: 'center' }
  const r = g.getBoundingClientRect()
  const d = { left: (x - r.left) / r.width, right: (r.right - x) / r.width, top: (y - r.top) / r.height, bottom: (r.bottom - y) / r.height }
  const [edge, v] = (Object.entries(d) as [Edge, number][]).sort((a, b) => a[1] - b[1])[0]
  return { group: g.dataset.group!, edge: v < 0.3 ? edge : 'center' }
}

function NodeView({ n, c }: { n: PNode; c: Ctx }) {
  if (n.k === 'group') return <GroupView g={n} c={c} />
  const row = n.dir === 'row'
  return (
    <div className={`flex-1 min-w-0 min-h-0 flex ${row ? 'flex-row' : 'flex-col'}`}>
      <div className={`min-w-0 min-h-0 flex ${row ? 'min-w-[200px]' : 'min-h-[110px]'}`} style={{ flex: `${n.ratio} 1 0px` }}><NodeView n={n.a} c={c} /></div>
      <Splitter id={n.id} row={row} ratio={n.ratio} op={c.op} />
      <div className={`min-w-0 min-h-0 flex ${row ? 'min-w-[200px]' : 'min-h-[110px]'}`} style={{ flex: `${1 - n.ratio} 1 0px` }}><NodeView n={n.b} c={c} /></div>
    </div>
  )
}

function Splitter({ id, row, ratio, op }: { id: string; row: boolean; ratio: number; op: (o: Op) => void }) {
  const down = (e: React.PointerEvent) => {
    const box = (e.currentTarget.parentElement as HTMLElement).getBoundingClientRect()
    const mv = (ev: PointerEvent) => op({ op: 'ratio', id, ratio: row ? (ev.clientX - box.left) / box.width : (ev.clientY - box.top) / box.height })
    const up = () => { window.removeEventListener('pointermove', mv); window.removeEventListener('pointerup', up); delete document.body.dataset.paneldrag }
    document.body.dataset.paneldrag = '1'
    window.addEventListener('pointermove', mv); window.addEventListener('pointerup', up)
  }
  const key = (e: React.KeyboardEvent) => {
    const d = { ArrowLeft: -0.04, ArrowUp: -0.04, ArrowRight: 0.04, ArrowDown: 0.04 }[e.key]
    if (d !== undefined) { e.preventDefault(); op({ op: 'ratio', id, ratio: ratio + d }) }
    if (e.key === 'Home' || e.key === 'Enter') { e.preventDefault(); op({ op: 'ratio', id, ratio: 0.5 }) }
  }
  return (
    <div role="separator" tabIndex={0} aria-orientation={row ? 'vertical' : 'horizontal'} aria-valuenow={Math.round(ratio * 100)} aria-valuemin={18} aria-valuemax={82}
      aria-label="拖动或用方向键调整面板大小，双击或 Enter 等分" title="拖动调整 · 方向键微调 · 双击等分"
      onPointerDown={down} onKeyDown={key} onDoubleClick={() => op({ op: 'ratio', id, ratio: 0.5 })}
      className={`ring-focus shrink-0 relative group/sp ${row ? 'w-[5px] cursor-col-resize' : 'h-[5px] cursor-row-resize'}`}>
      <span className={`absolute rounded-full bg-control/0 group-hover/sp:bg-control/50 group-focus-visible/sp:bg-navy transition-colors ${row ? 'inset-y-0 left-[2px] w-px' : 'inset-x-0 top-[2px] h-px'}`} />
    </div>
  )
}

/** a reveal request flashes the panel that answers it, once */
function useFlash(L: Layout, m: ModuleId) {
  const seen = useRef(L.pulse?.n ?? 0)
  const [on, setOn] = useState(false)
  useEffect(() => {
    const n = L.pulse?.n ?? 0
    if (n === seen.current) return
    seen.current = n
    if (L.pulse?.m !== m) return
    setOn(false)
    requestAnimationFrame(() => setOn(true))
    const t = setTimeout(() => setOn(false), 1100)
    return () => clearTimeout(t)
  }, [L.pulse?.n])
  return on
}

function GroupView({ g, c }: { g: G; c: Ctx }) {
  const focused = c.L.focus === g.id
  const flash = useFlash(c.L, g.active)
  const over = c.over?.group === g.id ? c.over.edge : null
  return (
    <section data-group={g.id} aria-label={`面板组：${g.tabs.map(t => MODULES[t].label).join('、')}`}
      onPointerDownCapture={() => !focused && c.op({ op: 'activate', group: g.id, m: g.active })}
      className={`relative flex-1 min-w-0 min-h-0 flex flex-col bg-paper m-[3px] rounded-[9px] overflow-hidden shadow-[0_0_0_1px_rgba(44,53,71,.08)] ${flash ? 'anim-reveal' : ''}`}>
      <Tabs g={g} c={c} focused={focused} />
      <div className="@container relative flex-1 min-h-0 flex flex-col">{c.render(g.active)}</div>
      {c.drag && over && <DropHint edge={over} />}
    </section>
  )
}

function DropHint({ edge }: { edge: Edge }) {
  const pos = { center: 'inset-1.5', left: 'inset-y-1.5 left-1.5 w-[calc(50%-6px)]', right: 'inset-y-1.5 right-1.5 w-[calc(50%-6px)]', top: 'inset-x-1.5 top-1.5 h-[calc(50%-6px)]', bottom: 'inset-x-1.5 bottom-1.5 h-[calc(50%-6px)]' }[edge]
  return <div aria-hidden className={`absolute ${pos} z-20 rounded-lg border-2 border-navy/50 bg-navy/[.07] grid place-items-center pointer-events-none`}><span className="rounded-md bg-navy text-paper text-[11.5px] px-2 py-1">{EDGE_LABEL[edge]}</span></div>
}

function Tabs({ g, c, focused }: { g: G; c: Ctx; focused: boolean }) {
  const [menu, setMenu] = useState<ModuleId | null>(null)
  const btns = useRef<Record<string, HTMLButtonElement | null>>({})
  const key = (m: ModuleId, e: React.KeyboardEvent) => {
    const i = g.tabs.indexOf(m)
    const go = (j: number) => { const t = g.tabs[(j + g.tabs.length) % g.tabs.length]; c.op({ op: 'activate', group: g.id, m: t }); btns.current[t]?.focus() }
    if (e.key === 'ArrowRight') { e.preventDefault(); go(i + 1) }
    if (e.key === 'ArrowLeft') { e.preventDefault(); go(i - 1) }
    if (e.key === 'Delete' && !c.single) { e.preventDefault(); c.op({ op: 'close', m }) }
    if (e.key === 'ContextMenu' || (e.key === 'F10' && e.shiftKey)) { e.preventDefault(); setMenu(m) }
  }
  return (
    <div data-tabs className={`shrink-0 flex items-stretch gap-0.5 pl-1.5 pr-1 border-b ${c.short ? 'h-8' : 'h-9'} ${focused ? 'border-navy/25 bg-canvas' : 'border-silver/70 bg-canvas/60'}`}>
      <div role="tablist" aria-label="面板标签" className="flex-1 min-w-0 flex items-stretch gap-0.5 overflow-x-auto scroll-quiet">
        {g.tabs.map(m => {
          const on = g.active === m
          const b = c.badge(m)
          return (
            <div key={m} className={`group/tab relative shrink-0 flex items-center rounded-t-md ${on ? 'bg-paper' : 'hover:bg-paper/60'} ${c.drag === m ? 'opacity-40' : ''}`}>
              {on && <span className={`absolute inset-x-1.5 top-0 h-[2px] rounded-full ${focused ? 'bg-navy' : 'bg-control/50'}`} />}
              <button ref={el => { btns.current[m] = el }} role="tab" aria-selected={on} tabIndex={on ? 0 : -1} data-module={m}
                onPointerDown={e => c.startDrag(m, e)} onClick={() => c.op({ op: 'activate', group: g.id, m })}
                onContextMenu={e => { e.preventDefault(); setMenu(m) }} onKeyDown={e => key(m, e)}
                title={`${MODULES[m].label} · 拖动移动 · 右键或 Shift+F10 更多`}
                className={`ring-focus h-full pl-2 pr-1 inline-flex items-center gap-1.5 text-[12.5px] whitespace-nowrap touch-none cursor-default ${on ? 'text-ink font-medium' : 'text-ink-2 hover:text-ink'}`}>
                <Icon name={MODULES[m].icon} size={12.5} />{MODULES[m].label}
                {b && <span className="font-mono text-[10.5px] text-ink-2 font-normal">{b}</span>}
              </button>
              {!c.single && (
                <button onClick={() => c.op({ op: 'close', m })} aria-label={`关闭${MODULES[m].label}面板（${m === 'chat' ? '会话保留' : '任务不受影响'}）`} title={m === 'chat' ? '关闭对话面板 · 会话与任务保留，可从「面板」重开' : '关闭面板 · 任务不受影响'}
                  className={`ring-focus size-5 mr-0.5 rounded grid place-items-center text-ink-2 hover:text-ink hover:bg-muted ${on ? 'opacity-70' : 'opacity-0 group-hover/tab:opacity-70 focus-visible:opacity-100'}`}>
                  <Icon name="x" size={10} />
                </button>
              )}
            </div>
          )
        })}
      </div>
      <div className="relative self-center">
        <button onClick={() => setMenu(menu ? null : g.active)} aria-haspopup="menu" aria-expanded={!!menu} aria-label="面板操作：拆分、移动、合并、关闭" title="拆分 · 移动 · 合并 · 关闭"
          className="ring-focus size-6 rounded-md grid place-items-center text-ink-2 hover:text-ink hover:bg-muted"><Icon name="dots" size={14} /></button>
        {menu && <TabMenu m={menu} g={g} c={c} close={() => { setMenu(null); btns.current[menu]?.focus() }} />}
      </div>
    </div>
  )
}

const Item = ({ label, onClick, disabled, hint }: { label: string; onClick: () => void; disabled?: boolean; hint?: string; danger?: boolean }) => (
  <button role="menuitem" disabled={disabled} onClick={onClick} title={hint}
    className="ring-focus w-full text-left px-2.5 h-8 rounded-md text-[12.5px] flex items-center gap-2 hover:bg-muted disabled:opacity-40 disabled:hover:bg-transparent">{label}</button>
)

function TabMenu({ m, g, c, close }: { m: ModuleId; g: G; c: Ctx; close: () => void }) {
  const ref = useRef<HTMLDivElement>(null)
  useEffect(() => {
    ref.current?.querySelector<HTMLButtonElement>('button:not(:disabled)')?.focus()
    const h = (e: PointerEvent) => { if (!ref.current?.contains(e.target as Node)) close() }
    window.addEventListener('pointerdown', h, true)
    return () => window.removeEventListener('pointerdown', h, true)
  }, [])
  const others = groups(c.L.root).filter(x => x.id !== g.id)
  const lone = g.tabs.length === 1
  const run = (o: Op) => { c.op(o); close() }
  const nav = (e: React.KeyboardEvent) => {
    const items = [...(ref.current?.querySelectorAll<HTMLButtonElement>('button:not(:disabled)') ?? [])]
    const i = items.indexOf(document.activeElement as HTMLButtonElement)
    if (e.key === 'ArrowDown') { e.preventDefault(); items[(i + 1) % items.length]?.focus() }
    if (e.key === 'ArrowUp') { e.preventDefault(); items[(i - 1 + items.length) % items.length]?.focus() }
    if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); close() }
  }
  const name = (x: G) => x.tabs.map(t => MODULES[t].label).join(' / ')
  return (
    <div ref={ref} role="menu" aria-label={`${MODULES[m].label} 面板操作`} onKeyDown={nav}
      className="anim-rise absolute right-0 top-full mt-1 z-40 w-60 rounded-xl bg-paper border border-silver shadow-lg p-1">
      <div className="px-2.5 pt-1.5 pb-1 text-[11px] text-ink-2">{MODULES[m].label}</div>
      <Item label="拆分到右侧" disabled={lone} hint={lone ? '组内只有这一个面板' : undefined} onClick={() => run({ op: 'move', m, group: g.id, edge: 'right' })} />
      <Item label="拆分到下方" disabled={lone} onClick={() => run({ op: 'move', m, group: g.id, edge: 'bottom' })} />
      {others.length > 0 && <div className="mx-2 my-1 h-px bg-silver/70" />}
      {others.map(x => <Item key={x.id} label={`合并到「${name(x)}」`} onClick={() => run({ op: 'move', m, group: x.id, edge: 'center' })} />)}
      {others.map(x => <Item key={x.id + 'r'} label={`放到「${name(x)}」右侧`} onClick={() => run({ op: 'move', m, group: x.id, edge: 'right' })} />).slice(0, 2)}
      {others.map(x => <Item key={x.id + 'b'} label={`放到「${name(x)}」下方`} onClick={() => run({ op: 'move', m, group: x.id, edge: 'bottom' })} />).slice(0, 2)}
      <div className="mx-2 my-1 h-px bg-silver/70" />
      <Item label={m === 'chat' ? '关闭对话面板 · 会话保留' : '关闭面板 · 任务不受影响'} disabled={c.single} hint={c.single ? '至少保留一个面板' : undefined} onClick={() => run({ op: 'close', m })} danger />
    </div>
  )
}

/** narrow windows: the conversation stays whole; any other open panel opens as a sheet over its right side */
function Compact({ c, w }: { c: Ctx; w: number }) {
  const gs = groups(c.L.root)
  const all = gs.flatMap(x => x.tabs)
  const base: ModuleId = all.includes('chat') ? 'chat' : gs[0].active
  const side = all.filter(m => m !== base)
  const [sheet, setSheet] = useState<ModuleId | null>(null)
  // a reveal request (button in the conversation, 面板 menu) opens the sheet; nothing else does
  const seen = useRef(c.L.pulse?.n ?? 0)
  useEffect(() => {
    const n = c.L.pulse?.n ?? 0
    if (n === seen.current) return
    seen.current = n
    const m = c.L.pulse!.m
    setSheet(m === base ? null : m)
  }, [c.L.pulse?.n])
  useEffect(() => { if (sheet && !all.includes(sheet)) setSheet(null) }, [all.join()])
  useEffect(() => {
    if (!sheet) return
    const k = (e: KeyboardEvent) => { if (e.key === 'Escape' && !e.defaultPrevented) setSheet(null) }
    window.addEventListener('keydown', k)
    return () => window.removeEventListener('keydown', k)
  }, [sheet])
  const pick = (m: ModuleId) => {
    const g = gs.find(x => x.tabs.includes(m))!
    c.op({ op: 'activate', group: g.id, m })
    setSheet(m === base || m === sheet ? null : m)
  }
  const full = w < 520
  const bg = gs.find(x => x.tabs.includes(base))!
  const sg = sheet ? gs.find(x => x.tabs.includes(sheet)) : undefined
  return (
    <div className="flex-1 min-w-0 min-h-0 flex flex-col bg-paper relative">
      <div role="tablist" aria-label="已打开的面板" className="shrink-0 h-9 flex items-stretch gap-0.5 px-1.5 border-b border-silver/70 bg-canvas overflow-x-auto scroll-quiet">
        {[base, ...side].map(m => {
          const on = sheet ? sheet === m : m === base
          return (
            <button key={m} role="tab" aria-selected={on} data-module={m} onClick={() => pick(m)}
              title={m === base ? '回到对话' : on ? '收起这个面板' : `在对话上方打开${MODULES[m].label}`}
              className={`ring-focus relative shrink-0 px-2 inline-flex items-center gap-1.5 text-[12.5px] whitespace-nowrap ${on ? 'text-ink font-medium' : 'text-ink-2 hover:text-ink'}`}>
              {on && <span className="absolute inset-x-1.5 bottom-0 h-[2px] rounded-full bg-navy" />}
              <Icon name={MODULES[m].icon} size={12.5} />{MODULES[m].label}
            </button>
          )
        })}
        <span className="flex-1" />
        <span className="self-center text-[11px] text-ink-2 pr-1 whitespace-nowrap" title="窗口拉宽后恢复原来的面板组合">窄窗视图</span>
      </div>
      <section data-group={bg.id} className="@container relative flex-1 min-h-0 flex flex-col" inert={!!sheet && full}>{c.render(base)}</section>
      {sheet && sg && (
        <>
          {!full && <button aria-label="收起面板，回到对话" onClick={() => setSheet(null)} className="absolute inset-x-0 top-9 bottom-0 bg-navy/[.06] cursor-default" />}
          <section data-group={sg.id} aria-label={MODULES[sheet].label}
            className={`anim-sheet absolute top-9 bottom-0 right-0 flex flex-col bg-paper ${full ? 'left-0' : 'w-[min(560px,64%)] border-l border-silver shadow-[-12px_0_32px_-16px_rgba(44,53,71,.28)]'}`}>
            <div className="shrink-0 h-9 flex items-center gap-2 pl-3 pr-1.5 border-b border-silver/70">
              <Icon name={MODULES[sheet].icon} size={13} className="text-control" />
              <span className="text-[12.5px] font-medium flex-1">{MODULES[sheet].label}</span>
              <button onClick={() => setSheet(null)} className="ring-focus h-7 px-2 rounded-md text-[12px] text-ink-2 hover:text-ink hover:bg-muted inline-flex items-center gap-1"><Icon name="x" size={11} />收起 <span className="text-ink-2/70">Esc</span></button>
            </div>
            <div className="@container relative flex-1 min-h-0 flex flex-col">{c.render(sheet)}</div>
          </section>
        </>
      )}
    </div>
  )
}
