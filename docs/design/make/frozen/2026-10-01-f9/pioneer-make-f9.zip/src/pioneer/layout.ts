/* Panel composition · pure operations on a session's layout tree.
   Rule: only user acts (click, menu, key, drag) call these. Results never do. */
import { group, uid, type Edge, type Layout, type ModuleId, type PNode } from './data'

export type Op =
  | { op: 'open'; m: ModuleId; edge?: Exclude<Edge, 'center'>; preview?: string }
  | { op: 'move'; m: ModuleId; group: string; edge: Edge }
  | { op: 'close'; m: ModuleId }
  | { op: 'activate'; group: string; m: ModuleId }
  | { op: 'ratio'; id: string; ratio: number }
  | { op: 'preview'; id: string }
  | { op: 'reset' }

export const MODULES: Record<ModuleId, { label: string; icon: string; wide?: boolean }> = {
  chat: { label: '对话', icon: 'chat' },
  context: { label: '上下文', icon: 'layers' },
  changes: { label: '改动', icon: 'diff', wide: true },
  deliver: { label: '验收与交付', icon: 'flask', wide: true },
  preview: { label: '产物预览', icon: 'file', wide: true },
  log: { label: '执行日志', icon: 'terminal' },
  caps: { label: '能力与授权', icon: 'bolt' },
}

export const groups = (n: PNode): Extract<PNode, { k: 'group' }>[] => (n.k === 'group' ? [n] : [...groups(n.a), ...groups(n.b)])
export const findGroup = (L: Layout, id: string) => groups(L.root).find(g => g.id === id)
export const groupOf = (L: Layout, m: ModuleId) => groups(L.root).find(g => g.tabs.includes(m))
export const isOpen = (L: Layout, m: ModuleId) => !!groupOf(L, m)
/** a module is "visible" when it's the active tab of its group */
export const isShown = (L: Layout, m: ModuleId) => groupOf(L, m)?.active === m

const map = (n: PNode, f: (n: PNode) => PNode | null): PNode | null => {
  if (n.k === 'group') return f(n)
  const a = map(n.a, f), b = map(n.b, f)
  if (!a && !b) return null
  if (!a) return b
  if (!b) return a
  return f({ ...n, a, b })
}

function remove(root: PNode, m: ModuleId): PNode | null {
  return map(root, n => {
    if (n.k !== 'group' || !n.tabs.includes(m)) return n
    const tabs = n.tabs.filter(t => t !== m)
    if (!tabs.length) return null
    return { ...n, tabs, active: n.active === m ? tabs[Math.max(0, n.tabs.indexOf(m) - 1)] : n.active }
  })
}

/** ratio = share of the new panel */
function insert(root: PNode, m: ModuleId, gid: string, edge: Edge, ratio = 0.5): { root: PNode; gid: string } {
  let out = gid
  const r = map(root, n => {
    if (n.k !== 'group' || n.id !== gid) return n
    if (edge === 'center') return { ...n, tabs: [...n.tabs, m], active: m }
    const g = group([m])
    out = g.id
    const first = edge === 'left' || edge === 'top'
    return { k: 'split', id: uid('x'), dir: edge === 'left' || edge === 'right' ? 'row' : 'col', ratio: first ? ratio : 1 - ratio, a: first ? g : n, b: first ? n : g }
  })!
  return { root: r, gid: out }
}

export function applyOp(L: Layout, o: Op): Layout {
  switch (o.op) {
    case 'activate': return { ...L, focus: o.group, root: map(L.root, n => (n.k === 'group' && n.id === o.group ? { ...n, active: o.m } : n))! }
    case 'preview': return { ...L, preview: o.id }
    case 'ratio': return { ...L, root: map(L.root, n => (n.k === 'split' && n.id === o.id ? { ...n, ratio: Math.max(0.18, Math.min(0.82, o.ratio)) } : n))! }
    case 'reset': return { root: group(['chat']), focus: '', recent: [], preview: L.preview }
    case 'close': {
      const all = groups(L.root)
      if (!groupOf(L, o.m) || (all.length === 1 && all[0].tabs.length === 1)) return L // the last panel stays: never an empty window
      const root = remove(L.root, o.m)!
      return { ...L, root, recent: [o.m, ...L.recent.filter(x => x !== o.m)].slice(0, 6) }
    }
    case 'open': {
      const pv = { ...(o.preview ? { preview: o.preview } : {}), pulse: { m: o.m, n: (L.pulse?.n ?? 0) + 1 } }
      const at = groupOf(L, o.m)
      if (at && !o.edge) return { ...applyOp(L, { op: 'activate', group: at.id, m: o.m }), ...pv }
      const recent = L.recent.filter(x => x !== o.m)
      const base = at ? remove(L.root, o.m)! : L.root
      const gs = groups(base)
      const chat = gs.find(g => g.tabs.includes('chat'))
      // default placement: join the panel group beside the conversation; otherwise split the conversation to the right
      const side = gs.filter(g => g !== chat)
      const target = o.edge ? (chat ?? gs[0]) : side.find(g => g.id === L.focus) ?? side[side.length - 1]
      if (target && !o.edge) {
        const r = insert(base, o.m, target.id, 'center')
        return { ...L, ...pv, root: r.root, focus: r.gid, recent }
      }
      const host = target ?? gs[0]
      const r = insert(base, o.m, host.id, o.edge ?? 'right', MODULES[o.m].wide ? 0.54 : 0.36)
      return { ...L, ...pv, root: r.root, focus: r.gid, recent }
    }
    case 'move': {
      const src = groupOf(L, o.m)
      if (!src) return L
      if (src.id === o.group && (o.edge === 'center' || src.tabs.length === 1)) return L
      const base = remove(L.root, o.m)
      if (!base || !groups(base).some(g => g.id === o.group)) return L
      const r = insert(base, o.m, o.group, o.edge)
      return { ...L, root: r.root, focus: r.gid }
    }
  }
}

/** layouts saved before the panel tree carried {dock, dockTab, dockW} */
export function migrateLayout(l: any): Layout {
  if (l && l.root && (l.root.k === 'group' || l.root.k === 'split')) return { root: l.root, focus: l.focus ?? '', recent: Array.isArray(l.recent) ? l.recent : [], preview: l.preview }
  const a = group(['chat'])
  if (!l?.dock) return { root: a, focus: a.id, recent: [] }
  const tab: ModuleId = ({ review: 'changes', changes: 'changes', deliver: 'deliver', files: 'preview', context: 'context', caps: 'caps' } as Record<string, ModuleId>)[l.dockTab] ?? 'context'
  const b = group([tab])
  return { root: { k: 'split', id: uid('x'), dir: 'row', ratio: MODULES[tab].wide ? 0.5 : 0.66, a, b }, focus: b.id, recent: [] }
}
