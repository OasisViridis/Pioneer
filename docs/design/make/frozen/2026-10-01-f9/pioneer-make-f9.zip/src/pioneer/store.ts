/* Prototype persistence. Only keys with PREFIX are ever read, written or cleared. */
import { seedSessions, type Session, type Workspace } from './data'
import type { PetPrefs } from './Pet'
import { migrateLayout } from './layout'

export const PREFIX = 'pioneer-proto'
export const KEY = `${PREFIX}-v5`
export const BACKUP = `${PREFIX}-v5.corrupt`

export type Prefs = { demo: boolean; motion: 'system' | 'off'; enterSends: boolean; restoreTabs: boolean; speed: 'slow' | 'normal' | 'fast'; pet: PetPrefs }
export type Saved = { v: 5; sessions: Session[]; workspaces: Workspace[]; openIds: string[]; active: string; closed: string[]; grants: Record<string, string[]>; prefs: Prefs; firstUse: boolean }

export const DEFAULT_PREFS: Prefs = { demo: false, motion: 'system', enterSends: false, restoreTabs: true, speed: 'normal', pet: { state: 'out', pos: { r: 28, b: 96 }, remember: true, bubbles: true } }

// earlier v5 saves carried a page "mode" or a single dock {dock, dockTab, dockW} — both become a panel tree
function migrate(s: any) {
  // the delivered report example used to have no artifacts to revisit — bring in the completed one
  if (s.id === 's-recon' && s.script !== 'recon') return seedSessions().find(x => x.id === 's-recon')!
  // intent sign-off was removed: drop its cards and give older sessions the default permission mode
  const blocks = s.blocks.filter((b: any) => b.kind !== 'intent' && !(b.kind === 'permission' && !b.perm))
  const phase = s.phase === 'intent' || (s.phase === 'permission' && !blocks.some((b: any) => b.kind === 'permission' && b.state === 'open')) ? 'empty' : s.phase
  return { ...s, blocks, phase, permMode: s.permMode ?? 'ask', model: s.model ?? 'claude-opus-5-5', allowed: s.allowed ?? [], layout: migrateLayout(s.layout) }
}
function valid(d: any): d is Saved {
  return d && d.v === 5 && Array.isArray(d.sessions) && Array.isArray(d.workspaces) && Array.isArray(d.openIds) && typeof d.active === 'string'
    && d.sessions.every((s: any) => s && typeof s.id === 'string' && Array.isArray(s.blocks) && s.layout && s.hunks)
}

export function load(): { data: Saved | null; status: 'ok' | 'empty' | 'corrupt' } {
  let raw: string | null = null
  try { raw = localStorage.getItem(KEY) } catch { return { data: null, status: 'empty' } }
  if (!raw) return { data: null, status: 'empty' }
  try {
    const d = JSON.parse(raw)
    if (valid(d)) return { data: { ...d, sessions: d.sessions.map(migrate), prefs: { ...DEFAULT_PREFS, ...d.prefs, pet: { ...DEFAULT_PREFS.pet, ...d.prefs?.pet } } }, status: 'ok' }
  } catch { /* fall through */ }
  try { localStorage.setItem(BACKUP, raw) } catch { /* ignore */ }
  return { data: null, status: 'corrupt' }
}

export function save(d: Saved, simulateFail: boolean): boolean {
  try {
    if (simulateFail) throw new Error('QuotaExceededError (simulated)')
    localStorage.setItem(KEY, JSON.stringify(d))
    return true
  } catch { return false }
}

export function protoKeys() {
  const out: string[] = []
  try { for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); if (k && k.startsWith(PREFIX)) out.push(k) } } catch { /* ignore */ }
  return out
}
export function resetProto() { protoKeys().forEach(k => localStorage.removeItem(k)) }
export function corrupt() { localStorage.setItem(KEY, '{"v":5,"sessions":[{"id":') }
