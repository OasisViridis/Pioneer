import { useState } from 'react'
import { FAKE_FS, rel, type Session, type Workspace } from './data'
import { isActive, needsYou } from './flow'
import { elide, phaseInfo } from './Session'
import { Button, Icon, Kbd, Status, QuietSlot, Mark, Modal } from './ui'

type Props = {
  sessions: Session[]
  workspaces: Workspace[]
  openIds: string[]
  narrow: boolean
  short: boolean
  petVisible: boolean
  firstUse: boolean
  onOpen: (id: string) => void
  onNew: (ws: string, text?: string) => void
  onAddWs: (w: Workspace) => void
  onPatchWs: (id: string, patch: Partial<Workspace> | null) => void
}

/** Covers show what kind of content is inside — never Hazel art, never status. */
function Cover({ w }: { w: Pick<Workspace, 'cover' | 'tint'> }) {
  return (
    <div className="aspect-[16/9] rounded-lg relative overflow-hidden" style={{ background: w.tint }} aria-hidden>
      {w.cover === 'code' && <div className="absolute inset-3 flex flex-col gap-1.5 font-mono">{[70, 45, 82, 30, 60].map((x, i) => <span key={i} className="h-1 rounded bg-ink/15" style={{ width: `${x}%`, marginLeft: i % 3 ? 10 : 0 }} />)}</div>}
      {w.cover === 'map' && <svg className="absolute inset-0 size-full" viewBox="0 0 160 90"><path d="M0 60 Q40 40 80 55 T160 45" stroke="#858d92" strokeOpacity=".5" fill="none" /><path d="M0 30 Q50 50 90 25 T160 35" stroke="#858d92" strokeOpacity=".35" fill="none" /><path d="M60 0 L70 90 M120 0 L105 90" stroke="#fdfcfa" strokeWidth="3" /></svg>}
      {w.cover === 'doc' && <div className="absolute left-1/2 top-3 -translate-x-1/2 w-[46%] bottom-0 bg-paper rounded-t-md shadow-sm p-2 flex flex-col gap-1">{[90, 70, 85, 50].map((x, i) => <span key={i} className="h-[3px] rounded bg-ink/15" style={{ width: `${x}%` }} />)}</div>}
      {w.cover === 'image' && <div className="absolute inset-3 grid grid-cols-3 gap-1.5">{[0, 1, 2, 3, 4, 5].map(i => <span key={i} className="rounded bg-paper/70" />)}</div>}
    </div>
  )
}

export default function Library(p: Props) {
  const { sessions, workspaces, openIds, narrow, short, petVisible, firstUse, onOpen, onNew } = p
  const [ws, setWs] = useState<string>(workspaces[0]?.id ?? '')
  const [q, setQ] = useState('')
  const [quick, setQuick] = useState('')
  const [adding, setAdding] = useState(false)
  const cur = workspaces.find(w => w.id === ws) ?? workspaces[0]
  const running = sessions.filter(isActive)
  const waiting = sessions.filter(s => needsYou(s) && !isActive(s))

  if (firstUse || !workspaces.length) return (
    <div className="flex-1 min-h-0 overflow-auto scroll-quiet grid place-items-center px-6">
      <div className="max-w-[520px] text-center py-10 flex flex-col items-center">
        {!petVisible && <QuietSlot seed="first-use" />}
        <h1 className="font-serif font-medium text-[28px] leading-[40px] mt-5">先选一个文件夹</h1>
        <p className="text-[15px] leading-6 text-ink-2 mt-2">Pioneer 以文件夹为工作区。它在你确认之前不会读取任何内容，只读文件夹也可以添加。</p>
        <Button variant="primary" icon="folder" className="mt-6" onClick={() => setAdding(true)}>添加工作区…</Button>
        <p className="text-[11.5px] text-ink-2 mt-3">原型中使用模拟的文件夹选择器，不会访问你的磁盘。</p>
      </div>
      {adding && <AddWs existing={workspaces} close={() => setAdding(false)} add={w => { p.onAddWs(w); setWs(w.id); setAdding(false) }} />}
    </div>
  )

  const term = q.trim().toLowerCase()
  const hits = term ? sessions.filter(s => s.title.toLowerCase().includes(term) || workspaces.find(w => w.id === s.workspace)?.name.toLowerCase().includes(term)) : null
  const list = sessions.filter(s => s.workspace === cur.id).sort((a, b) => b.updated - a.updated)
  const recent = [...sessions].sort((a, b) => b.updated - a.updated).slice(0, 4)

  return (
    <div className="flex-1 min-h-0 overflow-auto scroll-quiet">
      <div className={`mx-auto max-w-[1080px] ${narrow ? 'px-5' : 'px-10'} ${short ? 'py-5' : 'py-10'}`}>
        <div className={`flex items-end gap-8 ${short ? 'mb-5' : 'mb-8'}`}>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 text-[12px] text-ink-2 mb-3"><Mark size={18} />周四 · 10月1日 · 本机</div>
          </div>
          {!petVisible && !short && !narrow && <QuietSlot seed="welcome-organizing" />}
        </div>

        <label className="relative block mb-6">
          <Icon name="search" size={14} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-control" />
          <input value={q} onChange={e => setQ(e.target.value)} placeholder="搜索全部会话与工作区" aria-label="搜索"
            onKeyDown={e => { if (e.key === 'Escape' && q) { e.stopPropagation(); setQ('') } }}
            className="ring-focus h-10 w-full pl-9 pr-9 rounded-xl border border-silver bg-paper text-[14px] outline-none focus:border-control" />
          {q && <button aria-label="清除搜索" onClick={() => setQ('')} className="ring-focus absolute right-2 top-1/2 -translate-y-1/2 size-6 grid place-items-center rounded text-control hover:text-ink"><Icon name="x" size={12} /></button>}
        </label>

        {hits ? (
          <section aria-label="搜索结果">
            <h2 className="text-[12px] text-ink-2 mb-2">{hits.length ? `${hits.length} 个结果` : '没有结果'}</h2>
            {hits.length ? <SessionList items={hits} openIds={openIds} onOpen={onOpen} workspaces={workspaces} showWs />
              : <div className="rounded-xl border border-dashed border-silver px-6 py-8 text-[14px] text-ink-2">没有标题或工作区包含「{q}」。试试更短的词，或 <button className="underline text-ink" onClick={() => { setQuick(q); setQ('') }}>以它开始新任务</button>。</div>}
          </section>
        ) : (
          <>
            {(running.length > 0 || waiting.length > 0) && (
              <div className="mb-6 grid gap-2">
                {running.length > 0 && <Banner tone="run" label="后台进行中" items={running} onOpen={onOpen} />}
                {waiting.length > 0 && <Banner tone="warn" label="等你处理" items={waiting} onOpen={onOpen} />}
              </div>
            )}
            <div className={`grid gap-8 ${narrow ? '' : 'grid-cols-[minmax(0,1fr)_minmax(0,1.35fr)]'}`}>
              <section aria-label="工作区">
                <div className="flex items-center justify-between mb-3">
                  <h2 className="text-[12px] font-medium text-ink-2 uppercase tracking-[.08em]">工作区 · {workspaces.length}</h2>
                  <button onClick={() => setAdding(true)} className="ring-focus text-[12px] text-ink-2 hover:text-ink inline-flex items-center gap-1"><Icon name="plus" size={12} />添加文件夹</button>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  {workspaces.map(w => {
                    const count = sessions.filter(s => s.workspace === w.id).length
                    return (
                      <button key={w.id} onClick={() => setWs(w.id)} aria-pressed={cur.id === w.id}
                        className={`ring-focus text-left rounded-xl border p-3 transition ${cur.id === w.id ? 'border-navy bg-paper' : 'border-silver/80 bg-paper/60 hover:bg-paper hover:border-control'}`}>
                        <div className={`relative mb-3 ${w.unavailable ? 'opacity-50 grayscale' : ''}`}>
                          <Cover w={w} />
                          {count > 0 && <span className="absolute top-2 right-2 text-[10.5px] font-mono px-1.5 py-0.5 rounded bg-paper/85 text-ink-2">{count} 会话</span>}
                        </div>
                        <div className="text-[14px] font-medium truncate flex items-center gap-1.5">{w.readOnly && <Icon name="lock" size={12} className="text-control" />}{w.name}</div>
                        <div className={`text-[11.5px] truncate ${w.unavailable ? 'text-berry' : 'text-ink-2'}`}>{w.unavailable ? `不可用 · ${w.unavailable}` : `${w.kind} · ${w.note}`}</div>
                      </button>
                    )
                  })}
                </div>
                {!narrow && (
                  <div className="mt-6">
                    <h2 className="text-[12px] font-medium text-ink-2 uppercase tracking-[.08em] mb-2">最近</h2>
                    <SessionList items={recent} openIds={openIds} onOpen={onOpen} workspaces={workspaces} showWs dense />
                  </div>
                )}
              </section>

              <section aria-label={`${cur.name} 的会话`} className="min-w-0">
                <div className="mb-3 min-w-0">
                  <h2 className="text-[16px] leading-6 font-medium truncate">{cur.name}</h2>
                  <div className="font-mono text-[11.5px] text-ink-2 truncate" title={cur.path}>{elide(cur.path, 64)} · {cur.kind}</div>
                </div>
                {cur.unavailable ? (
                  <div role="alert" className="rounded-xl border border-berry/30 bg-rose/40 px-4 py-4 mb-4">
                    <div className="text-[14px] font-medium text-berry flex items-center gap-2"><Icon name="alert" size={14} />找不到这个文件夹</div>
                    <p className="text-[13px] leading-5 text-ink-2 mt-1">{cur.unavailable}。已有会话仍可查看，但无法开始新任务。</p>
                    <div className="flex flex-wrap gap-2 mt-3">
                      <Button size="sm" icon="refresh" onClick={() => p.onPatchWs(cur.id, { unavailable: undefined })}>重新检测（模拟已连接）</Button>
                      <Button size="sm" variant="quiet" icon="folder" onClick={() => p.onPatchWs(cur.id, { unavailable: undefined, path: 'F:\\design\\hazel' })}>重新定位到 F:\design\hazel</Button>
                      <Button size="sm" variant="quiet" icon="trash" onClick={() => { p.onPatchWs(cur.id, null); setWs(workspaces[0].id) }}>从列表移除</Button>
                    </div>
                  </div>
                ) : (
                  <form onSubmit={e => { e.preventDefault(); onNew(cur.id, quick); setQuick('') }} className="flex items-center gap-2 rounded-xl border border-silver bg-paper pl-4 pr-2 h-12 mb-4 focus-within:border-control">
                    <Icon name="sparkle" size={14} className="text-control" />
                    <input value={quick} onChange={e => setQuick(e.target.value)} placeholder={`在 ${cur.name} 中开始新任务…`} className="flex-1 min-w-0 bg-transparent outline-none text-[14px] placeholder:text-control" aria-label="新任务" />
                    <span className="hidden sm:inline text-[11px] text-ink-2"><Kbd>Alt</Kbd> <Kbd>N</Kbd></span>
                    <Button size="sm" variant="primary" type="submit">新会话</Button>
                  </form>
                )}
                {list.length === 0 ? (
                  <div className="rounded-xl border border-dashed border-silver px-6 py-8 flex items-center gap-5">
                    <QuietSlot seed={'ws-' + cur.id} compact />
                    <div>
                      <div className="text-[14px] font-medium">这里还没有会话</div>
                      <div className="text-[13px] text-ink-2">{cur.readOnly ? '这个文件夹只读，Agent 可以阅读与总结，但不会写入。' : '在上方写一句具体的任务，就能开始。'}</div>
                    </div>
                  </div>
                ) : <SessionList items={list} openIds={openIds} onOpen={onOpen} workspaces={workspaces} />}
              </section>
            </div>
          </>
        )}
      </div>
      {adding && <AddWs existing={workspaces} close={() => setAdding(false)} add={w => { p.onAddWs(w); setWs(w.id); setAdding(false) }} />}
    </div>
  )
}

function Banner({ tone, label, items, onOpen }: { tone: 'run' | 'warn'; label: string; items: Session[]; onOpen: (id: string) => void }) {
  return (
    <div className="rounded-xl border border-silver bg-paper px-4 py-2.5 flex flex-wrap items-center gap-2">
      <Status tone={tone} pulse={tone === 'run'}>{label}</Status>
      <span className="flex-1" />
      {items.map(r => <Button key={r.id} size="sm" variant="quiet" onClick={() => onOpen(r.id)}>{r.title} · {phaseInfo(r).label}<Icon name="chevron" size={11} /></Button>)}
    </div>
  )
}

function SessionList({ items, openIds, onOpen, workspaces, showWs, dense }: { items: Session[]; openIds: string[]; onOpen: (id: string) => void; workspaces: Workspace[]; showWs?: boolean; dense?: boolean }) {
  return (
    <ul className="rounded-xl border border-silver bg-paper divide-y divide-silver/60 overflow-hidden">
      {items.map(s => {
        const ph = phaseInfo(s)
        return (
          <li key={s.id}>
            <button onClick={() => onOpen(s.id)} className={`ring-focus w-full text-left px-4 flex items-center gap-3 hover:bg-canvas ${dense ? 'py-2' : 'py-3'}`}>
              <span className="flex-1 min-w-0">
                <span className="block text-[14px] truncate">{s.title}</span>
                <span className="block text-[11.5px] text-ink-2 truncate">{showWs ? `${workspaces.find(w => w.id === s.workspace)?.name ?? '已移除的工作区'} · ` : ''}{rel(s.updated)}{openIds.includes(s.id) ? ' · 标签已打开' : ''}{s.draft ? ' · 有草稿' : ''}</span>
              </span>
              <Status tone={ph.tone} pulse={ph.pulse}>{ph.label}</Status>
            </button>
          </li>
        )
      })}
    </ul>
  )
}

function AddWs({ existing, close, add }: { existing: Workspace[]; close: () => void; add: (w: Workspace) => void }) {
  const [pick, setPick] = useState<number | null>(null)
  const [ro, setRo] = useState(false)
  const opts = FAKE_FS.filter(f => !existing.some(e => e.path === f.path))
  return (
    <Modal label="添加工作区" title={<span className="flex items-center gap-2">添加工作区 <span className="text-[10.5px] font-mono px-1.5 py-0.5 rounded border border-dashed border-control/60 text-ink-2">模拟选择器</span></span>} onClose={close} width={480}>
      <p className="text-[13px] text-ink-2 mb-3">真实应用会打开 Windows 文件夹对话框。原型只列出虚构的文件夹，不读取你的磁盘。</p>
      {opts.length === 0 ? <p className="text-[13px] rounded-lg border border-dashed border-silver px-3 py-4 text-ink-2">示例文件夹都已添加。可以在设置中重置演示数据。</p> : (
        <ul role="listbox" aria-label="文件夹" className="rounded-lg border border-silver divide-y divide-silver/60">
          {opts.map((f, i) => (
            <li key={f.path}>
              <button role="option" aria-selected={pick === i} onClick={() => setPick(i)} className={`ring-focus w-full text-left px-3 py-2.5 flex items-center gap-3 ${pick === i ? 'bg-mint/50' : 'hover:bg-canvas'}`}>
                <Icon name="folder" className="text-control" />
                <span className="flex-1 min-w-0"><span className="block font-mono text-[12.5px] truncate">{f.path}</span><span className="block text-[11.5px] text-ink-2">{f.kind}</span></span>
                {pick === i && <Icon name="check" className="text-mint-ink" />}
              </button>
            </li>
          ))}
        </ul>
      )}
      <label className="flex items-center gap-2 mt-3 text-[13px]"><input type="checkbox" checked={ro} onChange={e => setRo(e.target.checked)} className="size-4 accent-[#333c50]" />以只读方式添加（Agent 只能阅读）</label>
      <div className="flex justify-end gap-2 mt-5">
        <Button variant="quiet" onClick={close}>取消</Button>
        <Button variant="primary" disabled={pick === null} onClick={() => {
          const f = opts[pick!]
          add({ id: 'w' + Date.now().toString(36), name: f.path.split('\\').pop()!, path: f.path, kind: f.kind, cover: f.cover, tint: f.tint, note: ro ? '只读文件夹' : '新添加', readOnly: ro, added: Date.now() })
        }}>添加</Button>
      </div>
    </Modal>
  )
}
