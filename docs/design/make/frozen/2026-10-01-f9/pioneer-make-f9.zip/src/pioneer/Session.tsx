import { Fragment, useEffect, useRef, useState } from 'react'
import { MODELS, SCRIPTS, type Block, type Decision, type ModuleId, type PermMode, type Session, type Workspace } from './data'
import { currentHunks, isActive, type Action } from './flow'
import { Button, Icon, Kbd, Seg, Status, QuietSlot, type Tone } from './ui'
import Workbench from './Workbench'
import { Caps, Context, Log, Preview } from './Modules'
import { MODULES, groups, isOpen, isShown, type Op } from './layout'

export function phaseInfo(s: Session): { label: string; tone: Tone; pulse?: boolean } {
  const total = SCRIPTS[s.script].steps.length
  switch (s.phase) {
    case 'empty': return { label: s.blocks.length ? '空闲' : '新会话', tone: 'neutral' }
    case 'permission': return { label: '等你允许', tone: 'warn' }
    case 'denied': return { label: '已拒绝', tone: 'neutral' }
    case 'running': return { label: `运行中 ${Math.min(s.step + 1, total)}/${total}`, tone: 'run', pulse: true }
    case 'stopping': return { label: '正在停止…', tone: 'warn', pulse: true }
    case 'stopped': return { label: s.handoff ? '已交给你' : '已停止', tone: 'neutral' }
    case 'failed': return { label: '失败', tone: 'bad' }
    case 'disconnected': return { label: '断连 · 结果未知', tone: 'bad' }
    case 'checking': return { label: '核对中…', tone: 'warn', pulse: true }
    case 'reconciled': return { label: '已核对 · 等你选择', tone: 'warn' }
    case 'review': return { label: `v${s.version} 待审阅`, tone: 'warn' }
    case 'revising': return { label: `生成 v${s.version + 1}…`, tone: 'run', pulse: true }
    case 'applying': return { label: '正在应用…', tone: 'run', pulse: true }
    case 'applied': return { label: '已应用 · 未验收', tone: 'local' }
    case 'verifying': return { label: '验收中…', tone: 'run', pulse: true }
    case 'verifyFailed': return { label: '验收未通过', tone: 'bad' }
    case 'verified': return { label: s.manualOk ? '验收通过 · 可交付' : '待人工确认', tone: s.manualOk ? 'ok' : 'warn' }
    case 'delivered': return { label: '已交付', tone: 'ok' }
  }
}

/** Middle-elide long Windows paths so the drive and leaf stay readable. */
export function elide(p: string, max = 46) {
  if (p.length <= max) return p
  const parts = p.split('\\')
  return `${parts[0]}\\…\\${parts.slice(-2).join('\\')}`.slice(-max)
}

type Props = {
  s: Session
  ws: Workspace
  dispatch: (a: Action) => void
  narrow: boolean
  short: boolean
  grants: string[]
  setGrant: (perm: string, on: boolean) => void
  enterSends: boolean
  onTyping: (b: boolean) => void
  composerRef: React.RefObject<HTMLTextAreaElement | null>
  stopArmed: boolean
  armStop: (b: boolean) => void
}

export default function SessionView(p: Props) {
  const { s, dispatch, ws } = p
  const op = (o: Op) => dispatch({ t: 'layout', o })
  const sc = SCRIPTS[s.script]
  const render = (m: ModuleId) => {
    switch (m) {
      case 'chat': return <><Conversation {...p} compact /><Composer {...p} compact /></>
      case 'context': return <Scroll><Context s={s} dispatch={dispatch} /></Scroll>
      case 'caps': return <Scroll><Caps s={s} ws={ws} grants={p.grants} setGrant={p.setGrant} /></Scroll>
      case 'log': return <Log s={s} />
      case 'preview': return <Preview s={s} op={op} />
      case 'changes': return sc.kind === 'report' ? <Unavailable text="这是报表任务，没有代码改动。报表在「产物预览」里。" action={['打开产物预览', () => op({ op: 'open', m: 'preview' })]} />
        : Object.keys(s.hunks).length ? <ReviewPane s={s} dispatch={dispatch} /> : <Unavailable text="这一轮还没有可审阅的改动。结果出来后只会在对话里提示，不会自动打开。" />
      case 'deliver': return <DeliverPane s={s} dispatch={dispatch} ws={ws} />
    }
  }
  const badge = (m: ModuleId) => (m === 'changes' && Object.keys(s.hunks).length ? String(Object.values(s.hunks).filter(x => x === 'pending').length || '') || undefined : undefined)
  return (
    <div className="flex-1 min-h-0 flex flex-col">
      <Header {...p} op={op} />
      <Workbench L={s.layout} op={op} render={render} badge={badge} short={p.short} />
    </div>
  )
}

const Scroll = ({ children }: { children: React.ReactNode }) => <div className="flex-1 min-h-0 overflow-auto scroll-quiet p-3">{children}</div>
function Unavailable({ text, action }: { text: string; action?: [string, () => void] }) {
  return <div className="flex-1 min-h-0 grid place-items-center p-6"><div className="max-w-[300px] text-center text-[12.5px] leading-5 text-ink-2">{text}{action && <div className="mt-3"><Button size="sm" onClick={action[1]}>{action[0]}</Button></div>}</div></div>
}

/** which modules make sense for this task right now — a closed list, never a forced empty panel */
export function moduleAvail(s: Session): Partial<Record<ModuleId, string>> {
  const sc = SCRIPTS[s.script]
  const post = POST.includes(s.phase)
  return {
    changes: sc.kind === 'report' ? '报表任务没有代码改动' : Object.keys(s.hunks).length ? undefined : '还没有改动',
    deliver: post ? undefined : '结果出来后可用',
    preview: post || Object.keys(s.hunks).length ? undefined : '还没有产物',
    log: s.blocks.some(b => b.kind === 'run') ? undefined : '还没有运行过',
  }
}
const POST = ['review', 'revising', 'applying', 'applied', 'verifying', 'verifyFailed', 'verified', 'delivered']

function Header({ s, ws, dispatch, narrow, op }: Props & { op: (o: Op) => void }) {
  const ph = phaseInfo(s)
  const [edit, setEdit] = useState(false)
  const [menu, setMenu] = useState(false)
  useEffect(() => { const h = () => setMenu(m => !m); window.addEventListener('pioneer:panels', h); return () => window.removeEventListener('pioneer:panels', h) }, [])
  return (
    <header className="shrink-0 h-12 flex items-center gap-3 px-4 border-b border-silver/70 bg-canvas relative z-[35]">
      <div className="min-w-0 flex-1 flex items-center gap-3">
        {edit ? (
          <input autoFocus defaultValue={s.title} aria-label="会话名称" maxLength={40}
            onBlur={e => { dispatch({ t: 'rename', title: e.target.value }); setEdit(false) }}
            onKeyDown={e => { if (e.nativeEvent.isComposing) return; if (e.key === 'Enter') (e.target as HTMLInputElement).blur(); if (e.key === 'Escape') { e.stopPropagation(); setEdit(false) } }}
            className="ring-focus h-7 w-56 rounded-md border border-control bg-paper px-2 text-[14px] outline-none" />
        ) : (
          <button onDoubleClick={() => setEdit(true)} title="双击重命名" className="min-w-0 text-left">
            <div className="text-[14px] font-medium truncate leading-5">{s.title}</div>
          </button>
        )}
        {!narrow && <span className="font-mono text-[11.5px] text-ink-2 truncate min-w-0" title={ws.path}>{elide(ws.path)}{ws.readOnly ? ' · 只读' : ''}</span>}
        <Status tone={ph.tone} pulse={ph.pulse}>{ph.label}</Status>
      </div>
      <div className="relative">
        <Button size="sm" variant={menu ? 'outline' : 'quiet'} icon="panel" aria-haspopup="menu" aria-expanded={menu} onClick={() => setMenu(!menu)} title="面板 · Alt+\">{narrow ? '' : `面板 ${groups(s.layout.root).reduce((n, g) => n + g.tabs.length, 0)}`}</Button>
        {menu && <PanelMenu s={s} op={op} close={() => setMenu(false)} />}
      </div>
    </header>
  )
}

/** add / show / close modules and restore recently closed ones — the keyboard path to everything drag does */
function PanelMenu({ s, op, close }: { s: Session; op: (o: Op) => void; close: () => void }) {
  const ref = useRef<HTMLDivElement>(null)
  const avail = moduleAvail(s)
  const L = s.layout
  const single = groups(L.root).length === 1 && groups(L.root)[0].tabs.length === 1
  useEffect(() => {
    ref.current?.querySelector<HTMLButtonElement>('button:not(:disabled)')?.focus()
    const h = (e: PointerEvent) => { if (!ref.current?.parentElement?.contains(e.target as Node)) close() }
    window.addEventListener('pointerdown', h, true)
    return () => window.removeEventListener('pointerdown', h, true)
  }, [])
  const nav = (e: React.KeyboardEvent) => {
    const items = [...(ref.current?.querySelectorAll<HTMLButtonElement>('button:not(:disabled)') ?? [])]
    const i = items.indexOf(document.activeElement as HTMLButtonElement)
    if (e.key === 'ArrowDown') { e.preventDefault(); items[(i + 1) % items.length]?.focus() }
    if (e.key === 'ArrowUp') { e.preventDefault(); items[(i - 1 + items.length) % items.length]?.focus() }
    if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); close() }
  }
  const run = (o: Op) => { op(o); close() }
  const order: ModuleId[] = ['chat', 'changes', 'preview', 'deliver', 'log', 'context', 'caps']
  return (
    <div ref={ref} role="menu" aria-label="面板" onKeyDown={nav} className="anim-rise absolute right-0 top-full mt-1.5 w-[300px] rounded-xl bg-paper border border-silver shadow-lg p-1 text-[12.5px]">
      <div className="px-2.5 pt-1.5 pb-1 text-[11px] text-ink-2">打开或显示</div>
      {order.map(m => {
        const why = avail[m]
        const open = isOpen(L, m), shown = isShown(L, m)
        return (
          <div key={m} className="flex items-center gap-0.5">
            <button role="menuitemcheckbox" aria-checked={open} disabled={!!why && !open} onClick={() => run({ op: 'open', m })}
              className="ring-focus flex-1 min-w-0 h-8 px-2.5 rounded-md flex items-center gap-2 hover:bg-muted disabled:opacity-45 disabled:hover:bg-transparent text-left">
              <span className="w-3.5 shrink-0">{open && <Icon name="check" size={12} className="text-mint-ink" />}</span>
              <Icon name={MODULES[m].icon} size={13} className="text-control" />
              <span className="truncate">{MODULES[m].label}</span>
              <span className="ml-auto text-[11px] text-ink-2 truncate">{why && !open ? why : open ? (shown ? '显示中' : '在标签组里') : ''}</span>
            </button>
            {!open && !why && <>
              <button onClick={() => run({ op: 'open', m, edge: 'right' })} aria-label={`在右侧拆分打开${MODULES[m].label}`} title="在对话右侧拆分打开" className="ring-focus size-8 rounded-md grid place-items-center text-ink-2 hover:bg-muted hover:text-ink"><SplitGlyph dir="row" /></button>
              <button onClick={() => run({ op: 'open', m, edge: 'bottom' })} aria-label={`在下方拆分打开${MODULES[m].label}`} title="在对话下方拆分打开" className="ring-focus size-8 rounded-md grid place-items-center text-ink-2 hover:bg-muted hover:text-ink"><SplitGlyph dir="col" /></button>
            </>}
            {open && <button disabled={single} onClick={() => run({ op: 'close', m })} aria-label={`关闭${MODULES[m].label}面板`} title={single ? '至少保留一个面板' : '关闭 · 不影响任务与会话'} className="ring-focus size-8 rounded-md grid place-items-center text-ink-2 hover:bg-muted hover:text-ink disabled:opacity-30"><Icon name="x" size={11} /></button>}
          </div>
        )
      })}
      {L.recent.filter(m => !isOpen(L, m)).length > 0 && <>
        <div className="mx-2 my-1 h-px bg-silver/70" />
        <div className="px-2.5 pt-1 pb-1 text-[11px] text-ink-2">最近关闭</div>
        <div className="flex flex-wrap gap-1 px-2 pb-1.5">
          {L.recent.filter(m => !isOpen(L, m)).map(m => <button key={m} onClick={() => run({ op: 'open', m })} className="ring-focus h-7 px-2 rounded-md border border-silver hover:border-control inline-flex items-center gap-1.5"><Icon name="undo" size={11} />{MODULES[m].label}</button>)}
        </div>
      </>}
      <div className="mx-2 my-1 h-px bg-silver/70" />
      <button onClick={() => run({ op: 'reset' })} className="ring-focus w-full h-8 px-2.5 rounded-md text-left hover:bg-muted flex items-center gap-2"><Icon name="refresh" size={12} className="text-control" />复位为只有对话<span className="ml-auto text-[11px] text-ink-2">任务不受影响</span></button>
      <p className="px-2.5 py-1.5 text-[11px] leading-4 text-ink-2">拖动标签可拆分、合并、移动；标签的 ⋯ 菜单或 Shift+F10 提供同样操作。每个会话各自记住布局。</p>
    </div>
  )
}
const SplitGlyph = ({ dir }: { dir: 'row' | 'col' }) => (
  <svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.3" aria-hidden><rect x="2.5" y="3" width="11" height="10" rx="1.5" />{dir === 'row' ? <path d="M8 3v10" /> : <path d="M2.5 8h11" />}</svg>
)

/* ───────────────────────── conversation ───────────────────────── */

function Conversation(p: Props & { compact: boolean }) {
  const { s, compact, short } = p
  const ref = useRef<HTMLDivElement>(null)
  const len = s.blocks.length
  const pinned = useRef(true)
  // follow new output only while the reader is already at the bottom — scrolling up to reread is never interrupted
  useEffect(() => { if (pinned.current) ref.current?.scrollTo({ top: ref.current.scrollHeight, behavior: 'smooth' }) }, [len, s.phase])
  if (!s.blocks.length) return <EmptySession {...p} />
  return (
    <div ref={ref} onScroll={e => { const t = e.currentTarget; pinned.current = t.scrollHeight - t.scrollTop - t.clientHeight < 80 }} className="flex-1 min-h-0 overflow-auto scroll-quiet">
      <div className={`mx-auto w-full max-w-[720px] flex flex-col gap-4 px-4 @lg:px-6 ${short ? 'py-4' : 'py-6'}`}>
        {s.blocks.map(b => <BlockView key={b.id} b={b} {...p} />)}
        {(Object.keys(s.hunks).length > 0 || (SCRIPTS[s.script].kind === 'report' && POST.includes(s.phase))) && <TaskCard s={s} dispatch={p.dispatch} />}
      </div>
    </div>
  )
}

function EmptySession({ s, ws, dispatch, composerRef, short }: Props) {
  const sc = SCRIPTS[s.script]
  const starters = [sc.ask, ws.readOnly ? '这个文件夹里有哪些内容？只读，不要改动。' : `${ws.name} 里最近改动最多的模块是哪个？`]
  return (
    <div className="flex-1 min-h-0 overflow-auto scroll-quiet grid place-items-center px-6">
      <div className={`max-w-[560px] w-full ${short ? 'py-4' : 'py-10'}`}>
        <div className="flex items-end gap-5 mb-6">
          <div className="flex-1">
            <div className="text-[12px] text-ink-2 mb-2 font-mono truncate">{elide(ws.path, 60)}</div>
            <h2 className="font-serif font-medium text-[22px] leading-8">说说你想完成什么</h2>
          </div>
          {!short && <QuietSlot seed={s.id} compact />}
        </div>
        <div className="flex flex-col gap-2">
          {starters.map(t => (
            <button key={t} onClick={() => { dispatch({ t: 'draft', text: t }); composerRef.current?.focus() }}
              className="ring-focus text-left rounded-xl border border-silver bg-paper px-4 py-3 text-[14px] leading-[22px] hover:border-control flex gap-3">
              <Icon name="sparkle" size={14} className="mt-1 text-control" /><span>{t}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  )
}

function BlockView(p: Props & { b: Block; compact: boolean }) {
  const { b } = p
  if (b.kind === 'user') return (
    <div className="self-end max-w-[86%] flex flex-col items-end gap-1">
      <div className="rounded-2xl rounded-br-md bg-muted px-4 py-2.5 text-[14px] leading-[22px] whitespace-pre-wrap break-words">{b.text}</div>
      {b.supplement && <span className="text-[11px] text-ink-2 inline-flex items-center gap-1">{b.supplement === 'queued' ? <><Icon name="clock" size={11} />补充说明 · 将在下一步读取</> : <><Icon name="check" size={11} />补充说明 · 已读取</>}</span>}
    </div>
  )
  if (b.kind === 'agent') return (
    <div className="flex gap-3">
      <span className="size-6 rounded-full bg-navy text-paper grid place-items-center shrink-0 mt-0.5"><Icon name="sparkle" size={12} /></span>
      <div className="flex-1 min-w-0">
        <p className="text-[14.5px] leading-6">{b.text}</p>
      </div>
    </div>
  )
  if (b.kind === 'notice') {
    const tone = { neutral: 'border-silver bg-paper text-ink-2', warn: 'border-gold/50 bg-gold-soft/60 text-[#6d5436]', bad: 'border-berry/30 bg-rose/50 text-berry', ok: 'border-mint-2 bg-mint/60 text-mint-ink' }[b.tone]
    return <div role={b.tone === 'bad' ? 'alert' : undefined} className={`rounded-lg border px-3 py-2 text-[13px] leading-5 flex gap-2 ${tone}`}><Icon name={b.tone === 'bad' ? 'alert' : b.tone === 'ok' ? 'check' : 'info'} size={14} className="mt-[3px]" /><span>{b.text}</span></div>
  }
  if (b.kind === 'permission') return <PermissionCard {...p} b={b} />
  return <RunCard {...p} b={b} />
}

function Card({ title, icon, state, children, dim }: { title: string; icon: string; state?: React.ReactNode; children: React.ReactNode; dim?: boolean }) {
  return (
    <section className={`rounded-xl border bg-paper ${dim ? 'border-silver/60 opacity-70' : 'border-silver'}`}>
      <div className="flex items-center gap-2 px-4 h-10 border-b border-silver/60">
        <Icon name={icon} size={14} className="text-control" />
        <h3 className="text-[13px] font-medium flex-1">{title}</h3>
        {state}
      </div>
      <div className="px-4 py-3">{children}</div>
    </section>
  )
}

const PERM_WORD: Record<string, string> = { write: '写入文件', exec: '运行命令' }

/** Inline, one decision, only when a step actually needs it — the way a normal agent asks. */
function PermissionCard({ s, b, dispatch, setGrant }: Props & { b: Extract<Block, { kind: 'permission' }> }) {
  const pm = SCRIPTS[s.script].perms.find(x => x.id === b.perm)
  const step = SCRIPTS[s.script].steps[b.step]
  const open = b.state === 'open' && s.phase === 'permission'
  const done = { once: '已允许一次', session: '本会话允许', always: '已始终允许', deny: '已拒绝' } as const
  if (!open) return (
    <div className="text-[12px] text-ink-2 pl-1 inline-flex items-center gap-1.5">
      <Icon name={b.state === 'deny' ? 'x' : 'shield'} size={12} />{PERM_WORD[b.perm]} · {b.state === 'open' ? '已跳过' : done[b.state]}
      {b.state === 'deny' && s.phase === 'denied' && b === [...s.blocks].reverse().find(x => x.kind === 'permission') &&
        <button onClick={() => dispatch({ t: 'rerequest' })} className="ring-focus ml-1 underline hover:text-ink">重新决定</button>}
    </div>
  )
  return (
    <section role="alertdialog" aria-label={`允许${PERM_WORD[b.perm]}？`} className="rounded-xl border border-gold/60 bg-paper px-4 py-3">
      <div className="flex items-start gap-2.5">
        <Icon name={pm?.icon ?? 'shield'} size={15} className="mt-[3px] text-control" />
        <div className="min-w-0 flex-1">
          <div className="text-[13.5px] font-medium">允许{PERM_WORD[b.perm]}？</div>
          <div className="text-[12.5px] text-ink-2 leading-5 mt-0.5"><span className="font-mono text-[12px] bg-canvas rounded px-1 break-all">{step?.label ?? pm?.object}</span>{pm && <> · {pm.scope}</>}</div>
        </div>
      </div>
      <div className="flex flex-wrap gap-1.5 mt-3 pl-[26px]">
        <Button size="sm" variant="primary" onClick={() => dispatch({ t: 'perm', v: 'once' })}>允许一次</Button>
        <Button size="sm" onClick={() => dispatch({ t: 'perm', v: 'session' })}>本会话允许</Button>
        <Button size="sm" variant="quiet" onClick={() => { setGrant(b.perm, true); dispatch({ t: 'perm', v: 'always' }) }}>始终允许</Button>
        <Button size="sm" variant="quiet" className="ml-auto" onClick={() => dispatch({ t: 'perm', v: 'deny' })}>拒绝</Button>
      </div>
    </section>
  )
}

function ModelMenu({ s, dispatch }: { s: Session; dispatch: (a: Action) => void }) {
  const [open, setOpen] = useState(false)
  const ref = useRef<HTMLDivElement>(null)
  useEffect(() => {
    if (!open) return
    const h = (e: MouseEvent) => { if (!ref.current?.contains(e.target as Node)) setOpen(false) }
    window.addEventListener('mousedown', h); return () => window.removeEventListener('mousedown', h)
  }, [open])
  const cur = MODELS.find(m => m.id === s.model) ?? MODELS[1]
  return (
    <div ref={ref} className="relative">
      <button onClick={() => setOpen(o => !o)} aria-haspopup="menu" aria-expanded={open} aria-label={`模型：${cur.name}`} title="模型（演示，不会调用）"
        className="ring-focus inline-flex items-center gap-1 h-6 px-2 rounded-md text-[11.5px] text-ink-2 hover:text-ink hover:bg-canvas">
        {cur.name}<Icon name="chevron" size={10} className="rotate-90 opacity-60" />
      </button>
      {open && (
        <div role="menu" aria-label="模型" onKeyDown={e => { if (e.key === 'Escape') { e.stopPropagation(); setOpen(false) } }}
          className="anim-rise absolute bottom-full right-0 mb-2 w-60 rounded-xl bg-paper border border-silver shadow-lg p-1 z-20">
          {MODELS.map(m => (
            <button key={m.id} role="menuitemradio" aria-checked={cur.id === m.id} autoFocus={cur.id === m.id}
              onClick={() => { dispatch({ t: 'model', v: m.id }); setOpen(false) }}
              className={`ring-focus w-full text-left px-2.5 py-1.5 rounded-md flex items-center gap-2.5 hover:bg-muted ${cur.id === m.id ? 'bg-muted' : ''}`}>
              <span className="flex-1"><span className="block text-[12.5px] text-ink">{m.name}</span><span className="block text-[11px] text-ink-2">{m.note}</span></span>
              {cur.id === m.id && <Icon name="check" size={12} className="text-mint-ink" />}
            </button>
          ))}
          <div className="px-2.5 pt-1.5 pb-1 mt-1 border-t border-silver/60 text-[10.5px] font-mono text-ink-2">演示列表 · 原型不调用模型</div>
        </div>
      )}
    </div>
  )
}

const MODES: [PermMode, string, string, string][] = [
  ['read', '只读', 'eye', '只读取和分析，写入前停下'],
  ['ask', '写入前询问', 'shield', '写文件、跑命令前问你'],
  ['auto', '自动', 'bolt', '不再询问（仍在模拟环境）'],
]

function PermMenu({ s, dispatch }: { s: Session; dispatch: (a: Action) => void }) {
  const [open, setOpen] = useState(false)
  const ref = useRef<HTMLDivElement>(null)
  useEffect(() => {
    if (!open) return
    const h = (e: MouseEvent) => { if (!ref.current?.contains(e.target as Node)) setOpen(false) }
    window.addEventListener('mousedown', h); return () => window.removeEventListener('mousedown', h)
  }, [open])
  const cur = MODES.find(m => m[0] === s.permMode) ?? MODES[1]
  return (
    <div ref={ref} className="relative">
      <button onClick={() => setOpen(o => !o)} aria-haspopup="menu" aria-expanded={open} aria-label={`权限：${cur[1]}`}
        className={`ring-focus inline-flex items-center gap-1 h-6 px-2 rounded-md text-[11.5px] hover:text-ink ${s.permMode === 'auto' ? 'bg-gold-soft text-[#6d5436]' : 'bg-canvas text-ink-2'}`}>
        <Icon name={cur[2]} size={12} />{cur[1]}<Icon name="chevron" size={10} className="rotate-90 opacity-60" />
      </button>
      {open && (
        <div role="menu" aria-label="权限" onKeyDown={e => { if (e.key === 'Escape') { e.stopPropagation(); setOpen(false) } }}
          className="anim-rise absolute bottom-full left-0 mb-2 w-60 rounded-xl bg-paper border border-silver shadow-lg p-1 z-20">
          {MODES.map(([k, l, ic, d], i) => (
            <button key={k} role="menuitemradio" aria-checked={s.permMode === k} autoFocus={s.permMode === k || (i === 1 && !MODES.some(m => m[0] === s.permMode))}
              onClick={() => { dispatch({ t: 'permMode', v: k }); setOpen(false) }}
              className={`ring-focus w-full text-left px-2.5 py-1.5 rounded-md flex gap-2.5 hover:bg-muted ${s.permMode === k ? 'bg-muted' : ''}`}>
              <Icon name={ic} size={13} className="mt-[3px] text-control" />
              <span className="flex-1"><span className="block text-[12.5px] text-ink">{l}</span><span className="block text-[11px] text-ink-2">{d}</span></span>
              {s.permMode === k && <Icon name="check" size={12} className="mt-[3px] text-mint-ink" />}
            </button>
          ))}
        </div>
      )}
    </div>
  )
}

function RunCard({ s, b, dispatch, stopArmed, armStop }: Props & { b: Extract<Block, { kind: 'run' }> }) {
  const sc = SCRIPTS[s.script]
  const last = b === [...s.blocks].reverse().find(x => x.kind === 'run')
  const [log, setLog] = useState<number | null>(null)
  const live = last && s.phase !== 'empty'
  const failed = live && s.phase === 'failed'
  const unknown = live && (s.phase === 'disconnected' || s.phase === 'checking') ? s.unknownStep : undefined
  const status = (i: number) => {
    if (!live) return i < sc.steps.length ? 'done' : 'todo'
    if (failed && i === s.failedStep) return 'fail'
    if (unknown === i) return 'unknown'
    if (i < s.step) return 'done'
    if (i === s.step && (s.phase === 'running' || s.phase === 'stopping')) return 'now'
    return 'todo'
  }
  const done = live ? Math.min(s.step, sc.steps.length) : sc.steps.length
  return (
    <Card title={`执行 · 第 ${b.attempt} 次`} icon="terminal" dim={!last}
      state={<span className="inline-flex items-center gap-2"><span className="font-mono text-[11.5px] text-ink-2">{done}/{sc.steps.length}</span>{last && <button onClick={() => dispatch({ t: 'layout', o: { op: 'open', m: 'log' } })} className="ring-focus text-[11.5px] text-ink-2 hover:text-ink inline-flex items-center gap-1" title="在面板中打开执行日志"><Icon name="terminal" size={11} />日志</button>}</span>}>
      <ol className="flex flex-col">
        {sc.steps.map((st, i) => {
          const k = status(i)
          const dot = { done: <Icon name="check" size={12} className="text-mint-ink" />, now: <span className="size-2 rounded-full bg-navy anim-pulse" />, fail: <Icon name="x" size={12} className="text-berry" />, unknown: <span className="text-[11px] font-bold text-[#7a5f3e]">?</span>, todo: <span className="size-1.5 rounded-full bg-silver" /> }[k]
          const lines = k === 'fail' ? sc.failLog : st.log
          const canLog = k === 'done' || k === 'fail' || k === 'now'
          return (
            <li key={i} className="relative pl-7 py-1.5">
              <span className="absolute left-0 top-[9px] size-[18px] rounded-full grid place-items-center bg-canvas">{dot}</span>
              <button disabled={!canLog} onClick={() => setLog(log === i ? null : i)} className="ring-focus w-full text-left flex items-baseline gap-2 disabled:cursor-default">
                <span className={`text-[13.5px] ${k === 'todo' ? 'text-ink-2' : ''} ${k === 'fail' ? 'text-berry' : ''}`}>{st.label}</span>
                <span className="text-[11.5px] text-ink-2 truncate">{k === 'unknown' ? '结果未知' : st.detail.replace('{rev}', String(s.intentRev))}</span>
                {canLog && <Icon name="down" size={11} className={`ml-auto text-control transition ${log === i ? 'rotate-180' : ''}`} />}
              </button>
              {st.writes && k === 'done' && <div className="mt-1 flex flex-wrap gap-1">{st.writes.map(w => <span key={w} className="font-mono text-[11px] rounded bg-mint/60 text-mint-ink px-1.5 py-0.5">中间产物 · {w}</span>)}</div>}
              {log === i && <pre className="mt-1.5 rounded-lg bg-ink text-[#e6e4de] text-[11.5px] leading-[18px] font-mono px-3 py-2 overflow-x-auto scroll-quiet">{lines.join('\n')}</pre>}
            </li>
          )
        })}
      </ol>

      {live && s.phase === 'running' && (
        <div className="mt-3 pt-3 border-t border-silver/60 flex flex-wrap items-center gap-2">
          {stopArmed ? (
            <>
              <span className="text-[12.5px]">停止后已写入的文件保留在快照中。确定停止？</span>
              <Button size="sm" variant="danger" icon="stop" autoFocus onClick={() => { dispatch({ t: 'stop' }); armStop(false) }}>确定停止</Button>
              <Button size="sm" variant="quiet" onClick={() => armStop(false)}>继续运行</Button>
            </>
          ) : (
            <>
              <Button size="sm" icon="stop" onClick={() => armStop(true)}>停止…</Button>
              <span className="text-[11.5px] text-ink-2">或连按两次 <Kbd>Esc</Kbd> · 可以随时在下方补充说明</span>
            </>
          )}
        </div>
      )}
      {live && s.phase === 'stopping' && <Footer><Status tone="warn" pulse>已请求停止，等待执行器确认当前步骤结束</Status></Footer>}
      {live && s.phase === 'disconnected' && (
        <Footer>
          <span className="text-[12.5px] flex-1 min-w-[200px]">不会自动重放。重新连接后，我会先核对第 {(s.unknownStep ?? 0) + 1} 步的真实结果。</span>
          <Button size="sm" variant="primary" icon="wifi" onClick={() => dispatch({ t: 'reconnect' })}>重新连接并核对</Button>
        </Footer>
      )}
      {live && s.phase === 'checking' && <Footer><Status tone="warn" pulse>正在核对快照与工作区…</Status></Footer>}
      {live && s.phase === 'reconciled' && (
        <Footer>
          <Button size="sm" variant="primary" onClick={() => dispatch({ t: 'resume', from: 'next' })}>从第 {s.step + 1} 步继续</Button>
          {s.reconciledDone && <Button size="sm" onClick={() => dispatch({ t: 'resume', from: 'redo' })}>重做第 {(s.unknownStep ?? s.step - 1) + 1} 步</Button>}
          <span className="text-[11.5px] text-ink-2">选择之前任务保持暂停</span>
        </Footer>
      )}
      {failed && (
        <Footer>
          <Button size="sm" variant="quiet" icon="eye" onClick={() => setLog(s.failedStep ?? null)}>查看原因</Button>
          <Button size="sm" variant="primary" icon="bolt" onClick={() => dispatch({ t: 'fix' })}>让 Agent 修复</Button>
          <Button size="sm" icon="refresh" onClick={() => dispatch({ t: 'retry' })}>原样重试</Button>
          <Button size="sm" variant="quiet" onClick={() => dispatch({ t: 'takeover' })}>我来接手</Button>
        </Footer>
      )}
      {live && s.phase === 'stopped' && !s.handoff && s.step < sc.steps.length && (
        <Footer><Button size="sm" onClick={() => dispatch({ t: 'resume', from: 'next' })}>从第 {s.step + 1} 步继续</Button></Footer>
      )}
    </Card>
  )
}
const Footer = ({ children }: { children: React.ReactNode }) => <div className="mt-3 pt-3 border-t border-silver/60 flex flex-wrap items-center gap-2">{children}</div>

/* ───────────────────────── composer ───────────────────────── */

function Composer({ s, dispatch, enterSends, onTyping, composerRef, compact, short, grants }: Props & { compact: boolean }) {
  const composing = useRef(false)
  const sentAt = useRef(0)
  const active = isActive(s)
  const send = () => {
    if (!s.draft.trim() || Date.now() - sentAt.current < 600 || s.phase === 'stopping') return
    sentAt.current = Date.now()
    dispatch({ t: 'send', text: s.draft, remembered: grants })
  }
  const ph = active ? '补充说明，下一步读取' : s.blocks.length ? '继续提要求…' : '描述任务…'
  return (
    <div className={`shrink-0 px-3 @lg:px-6 ${short ? 'pb-2.5' : 'pb-4'}`}>
      <div data-zone="composer" className={`mx-auto max-w-[720px] rounded-2xl border border-silver bg-paper focus-within:border-control shadow-[0_1px_0_rgba(44,53,71,.04)]`}>
        <textarea ref={composerRef} value={s.draft} rows={short ? 1 : 2} aria-label="输入消息" placeholder={ph}
          onChange={e => dispatch({ t: 'draft', text: e.target.value })}
          onFocus={() => onTyping(true)} onBlur={() => onTyping(false)}
          onCompositionStart={() => (composing.current = true)} onCompositionEnd={() => (composing.current = false)}
          onKeyDown={e => {
            if (e.nativeEvent.isComposing || composing.current || e.keyCode === 229) return // IME guard
            if (e.key === 'Escape') { (e.target as HTMLTextAreaElement).blur(); return }
            if (e.key !== 'Enter') return
            const wants = enterSends ? !e.shiftKey && !e.ctrlKey : e.ctrlKey || e.metaKey
            if (wants) { e.preventDefault(); send() }
          }}
          className="block w-full resize-none bg-transparent px-4 pt-3 text-[14.5px] leading-[22px] outline-none placeholder:text-control max-h-40 scroll-quiet" />
        <div className="flex flex-wrap items-center gap-x-2 gap-y-1 px-3 pb-2.5 pt-1 [&_button]:whitespace-nowrap">
          <PermMenu s={s} dispatch={dispatch} />
          <button onClick={() => dispatch({ t: 'layout', o: { op: 'open', m: 'context' } })} title="在面板中查看上下文" className="ring-focus inline-flex items-center gap-1 h-6 px-2 rounded-md bg-canvas hover:bg-muted text-[11.5px] text-ink-2 hover:text-ink"><Icon name="layers" size={12} />{s.context.filter(c => c.state === 'in').length} 项上下文</button>
          <span className="flex-1" />
          <ModelMenu s={s} dispatch={dispatch} />
          <span className="hidden @2xl:inline text-[11px] text-ink-2 whitespace-nowrap">{enterSends ? <><Kbd>Enter</Kbd> 发送 · <Kbd>Shift</Kbd>+<Kbd>Enter</Kbd> 换行</> : <><Kbd>Ctrl</Kbd>+<Kbd>Enter</Kbd> 发送</>}</span>
          <Button size="sm" variant="primary" icon="send" onClick={send} disabled={!s.draft.trim() || s.phase === 'stopping'} aria-label={active ? '发送补充说明' : '发送'}>{active ? '补充' : ''}</Button>
        </div>
      </div>
    </div>
  )
}

/* ───────────────────────── task card · the one entry point into review / delivery ───────────────────────── */

/** Stage names say what the stage *is*; only a finished stage says it was achieved ("待审阅" → "审阅通过").
    Code tasks go through review → apply; reports skip both — they are previewed and checked. */
function stageStates(s: Session) {
  const at = (ph: string[]) => ph.includes(s.phase)
  const report = SCRIPTS[s.script].kind === 'report'
  const partial = s.phase === 'verified' && !s.manualOk
  const done = (ok: boolean, now: boolean, yes: string, todo: string, doing = todo) => ({ l: ok ? yes : now ? doing : todo, st: ok ? 'ok' : now ? 'now' : 'todo' })
  const verify = partial ? { l: '自动项通过 · 待人工确认', st: 'partial' } : s.phase === 'verifyFailed' ? { l: '验收未通过', st: 'fail' }
    : done(at(['verified', 'delivered']), s.phase === 'verifying', '验收通过', '待验收', '验收中')
  const out = [
    ...(report ? [done(at(['applied', 'verifying', 'verifyFailed', 'verified', 'delivered']), s.phase === 'running', '报表已生成', '待生成', '生成中')] : [
      done(at(['applying', 'applied', 'verifying', 'verifyFailed', 'verified', 'delivered']), at(['review', 'revising']), '审阅通过', '待审阅', s.phase === 'revising' ? '修订中' : '审阅中'),
      done(at(['applied', 'verifying', 'verifyFailed', 'verified', 'delivered']), s.phase === 'applying', '已应用（模拟）', '待应用', '应用中'),
    ]),
    verify,
    done(s.phase === 'delivered', false, '已交付', '待交付'),
  ]
  return out as { l: string; st: 'ok' | 'now' | 'partial' | 'fail' | 'todo' }[]
}

function Stages({ s, dense }: { s: Session; dense?: boolean }) {
  const look = { ok: 'border-mint-2 bg-mint/50 text-mint-ink', now: 'border-control bg-paper text-ink', partial: 'border-gold bg-gold-soft/60 text-ink', fail: 'border-berry/40 bg-rose/50 text-berry', todo: 'border-dashed border-silver bg-paper text-ink-2' }
  const st = stageStates(s)
  const cols = st.length === 3 ? (dense ? 'grid-cols-3' : 'grid-cols-3') : dense ? 'grid-cols-2 @md:grid-cols-4' : 'grid-cols-2 @lg:grid-cols-4'
  return (
    <ol className={`grid gap-1.5 ${cols}`} aria-label="结果进度">
      {st.map(({ l, st }, i) => (
        <li key={i} className={`rounded-lg border ${dense ? 'px-2.5 py-1.5' : 'px-3 py-2'} ${look[st]}`}>
          <div className="text-[10.5px] font-mono opacity-70">0{i + 1}</div>
          <div className={`${dense ? 'text-[12px]' : 'text-[13px]'} font-medium leading-[18px]`}>
            {st === 'ok' && <Icon name="check" size={11} className="inline mr-1 -mt-0.5" />}
            {st === 'now' && <span className="inline-block size-1.5 rounded-full bg-navy anim-pulse mr-1.5 align-middle" />}{l}
          </div>
        </li>
      ))}
    </ol>
  )
}

/** The result entry in the conversation. It only says what is next and offers entries; it never opens anything by itself. */
function TaskCard({ s, dispatch }: { s: Session; dispatch: (a: Action) => void }) {
  const sc = SCRIPTS[s.script]
  const report = sc.kind === 'report'
  const hs = currentHunks(s)
  const v = Object.values(s.hunks)
  const pen = v.filter(x => x === 'pending').length, acc = v.filter(x => x === 'accepted').length
  const files = new Set(hs.map(h => h.file)).size
  const L = s.layout
  const next: ModuleId = ['review', 'revising'].includes(s.phase) ? 'changes' : 'deliver'
  const passed = sc.checks.filter(c => s.checks[c.id] === 'pass' || (c.manual && s.manualOk)).length
  const hint = {
    review: pen ? `v${s.version} 有 ${pen} 处待你决定` : `v${s.version} 已全部判定，可以应用或退回修改`,
    revising: `正在按你的意见生成 v${s.version + 1}`,
    applying: '正在应用已接受的改动（模拟）',
    applied: report ? '报表已生成 · 尚未验收' : `已应用 ${s.applied.length} 处（模拟）· 尚未验收`,
    verifying: '正在逐项验收',
    verifyFailed: '验收未通过 · 需要修复或接手',
    verified: s.manualOk ? '全部标准已满足 · 可以交付' : '自动项已通过 · 还差一项人工确认',
    delivered: `v${s.version} 已交付 · ${passed}/${sc.checks.length} 项验收有记录`,
  }[s.phase as string] ?? `v${s.version} · 已接受 ${acc} 处`
  // called as a function, not <Entry/>: a component defined here would remount on every render and drop the click
  const entry = ({ m, icon, label, primary, preview }: { m: ModuleId; icon: string; label: string; primary?: boolean; preview?: string }) => {
    const shown = isShown(L, m) && (!preview || L.preview === preview)
    return (
      <Button key={m} size="sm" variant={shown ? 'outline' : primary ? 'primary' : 'quiet'} icon={icon} aria-pressed={shown}
        title={shown ? '定位到这个面板' : isOpen(L, m) ? '切换到这个面板' : '在面板中打开，对话保持不变'}
        onClick={() => dispatch({ t: 'layout', o: { op: 'open', m, preview } })}>
        {label}
      </Button>
    )
  }
  return (
    <section aria-label="本轮结果" className="@container rounded-2xl border border-silver bg-paper px-4 py-3.5 flex flex-col gap-3">
      <div className="flex items-baseline gap-2 flex-wrap">
        <Icon name={report ? 'file' : 'box'} size={14} className="text-control self-center" />
        <h3 className="text-[13.5px] font-medium">{report ? '报表' : '本轮结果'} · v{s.version}</h3>
        <span className="text-[12.5px] text-ink-2" aria-live="polite">{hint}</span>
      </div>
      <Stages s={s} dense />
      {report && (
        <ul className="flex flex-col gap-1">
          {sc.artifacts.map(a => (
            <li key={a.id}>
              <button onClick={() => dispatch({ t: 'layout', o: { op: 'open', m: 'preview', preview: a.id } })}
                className="ring-focus w-full text-left rounded-lg border border-silver hover:border-control px-3 py-2 flex items-center gap-3">
                <Icon name="file" size={14} className="text-control" />
                <span className="text-[13px] flex-1 min-w-0 truncate">{a.name}</span>
                <span className="text-[11.5px] text-ink-2 shrink-0">{a.type} · {a.size}</span>
                <span className="text-[12px] text-mint-ink shrink-0">预览</span>
              </button>
            </li>
          ))}
        </ul>
      )}
      <div className="flex flex-wrap gap-1.5">
        {!report && entry({ m: 'changes', icon: 'diff', label: `查看改动 · ${hs.length} 处`, primary: next === 'changes' })}
        {entry({ m: 'deliver', icon: 'flask', label: s.phase === 'delivered' ? '验收记录与证据' : '验收与交付', primary: next === 'deliver' && s.phase !== 'delivered' })}
        {!report && entry({ m: 'preview', icon: 'file', label: `打开产物 · ${sc.artifacts.length}` })}
        {entry({ m: 'log', icon: 'terminal', label: '执行日志' })}
      </div>
    </section>
  )
}

/* ───────────────────────── review ───────────────────────── */

export function ReviewPane({ s, dispatch }: { s: Session; dispatch: (a: Action) => void }) {
  const hunks = currentHunks(s)
  const can = s.phase === 'review'
  const v = Object.values(s.hunks)
  const n = { acc: v.filter(x => x === 'accepted').length, rej: v.filter(x => x === 'rejected').length, pen: v.filter(x => x === 'pending').length }
  const [note, setNote] = useState<string | null>(null)
  const [text, setText] = useState('')
  const vOf = (id: string) => Number(Object.entries(SCRIPTS[s.script].versions).find(([, hs]) => hs.some(h => h.id === id))?.[0] ?? 1)
  return (
    <div className="flex-1 min-h-0 flex flex-col">
      <div className="shrink-0 px-4 min-h-11 py-1.5 flex flex-wrap items-center gap-x-3 gap-y-1 border-b border-silver/70">
        <span className="text-[13px] font-medium">审阅 v{s.version}</span>
        <span className="text-[12px] text-ink-2">{hunks.length} 处 · 已接受 {n.acc} · 已退回 {n.rej} · 待定 {n.pen}</span>
        <span className="flex-1" />
        {!can && <Status tone="local">{s.phase === 'revising' ? `正在生成 v${s.version + 1}` : '审阅已提交 · 只读'}</Status>}
        {!can && s.phase !== 'revising' && <Button size="sm" variant="quiet" icon="flask" onClick={() => dispatch({ t: 'layout', o: { op: 'open', m: 'deliver' } })}>验收与交付</Button>}
        {can && n.pen > 0 && <Button size="sm" variant="quiet" onClick={() => dispatch({ t: 'hunkAll', v: 'accepted' })}>接受其余 {n.pen} 处</Button>}
      </div>
      <div className="flex-1 min-h-0 overflow-auto scroll-quiet px-4 py-4 flex flex-col gap-4">
        {hunks.map(h => {
          const st = s.hunks[h.id]
          return (
            <article key={h.id} className={`shrink-0 rounded-xl border bg-paper overflow-hidden ${st === 'accepted' ? 'border-mint-2' : st === 'rejected' ? 'border-berry/30' : 'border-silver'}`}>
              <div className="flex flex-wrap items-center gap-x-3 gap-y-1 px-4 py-2.5 border-b border-silver/60">
                <span className="font-mono text-[12px] break-all">{h.file}</span>
                <span className="font-mono text-[11px] text-ink-2">{h.range}</span>
                <span className="text-[10.5px] font-mono px-1.5 rounded bg-muted text-ink-2">v{vOf(h.id)}</span>
                <span className="flex-1" />
                {st === 'pending' ? <Status tone="neutral">待定</Status> : st === 'accepted' ? <Status tone="ok">已接受</Status> : <Status tone="bad">已退回</Status>}
              </div>
              <p className="px-4 pt-2.5 text-[13px] text-ink-2">{h.why}</p>
              <pre className="mx-4 my-2.5 rounded-lg bg-canvas font-mono text-[12px] leading-[19px] overflow-x-auto scroll-quiet py-1.5">
                {h.lines.map(([k, l], i) => (
                  <div key={i} className={`px-3 whitespace-pre ${k === '+' ? 'bg-mint/70 text-mint-ink' : k === '-' ? 'bg-rose/70 text-berry' : 'text-ink-2'}`}><span className="select-none inline-block w-4 opacity-60">{k}</span>{l}</div>
                ))}
              </pre>
              {s.rejectNotes[h.id] && st === 'rejected' && <p className="px-4 pb-2 text-[12.5px] text-berry">退回理由：{s.rejectNotes[h.id]}</p>}
              {can && (
                note === h.id ? (
                  <div className="px-4 pb-3 flex flex-wrap gap-2">
                    <input autoFocus value={text} onChange={e => setText(e.target.value)} placeholder="退回理由（可选），会作为修改意见" aria-label="退回理由"
                      onKeyDown={e => { if (e.nativeEvent.isComposing) return; if (e.key === 'Enter') { dispatch({ t: 'hunk', id: h.id, v: 'rejected', note: text }); setNote(null) } if (e.key === 'Escape') { e.stopPropagation(); setNote(null) } }}
                      className="ring-focus flex-1 min-w-[200px] h-8 rounded-md border border-silver bg-paper px-2.5 text-[13px] outline-none focus:border-control" />
                    <Button size="sm" variant="danger" onClick={() => { dispatch({ t: 'hunk', id: h.id, v: 'rejected', note: text }); setNote(null) }}>退回</Button>
                    <Button size="sm" variant="quiet" onClick={() => setNote(null)}>取消</Button>
                  </div>
                ) : (
                  <div className="px-4 pb-3 flex gap-2">
                    <Button size="sm" variant={st === 'accepted' ? 'mint' : 'outline'} icon="check" aria-pressed={st === 'accepted'} onClick={() => dispatch({ t: 'hunk', id: h.id, v: st === 'accepted' ? 'pending' : 'accepted' })}>{st === 'accepted' ? '已接受' : '接受'}</Button>
                    <Button size="sm" variant={st === 'rejected' ? 'danger' : 'quiet'} icon="undo" aria-pressed={st === 'rejected'} onClick={() => { if (st === 'rejected') dispatch({ t: 'hunk', id: h.id, v: 'pending', note: '' }); else { setText(''); setNote(h.id) } }}>{st === 'rejected' ? '撤销退回' : '退回…'}</Button>
                  </div>
                )
              )}
            </article>
          )
        })}
      </div>
      {can && (
        <div className="shrink-0 border-t border-silver/70 px-4 py-3 flex flex-wrap items-center gap-2 bg-canvas">
          <span className="text-[12px] text-ink-2 flex-1 min-w-[200px]">{n.pen ? `还有 ${n.pen} 处待定` : n.rej ? '可以只应用已接受的部分，或把退回的部分交回修改' : '全部已接受。应用后还需要验收。'}</span>
          <Button size="sm" disabled={n.pen > 0 || n.rej === 0} icon="undo" onClick={() => dispatch({ t: 'revise' })}>退回修改 {n.rej || ''}</Button>
          <Button size="sm" variant="primary" disabled={n.pen > 0 || n.acc === 0} onClick={() => dispatch({ t: 'apply' })}>{n.rej ? `仅应用已接受的 ${n.acc} 处` : `应用 ${n.acc} 处`}（模拟）</Button>
        </div>
      )}
    </div>
  )
}

/* ───────────────────────── deliver ───────────────────────── */

export function DeliverPane({ s, dispatch, ws }: { s: Session; dispatch: (a: Action) => void; ws: Workspace }) {
  const sc = SCRIPTS[s.script]
  const busy = ['applying', 'verifying', 'revising'].includes(s.phase)
  const report = sc.kind === 'report'
  const [ev, setEv] = useState<string | null>(null)
  if (!POST.includes(s.phase)) return <Unavailable text="这一轮还没有结果。完成后对话里会出现结果卡片，从那里进入验收。" />
  return (
    <div className="flex-1 min-h-0 overflow-auto scroll-quiet">
      <div className="px-4 py-4 flex flex-col gap-4">
        <Stages s={s} />

        {s.phase === 'review' || s.phase === 'revising' ? (
          <div className="rounded-xl border border-dashed border-silver px-5 py-6 text-[14px] text-ink-2">审阅还没有提交，交付不可用。<Button size="sm" className="ml-2" onClick={() => dispatch({ t: 'layout', o: { op: 'open', m: 'changes' } })}>打开改动</Button></div>
        ) : (
          <>
            <section className="rounded-xl border border-silver bg-paper">
              <div className="px-4 min-h-10 py-2 flex items-center border-b border-silver/60 gap-2"><Icon name="flask" size={14} className="text-control" /><h3 className="text-[13px] font-medium flex-1">验收标准</h3><span className="font-mono text-[11px] text-ink-2">v{s.version}</span></div>
              <ul className="divide-y divide-silver/60">
                {sc.checks.map(c => {
                  const st = s.checks[c.id] ?? 'idle'
                  const manualDone = c.manual && s.manualOk
                  return (
                    <li key={c.id} className="px-4 py-3 flex items-start gap-3">
                      <span className={`mt-0.5 size-5 rounded-full grid place-items-center shrink-0 ${st === 'pass' || manualDone ? 'bg-mint text-mint-ink' : st === 'fail' ? 'bg-rose text-berry' : 'bg-muted text-control'}`}>
                        {st === 'pass' || manualDone ? <Icon name="check" size={11} /> : st === 'fail' ? <Icon name="x" size={11} /> : s.phase === 'verifying' && !c.manual ? <span className="size-1.5 rounded-full bg-navy anim-pulse" /> : <span className="size-1.5 rounded-full bg-control" />}
                      </span>
                      <div className="flex-1 min-w-0">
                        <div className="text-[13.5px]">{c.label}</div>
                        <div className={`text-[12px] ${st === 'fail' ? 'text-berry' : 'text-ink-2'}`}>{st === 'fail' ? c.failText : st === 'idle' ? (c.manual ? '人工项 · 自动验收通过后由你确认' : '尚未运行') : c.how}</div>
                        {c.evidence && st !== 'idle' && (
                          <button onClick={() => setEv(ev === c.id ? null : c.id)} aria-expanded={ev === c.id} className="ring-focus mt-1 text-[11.5px] text-mint-ink hover:underline inline-flex items-center gap-1">
                            <Icon name="eye" size={11} />{ev === c.id ? '收起证据' : `证据 ${c.evidence.length} 条`}
                          </button>
                        )}
                        {ev === c.id && c.evidence && <ul className="mt-1.5 rounded-md bg-canvas px-2.5 py-1.5 font-mono text-[11px] leading-[18px] text-ink-2">{c.evidence.map(e => <li key={e}>· {e}</li>)}</ul>}
                      </div>
                      {c.manual && s.phase === 'verified' && (
                        <label className="inline-flex items-center gap-2 text-[12.5px] cursor-pointer">
                          <input type="checkbox" checked={s.manualOk} onChange={e => dispatch({ t: 'manual', v: e.target.checked })} className="size-4 accent-[#333c50]" />我已确认
                        </label>
                      )}
                    </li>
                  )
                })}
              </ul>
            </section>

            <div className="flex flex-wrap items-center gap-2">
              {s.phase === 'applying' && <Status tone="run" pulse>正在把已接受的改动应用到{sc.applyTarget}…</Status>}
              {s.phase === 'applied' && <><Button variant="primary" icon="flask" onClick={() => dispatch({ t: 'verify' })}>运行验收</Button><span className="text-[12.5px] text-ink-2">{report ? '报表已生成，尚未验收——这不是完成。' : `已应用 ${s.applied.length} 处（模拟），尚未验收——这不是完成。`}</span></>}
              {s.phase === 'verifying' && <Status tone="run" pulse>正在逐项核对…</Status>}
              {s.phase === 'verifyFailed' && <><Button variant="primary" icon="bolt" onClick={() => dispatch({ t: 'fix' })}>{report ? '重新生成报表' : '修复并重新审阅'}</Button><Button onClick={() => dispatch({ t: 'takeover' })}>我来接手</Button><span className="text-[12.5px] text-ink-2">{report ? `会生成 v${s.version + 1} 后再验收。` : `修复会生成 v${s.version + 1}，经你审阅、应用后再验收。`}</span></>}
              {s.phase === 'verified' && <><Button variant="primary" icon="box" disabled={!s.manualOk} onClick={() => dispatch({ t: 'deliver' })}>交付 v{s.version}</Button><span className="text-[12.5px] text-ink-2">{s.manualOk ? '所有标准已满足。' : '还差一项需要你亲自确认。'}</span></>}
              {s.phase === 'delivered' && <><Status tone="ok">v{s.version} 已交付</Status><span className="text-[12.5px] text-ink-2">想继续改？在对话里提出新的要求，会开始新一轮。</span></>}
              {s.phase === 'stopped' && s.handoff && <Status tone="neutral">已交给你处理 · 交付暂停</Status>}
              {busy && <span className="text-[11.5px] text-ink-2">按钮在完成前不可重复点击</span>}
            </div>

            <section>
              <h3 className="text-[12px] text-ink-2 mb-2">产物 · 属于此任务 v{s.version}</h3>
              <div className="grid @md:grid-cols-2 gap-2">
                {sc.artifacts.map(a => (
                  <button key={a.id} onClick={() => dispatch({ t: 'layout', o: { op: 'open', m: 'preview', preview: a.id } })} className="ring-focus text-left rounded-lg border border-silver bg-paper hover:border-control px-3 py-2.5 flex items-center gap-3">
                    <Icon name="file" className="text-control" />
                    <div className="min-w-0 flex-1"><div className="text-[13px] truncate">{a.name}</div><div className="text-[11.5px] text-ink-2">{a.type} · {a.size} · {s.phase === 'delivered' ? '已交付' : '草稿'}</div></div>
                    <span className="text-[12px] text-mint-ink">预览</span>
                  </button>
                ))}
              </div>
              {s.rounds.length > 0 && (
                <ol className="mt-3 flex flex-col gap-0.5" aria-label="记录">
                  {s.rounds.slice(-5).map((r, i) => <li key={i} className="text-[11.5px] text-ink-2 flex gap-2"><span className="font-mono w-[86px] shrink-0">{new Date(r.at).toLocaleString('zh-CN', { month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' })}</span><span className={r.tone === 'ok' ? 'text-mint-ink' : r.tone === 'bad' ? 'text-berry' : ''}>{r.label}</span></li>)}
                </ol>
              )}
              <p className="mt-2 text-[11.5px] text-ink-2">{report ? '报表只保存在 Pioneer 产物库（模拟），不会写入数据库或磁盘。' : ws.readOnly ? '此工作区只读：产物只保存在 Pioneer 产物库。' : '“应用”只更新原型内的模拟工作区，不会写入你的磁盘。'}</p>
            </section>
          </>
        )}
      </div>
    </div>
  )
}
