import type { ReactNode, ButtonHTMLAttributes } from 'react'

export const A = '/assets/hazel'

const paths: Record<string, ReactNode> = {
  plus: <path d="M8 3v10M3 8h10" />,
  x: <path d="M4 4l8 8M12 4l-8 8" />,
  search: <><circle cx="7" cy="7" r="4.25" /><path d="M10.2 10.2L13.5 13.5" /></>,
  send: <path d="M8 13V3M4 7l4-4 4 4" />,
  stop: <rect x="4.5" y="4.5" width="7" height="7" rx="1.2" />,
  grid: <><rect x="2.5" y="2.5" width="4.5" height="4.5" rx="1" /><rect x="9" y="2.5" width="4.5" height="4.5" rx="1" /><rect x="2.5" y="9" width="4.5" height="4.5" rx="1" /><rect x="9" y="9" width="4.5" height="4.5" rx="1" /></>,
  chat: <path d="M3 4.5A1.5 1.5 0 014.5 3h7A1.5 1.5 0 0113 4.5v5A1.5 1.5 0 0111.5 11H7l-3 2.5V11h0A1 1 0 013 10z" />,
  panel: <><rect x="2.5" y="3" width="11" height="10" rx="1.5" /><path d="M10 3v10" /></>,
  file: <><path d="M4 2.5h5l3 3v8H4z" /><path d="M9 2.5v3h3" /></>,
  diff: <><path d="M5 2.5v7M2.5 6h5M8.5 13h5" /><circle cx="11" cy="5" r="2" /></>,
  box: <><path d="M2.5 5L8 2.5 13.5 5v6L8 13.5 2.5 11z" /><path d="M2.5 5L8 7.5 13.5 5M8 7.5v6" /></>,
  bolt: <path d="M9 2L4 9h4l-1 5 5-7H8z" />,
  layers: <><path d="M8 2.5l5.5 3L8 8.5 2.5 5.5z" /><path d="M2.5 8.5L8 11.5l5.5-3" /></>,
  check: <path d="M3.5 8.5l3 3 6-7" />,
  shield: <path d="M8 2l5 2v4c0 3-2.2 5-5 6-2.8-1-5-3-5-6V4z" />,
  wifi: <><path d="M2 6.5a9 9 0 0112 0M4.2 9a5.5 5.5 0 017.6 0" /><circle cx="8" cy="11.8" r=".9" fill="currentColor" /></>,
  alert: <><path d="M8 2.5l6 10.5H2z" /><path d="M8 7v2.5" /><circle cx="8" cy="11.2" r=".6" fill="currentColor" /></>,
  undo: <path d="M5 6H10a3 3 0 010 6H7M5 6l2.5-2.5M5 6l2.5 2.5" />,
  keyboard: <><rect x="1.5" y="4" width="13" height="8" rx="1.5" /><path d="M4 7h1M7 7h1M10 7h2M5 9.5h6" /></>,
  eye: <><path d="M1.5 8S4 3.5 8 3.5 14.5 8 14.5 8 12 12.5 8 12.5 1.5 8 1.5 8z" /><circle cx="8" cy="8" r="2" /></>,
  eyeoff: <><path d="M2 2l12 12M6.5 4A6.5 6.5 0 0114.5 8a9 9 0 01-1.8 2.4M4 5.3A9 9 0 001.5 8S4 12.5 8 12.5a6 6 0 002.5-.6" /></>,
  chevron: <path d="M6 4l4 4-4 4" />,
  down: <path d="M4 6l4 4 4-4" />,
  pin: <path d="M6 2.5h4l-.5 4 2 2H4.5l2-2zM8 8.5V14" />,
  book: <><path d="M3 3h4a1.5 1.5 0 011.5 1.5V13A1.5 1.5 0 007 11.5H3zM13 3H9.5A1.5 1.5 0 008 4.5" /><path d="M13 3v8.5H9.5A1.5 1.5 0 008 13" /></>,
  info: <><circle cx="8" cy="8" r="5.5" /><path d="M8 7.2v3.5" /><circle cx="8" cy="5.2" r=".6" fill="currentColor" /></>,
  refresh: <path d="M13 4v3h-3M3 12V9h3M12.5 7A4.8 4.8 0 004 5.5M3.5 9a4.8 4.8 0 008.5 1.5" />,
  clock: <><circle cx="8" cy="8" r="5.5" /><path d="M8 5v3.2l2 1.3" /></>,
  sparkle: <path d="M8 2.5l1.3 4.2 4.2 1.3-4.2 1.3L8 13.5l-1.3-4.2L2.5 8l4.2-1.3z" />,
  dots: <><circle cx="4" cy="8" r=".9" fill="currentColor" /><circle cx="8" cy="8" r=".9" fill="currentColor" /><circle cx="12" cy="8" r=".9" fill="currentColor" /></>,
  edit: <path d="M3 13l1-3.5 6.5-6.5 2.5 2.5L6.5 12z M9.5 4l2.5 2.5" />,
  folder: <path d="M2.5 4.5A1 1 0 013.5 3.5H6l1.5 1.5h5a1 1 0 011 1v6a1 1 0 01-1 1h-9a1 1 0 01-1-1z" />,
  trash: <path d="M3 4.5h10M6.5 4.5V3h3v1.5M4.5 4.5l.6 8.5h5.8l.6-8.5" />,
  gear: <><circle cx="8" cy="8" r="2" /><path d="M8 1.8v1.6M8 12.6v1.6M1.8 8h1.6M12.6 8h1.6M3.6 3.6l1.1 1.1M11.3 11.3l1.1 1.1M3.6 12.4l1.1-1.1M11.3 4.7l1.1-1.1" /></>,
  lock: <><rect x="3.5" y="7" width="9" height="6.5" rx="1.2" /><path d="M5.5 7V5a2.5 2.5 0 015 0v2" /></>,
  flask: <path d="M6.5 2.5h3M7 2.5v4L3.5 12.5a.8.8 0 00.7 1h7.6a.8.8 0 00.7-1L9 6.5v-4" />,
  terminal: <><rect x="2" y="3" width="12" height="10" rx="1.5" /><path d="M4.5 6.5l2 1.5-2 1.5M8 10h3" /></>,
}

export function Icon({ name, size = 16, className = '' }: { name: keyof typeof paths | string; size?: number; className?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth={1.4} strokeLinecap="round" strokeLinejoin="round" className={`shrink-0 ${className}`} aria-hidden>
      {paths[name]}
    </svg>
  )
}

type BtnProps = ButtonHTMLAttributes<HTMLButtonElement> & { variant?: 'primary' | 'quiet' | 'outline' | 'danger' | 'mint'; size?: 'sm' | 'md'; icon?: string }
export function Button({ variant = 'outline', size = 'md', icon, className = '', children, ...rest }: BtnProps) {
  const v = {
    primary: 'bg-navy text-paper hover:bg-navy-deep',
    quiet: 'text-ink-2 hover:bg-muted hover:text-ink',
    outline: 'border border-silver bg-paper text-ink hover:border-control',
    danger: 'border border-berry/40 text-berry bg-paper hover:bg-rose/60',
    mint: 'bg-mint text-mint-ink hover:bg-mint-2',
  }[variant]
  const s = size === 'sm' ? 'h-7 px-2.5 text-[12px] gap-1.5 rounded-md' : 'h-9 px-3.5 text-[14px] gap-2 rounded-lg'
  return (
    <button {...rest} className={`ring-focus inline-flex items-center justify-center font-medium whitespace-nowrap transition-colors disabled:opacity-40 disabled:pointer-events-none ${v} ${s} ${className}`}>
      {icon && <Icon name={icon} size={size === 'sm' ? 13 : 15} />}
      {children}
    </button>
  )
}

export function Kbd({ children }: { children: ReactNode }) {
  return <kbd className="font-mono text-[10.5px] leading-none px-1.5 py-[3px] rounded border border-silver bg-paper text-ink-2">{children}</kbd>
}

export type Tone = 'neutral' | 'run' | 'ok' | 'warn' | 'bad' | 'local'
export function Status({ tone, children, pulse }: { tone: Tone; children: ReactNode; pulse?: boolean }) {
  const t = {
    neutral: 'bg-muted text-ink-2',
    run: 'bg-navy/[.07] text-navy',
    ok: 'bg-mint text-mint-ink',
    warn: 'bg-gold-soft text-[#7a5f3e]',
    bad: 'bg-rose text-berry',
    local: 'bg-paper border border-silver text-ink-2',
  }[tone]
  const dot = { neutral: 'bg-control', run: 'bg-navy', ok: 'bg-mint-ink', warn: 'bg-gold', bad: 'bg-berry', local: 'bg-control' }[tone]
  return (
    <span className={`inline-flex items-center gap-1.5 h-6 px-2 rounded-full text-[12px] font-medium whitespace-nowrap ${t}`}>
      <span className={`size-1.5 rounded-full ${dot} ${pulse ? 'anim-pulse' : ''}`} />
      {children}
    </span>
  )
}

export function ProtoTag({ className = '' }: { className?: string }) {
  return <span className={`inline-flex items-center gap-1 h-5 px-1.5 rounded border border-dashed border-control/60 text-[10.5px] font-mono uppercase tracking-wider text-ink-2 ${className}`}>原型 · 模拟</span>
}

export const THEMES = [
  { key: 'organizing', src: `${A}/greendou-organizing.png`, kind: 'companion', label: '整理绿冻' },
  { key: 'listening', src: `${A}/greendou-listening.png`, kind: 'companion', label: '陪伴绿冻' },
  { key: 'reading', src: `${A}/greendou-reading.png`, kind: 'companion', label: '阅读绿冻' },
  { key: 'quiet', src: `${A}/jelly-companion.png`, kind: 'companion', label: '原版绿冻' },
  { key: 'butterfly', src: `${A}/paper-butterfly.png`, kind: 'motif', label: '纸蝶' },
  { key: 'bookmark', src: `${A}/cherry-bookmark.png`, kind: 'motif', label: '樱桃书签' },
  { key: 'charm', src: `${A}/jelly-ribbon-charm.png`, kind: 'motif', label: '果冻挂饰' },
  { key: 'uniform', src: `${A}/uniform-ribbon.png`, kind: 'motif', label: '制服蝴蝶结' },
  { key: 'ribbon', src: `${A}/ribbon-outline.svg`, kind: 'motif', label: '蝴蝶结轮廓' },
  { key: 'cherry', src: `${A}/cherry-pair.svg`, kind: 'motif', label: '樱桃小枝' },
  { key: 'fold', src: `${A}/silver-paper-fold.svg`, kind: 'motif', label: '银灰折页' },
  { key: 'jelly', src: `${A}/jelly-outline.svg`, kind: 'motif', label: '果冻线描' },
] as const

/** One quiet decoration slot. Theme chosen by immutable id, never by task state. */
export function QuietSlot({ seed, compact }: { seed: string; compact?: boolean }) {
  let h = 0
  for (const c of seed) h = (h * 31 + c.charCodeAt(0)) >>> 0
  const t = THEMES[h % THEMES.length]
  const px = t.kind === 'companion' ? (compact ? 64 : 88) : 48
  return <img src={t.src} alt="" aria-hidden draggable={false} width={px} height={px} className="pointer-events-none select-none object-contain shrink-0" style={{ width: px, height: px }} />
}

export function Mark({ size = 20 }: { size?: number }) {
  return <img src={`${A}/jelly-mark.svg`} alt="" aria-hidden width={size} height={size} style={{ width: size, height: size }} className="shrink-0" />
}


/** Segmented choice with no default: value may be undefined until the user picks. */
export function Seg<T extends string>({ value, options, onChange, label }: { value?: T; options: { v: T; label: string; tone?: 'bad' }[]; onChange: (v: T) => void; label: string }) {
  return (
    <div role="radiogroup" aria-label={label} className="inline-flex rounded-lg border border-silver bg-canvas p-0.5">
      {options.map(o => {
        const on = value === o.v
        return (
          <button key={o.v} role="radio" aria-checked={on} onClick={() => onChange(o.v)}
            className={`ring-focus h-7 px-2.5 rounded-md text-[12px] font-medium whitespace-nowrap transition-colors ${on ? (o.tone === 'bad' ? 'bg-rose text-berry' : 'bg-paper text-ink shadow-[0_1px_2px_rgba(44,53,71,.12)]') : 'text-ink-2 hover:text-ink'}`}>
            {o.label}
          </button>
        )
      })}
    </div>
  )
}

export function Modal({ title, onClose, children, width = 440, label }: { title: ReactNode; onClose: () => void; children: ReactNode; width?: number; label: string }) {
  return (
    <div className="absolute inset-0 z-50 grid place-items-center bg-ink/20 p-4" onMouseDown={e => e.target === e.currentTarget && onClose()}
      onKeyDown={e => { if (e.key === 'Escape') { e.stopPropagation(); onClose() } }}>
      <div role="dialog" aria-modal aria-label={label} className="anim-rise w-full max-h-full overflow-auto scroll-quiet rounded-2xl bg-paper border border-silver shadow-[0_24px_60px_-20px_rgba(44,53,71,.35)]" style={{ maxWidth: width }}>
        <div className="flex items-start gap-3 px-5 pt-5 pb-3">
          <div className="flex-1 min-w-0 text-[16px] leading-6 font-medium">{title}</div>
          <Button size="sm" variant="quiet" icon="x" onClick={onClose} aria-label="关闭" autoFocus />
        </div>
        <div className="px-5 pb-5">{children}</div>
      </div>
    </div>
  )
}
