import { useState } from 'react'
import { protoKeys, type Prefs } from './store'
import { Button, Icon, Modal, Seg, ProtoTag } from './ui'
import { A } from './ui'

type Tab = 'look' | 'pet' | 'session' | 'conn' | 'data' | 'about'
const TABS: [Tab, string][] = [['look', '外观与动效'], ['pet', '桌宠'], ['session', '会话与布局'], ['conn', '连接'], ['data', '演示数据'], ['about', '关于']]

export default function Settings({ prefs, set, close, onReset, connected, setConnected, toggleDemo, initial = 'look' }: {
  toggleDemo: () => void; prefs: Prefs; set: (p: Partial<Prefs>) => void; close: () => void; onReset: () => void; connected: boolean; setConnected: (b: boolean) => void; initial?: Tab
}) {
  const [tab, setTab] = useState<Tab>(initial)
  const [confirm, setConfirm] = useState(false)
  const pet = (p: Partial<Prefs['pet']>) => set({ pet: { ...prefs.pet, ...p } })
  const Row = ({ t, d, children }: { t: string; d?: string; children: React.ReactNode }) => (
    <div className="flex flex-wrap items-center gap-x-4 gap-y-2 py-3 border-b border-silver/60 last:border-0">
      <div className="flex-1 min-w-[200px]"><div className="text-[13.5px]">{t}</div>{d && <div className="text-[12px] text-ink-2 leading-[18px]">{d}</div>}</div>
      {children}
    </div>
  )
  const Toggle = ({ on, set: s, label }: { on: boolean; set: (b: boolean) => void; label: string }) => (
    <button role="switch" aria-checked={on} aria-label={label} onClick={() => s(!on)} className={`ring-focus relative w-9 h-5 rounded-full transition-colors ${on ? 'bg-navy' : 'bg-silver'}`}>
      <span className={`absolute top-0.5 size-4 rounded-full bg-paper transition-all ${on ? 'left-[18px]' : 'left-0.5'}`} />
    </button>
  )
  return (
    <Modal label="设置" title={<span className="flex items-center gap-2">设置 <ProtoTag /></span>} onClose={close} width={640}>
      <div className="flex gap-5 min-h-[340px] max-sm:flex-col">
        <nav className="flex sm:flex-col gap-0.5 sm:w-32 shrink-0 overflow-x-auto" aria-label="设置分类">
          {TABS.map(([k, l]) => <button key={k} onClick={() => setTab(k)} aria-current={tab === k} className={`ring-focus text-left h-8 px-2.5 rounded-md text-[13px] whitespace-nowrap ${tab === k ? 'bg-muted font-medium' : 'text-ink-2 hover:text-ink'}`}>{l}</button>)}
        </nav>
        <div className="flex-1 min-w-0">
          {tab === 'look' && <>
            <Row t="动效" d="“减少”会停用脉冲、浮动与过渡；系统已开启“减少动态效果”时始终遵从系统。"><Seg label="动效" value={prefs.motion} onChange={v => set({ motion: v })} options={[{ v: 'system', label: '跟随系统' }, { v: 'off', label: '减少' }]} /></Row>
            <Row t="发送方式" d="默认 Ctrl+Enter 发送，避免输入法选词时误发。"><Seg label="发送方式" value={prefs.enterSends ? 'enter' : 'ctrl'} onChange={v => set({ enterSends: v === 'enter' })} options={[{ v: 'ctrl', label: 'Ctrl+Enter' }, { v: 'enter', label: 'Enter' }]} /></Row>
            <Row t="主题" d="浅色纸面。深色主题不在本原型范围。"><span className="text-[12px] text-ink-2">浅色</span></Row>
          </>}
          {tab === 'pet' && <>
            <Row t="显示桌宠" d="dsh-manqu-pet 的适配原型，不是真实插件。关闭后可在此重新开启。"><Toggle label="显示桌宠" on={prefs.pet.state !== 'off'} set={b => pet({ state: b ? 'out' : 'off' })} /></Row>
            <Row t="记住位置" d="拖动后的位置在下次打开时恢复。关闭则每次回到右下角。"><Toggle label="记住位置" on={prefs.pet.remember} set={b => pet({ remember: b })} /></Row>
            <Row t="单击说话" d="单击时出现一句气泡。关闭后单击只有轻微回弹。"><Toggle label="单击说话" on={prefs.pet.bubbles} set={b => pet({ bubbles: b })} /></Row>
            <div className="mt-3 rounded-lg bg-canvas px-3 py-2.5 text-[12px] leading-[19px] text-ink-2">
              让位规则（宿主决定，桌宠不表达任务状态）：输入时淡出并点击穿透；待确认、待授权、失败、断连与审阅时收到边缘；打开对话框时隐藏。
            </div>
          </>}
          {tab === 'session' && <>
            <Row t="启动时恢复标签" d="关闭后，下次启动只显示工作区；会话本身不受影响。"><Toggle label="恢复标签" on={prefs.restoreTabs} set={b => set({ restoreTabs: b })} /></Row>
            <Row t="每个会话的布局" d="面板的拆分、分组、大小与关闭记录随会话保存；新结果只在对话里提示，不会自动打开、切换或重排面板。"><span className="text-[12px] text-ink-2">始终开启</span></Row>
          </>}
          {tab === 'conn' && <>
            <Row t="本机执行器（模拟）" d="原型不连接任何模型或服务。断开后运行中的任务进入“结果未知”。"><Toggle label="执行器连接" on={connected} set={setConnected} /></Row>
            <Row t="演示模式" d="显示模拟 Windows 桌面、任务栏、窗口关闭 / 恢复与异常注入。默认关闭，产品视图不含任何测试浮层。Alt+Shift+D"><Toggle label="演示模式" on={prefs.demo} set={() => toggleDemo()} /></Row>
            <Row t="模拟速度" d="只影响原型中步骤推进的快慢。"><Seg label="模拟速度" value={prefs.speed} onChange={v => set({ speed: v })} options={[{ v: 'slow', label: '慢' }, { v: 'normal', label: '正常' }, { v: 'fast', label: '快' }]} /></Row>
          </>}
          {tab === 'data' && <>
            <Row t="存储位置" d="浏览器 localStorage，仅以下前缀的键。"><span className="font-mono text-[11.5px] text-ink-2">pioneer-proto-*</span></Row>
            <div className="py-3">
              <div className="text-[12px] text-ink-2 mb-1.5">当前原型键（{protoKeys().length}）</div>
              <ul className="font-mono text-[11.5px] rounded-lg bg-canvas px-3 py-2">{protoKeys().map(k => <li key={k}>{k}</li>)}{!protoKeys().length && <li className="text-ink-2">（无）</li>}</ul>
            </div>
            {!confirm ? <Button variant="danger" icon="trash" onClick={() => setConfirm(true)}>重置演示数据…</Button> : (
              <div role="alertdialog" className="rounded-lg border border-berry/30 bg-rose/40 p-3">
                <div className="text-[13.5px] font-medium text-berry">确定重置？</div>
                <p className="text-[12.5px] text-ink-2 mt-1">会删除上面列出的原型键并重新载入示例会话。不会触碰此页面之外、也不会触碰其它前缀的数据。</p>
                <div className="flex gap-2 mt-3"><Button size="sm" variant="danger" onClick={onReset}>删除并重新载入</Button><Button size="sm" variant="quiet" onClick={() => setConfirm(false)}>取消</Button></div>
              </div>
            )}
          </>}
          {tab === 'about' && (
            <div className="flex gap-4 items-start py-2">
              <img src={`${A}/compass-seal.svg`} alt="" className="size-12" />
              <div className="text-[13px] leading-[21px] text-ink-2">
                <div className="text-ink font-medium text-[14px]">Pioneer · v5 候选原型</div>
                React + Tailwind 交互原型，所有执行、文件、连接均为模拟。v2/v3 原稿未修改。<br />
                <span className="inline-flex items-center gap-1 mt-1"><Icon name="info" size={12} />快捷键在浏览器里使用 Alt 组合；原生应用中会改为 Ctrl。</span>
              </div>
            </div>
          )}
        </div>
      </div>
    </Modal>
  )
}
