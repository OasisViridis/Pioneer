import { SCRIPTS, uid, type Block, type Decision, type PermMode, type Phase, type Session } from './data'
import { applyOp, type Op } from './layout'

/* Pure reducer for one session. The executor is simulated: a global ticker
   dispatches `tick` to every session, independent of tabs and windows.
   Rule: nothing advances to a "done" state without an explicit event. */

export type Action =
  | { t: 'send'; text: string; remembered: string[] }
  | { t: 'perm'; v: Decision }
  | { t: 'permMode'; v: PermMode }
  | { t: 'model'; v: string }
  | { t: 'rerequest' }
  | { t: 'tick'; failRun: boolean; failVerify: boolean; now: number }
  | { t: 'stop' }
  | { t: 'disconnect' }
  | { t: 'reconnect' }
  | { t: 'resume'; from: 'next' | 'redo' }
  | { t: 'retry' }
  | { t: 'fix' }
  | { t: 'takeover' }
  | { t: 'hunk'; id: string; v: 'pending' | 'accepted' | 'rejected'; note?: string }
  | { t: 'hunkAll'; v: 'accepted' }
  | { t: 'apply' }
  | { t: 'revise' }
  | { t: 'verify' }
  | { t: 'manual'; v: boolean }
  | { t: 'deliver' }
  | { t: 'draft'; text: string }
  | { t: 'layout'; o: Op }
  | { t: 'ctx'; id: string; state: 'in' | 'removed' }
  | { t: 'rename'; title: string }

const SPEED = { stop: 1700, check: 2000, revise: 2600, apply: 1500, verify: 2400 }
export const speed = { k: 1 }

const add = (s: Session, ...b: Block[]): Session => ({ ...s, blocks: [...s.blocks, ...b] })
const notice = (tone: 'neutral' | 'warn' | 'bad' | 'ok', text: string): Block => ({ id: uid(), kind: 'notice', tone, text })
const at = (ms: number) => Date.now() + ms * speed.k
const round = (s: Session, label: string, tone: 'ok' | 'bad' | 'neutral' = 'neutral'): Session => ({ ...s, rounds: [...s.rounds, { at: Date.now(), label, tone }] })

export const ACTIVE: Phase[] = ['running', 'stopping', 'checking', 'revising', 'applying', 'verifying']
export const isActive = (s: Session) => ACTIVE.includes(s.phase)
export const needsYou = (s: Session) => ['permission', 'failed', 'disconnected', 'reconciled', 'review', 'verifyFailed'].includes(s.phase) || (s.phase === 'verified' && !s.manualOk)

export function currentHunks(s: Session) {
  const sc = SCRIPTS[s.script]
  const all = Object.values(sc.versions).flat()
  return all.filter(h => h.id in s.hunks)
}

/** Send starts work immediately — no intent sign-off. Permission is asked inline, only when a step needs it. */
function startRun(s: Session, text: string, remembered: string[]): Session {
  const blocks = s.blocks.map(b => (b.kind === 'permission' && b.state === 'open' ? { ...b, state: 'deny' as const } : b))
  return {
    ...s, blocks: [...blocks, { id: uid(), kind: 'user', text }, { id: uid(), kind: 'run', attempt: s.attempt, version: s.version }],
    intentRev: s.intentRev + 1, phase: 'running', step: 0, failedStep: undefined, handoff: false, draft: '', queued: [], allowOnce: undefined,
    allowed: [...new Set([...s.allowed, ...remembered])],
  }
}

/** which permission a step needs before it may run (reads and planning never ask) */
export const needOf = (s: Session, i: number) => {
  const st = SCRIPTS[s.script].steps[i]
  return st && (st.kind === 'write' || st.kind === 'exec') ? st.kind : undefined
}

export function reduce(s: Session, a: Action): Session {
  const sc = SCRIPTS[s.script]
  const r = reduce0(s, a, sc)
  return r === s ? s : a.t === 'tick' || a.t === 'layout' || a.t === 'draft' ? r : { ...r, updated: Date.now() }
}

function reduce0(s: Session, a: Action, sc: (typeof SCRIPTS)[keyof typeof SCRIPTS]): Session {
  switch (a.t) {
    case 'draft': return s.draft === a.text ? s : { ...s, draft: a.text }
    case 'layout': return { ...s, layout: applyOp(s.layout, a.o) }
    case 'rename': return a.title.trim() ? { ...s, title: a.title.trim().slice(0, 40) } : s
    case 'ctx': return { ...s, context: s.context.map(c => (c.id === a.id ? { ...c, state: a.state } : c)) }

    case 'send': {
      const text = a.text.trim()
      if (!text) return s
      const last = [...s.blocks].reverse().find(b => b.kind === 'user')
      if (last && last.kind === 'user' && last.text === text && Date.now() - s.updated < 2000) return s // duplicate guard
      if (isActive(s)) {
        // supplementary note: queued, the agent reads it at the next step boundary
        return { ...add(s, { id: uid(), kind: 'user', text, supplement: 'queued' }), draft: '', queued: [...s.queued, text] }
      }
      return startRun(s, text, a.remembered)
    }
    case 'permMode': return { ...s, permMode: a.v }
    case 'model': return { ...s, model: a.v }

    case 'perm': {
      const open = s.blocks.find(b => b.kind === 'permission' && b.state === 'open')
      if (s.phase !== 'permission' || !open || open.kind !== 'permission') return s
      const blocks = s.blocks.map(b => (b === open ? { ...open, state: a.v } : b))
      if (a.v === 'deny') return round({ ...s, blocks, phase: 'denied' }, '已拒绝授权', 'bad')
      return {
        ...s, blocks, phase: 'running',
        allowOnce: a.v === 'once' ? `${open.perm}:${open.step}` : s.allowOnce,
        allowed: a.v === 'once' ? s.allowed : [...new Set([...s.allowed, open.perm])],
      }
    }
    case 'rerequest': {
      if (s.phase !== 'denied') return s
      const last = [...s.blocks].reverse().find(b => b.kind === 'permission')
      if (!last || last.kind !== 'permission') return s
      return { ...add(s, { id: uid(), kind: 'permission', perm: last.perm, step: last.step, state: 'open' }), phase: 'permission' }
    }

    case 'tick': {
      const now = a.now
      if (s.phase === 'running') {
        let n = s
        if (s.queued.length) n = { ...n, queued: [], blocks: n.blocks.map(b => (b.kind === 'user' && b.supplement === 'queued' ? { ...b, supplement: 'read' as const } : b)) }
        const need = needOf(n, s.step)
        if (need && n.permMode !== 'auto' && !n.allowed.includes(need) && n.allowOnce !== `${need}:${s.step}`) {
          if (n.permMode === 'read') return round({ ...add(n, notice('warn', `只读模式，已在「${sc.steps[s.step].label}」前停下。`)), phase: 'stopped' }, '只读 · 已停下')
          return { ...add(n, { id: uid(), kind: 'permission', perm: need, step: s.step, state: 'open' }), phase: 'permission' }
        }
        if (a.failRun && s.step === sc.failStep && !s.failedStep) {
          return round({ ...n, phase: 'failed', failedStep: s.step }, `第 ${s.step + 1} 步失败`, 'bad')
        }
        const step = s.step + 1
        if (step >= sc.steps.length) {
          if (sc.kind === 'report') return round({ ...add(n, { id: uid(), kind: 'agent', text: sc.summary, cta: 'deliver' }), step, phase: 'applied', checks: {}, manualOk: false }, '报表已生成 · 待验收')
          const first = sc.versions[1].map(h => h.id)
          const hunks = Object.keys(n.hunks).length ? n.hunks : Object.fromEntries(first.map(id => [id, 'pending' as const]))
          return round({ ...add(n, { id: uid(), kind: 'agent', text: sc.summary, cta: 'review' }), step, phase: 'review', hunks }, `v${s.version} 待审阅`)
        }
        return { ...n, step }
      }
      if (!s.until || now < s.until) return s
      if (s.phase === 'stopping') {
        const done = sc.steps.slice(0, s.step).filter(x => x.writes).flatMap(x => x.writes!)
        return round({ ...add(s, notice('neutral', `已确认停止：完成了 ${s.step} / ${sc.steps.length} 步。${done.length ? `已写入 ${done.join('、')}，保留在快照中，可回滚。` : '没有写入任何文件。'}`)), phase: 'stopped', until: undefined }, '已停止')
      }
      if (s.phase === 'checking') {
        const k = s.unknownStep ?? s.step
        const st = sc.steps[k]
        const done = !!st && st.kind !== 'exec'
        return { ...add(s, notice(done ? 'neutral' : 'warn', st ? `核对完成：第 ${k + 1} 步「${st.label}」${done ? '在断连前已完成，结果已同步。' : '没有完成，输出不完整。'}没有自动继续，请你选择下一步。` : '核对完成，没有未知步骤。')), phase: 'reconciled', until: undefined, reconciledDone: done, step: done ? k + 1 : k }
      }
      if (s.phase === 'revising') {
        const next = s.version + 1
        // the last scripted version is the acceptance fix; review revisions never reach it, acceptance failures always do
        const last = Math.max(...Object.keys(sc.versions).map(Number))
        const vh = s.fixingVerify ? sc.versions[last] : sc.versions[Math.min(next, last - 1)]
        const kept = Object.fromEntries(Object.entries(s.hunks).filter(([, v]) => v === 'accepted'))
        const hunks = { ...kept, ...Object.fromEntries(vh.map(h => [h.id, 'pending' as const])) }
        return round({ ...add(s, { id: uid(), kind: 'agent', text: `v${next} 好了：${vh.map(h => h.why).join('；')}。之前已接受的改动保持不变。`, cta: 'review' }), phase: 'review', version: next, hunks, rejectNotes: {}, until: undefined, fixingVerify: undefined }, `v${next} 待审阅`)
      }
      if (s.phase === 'applying') {
        const applied = Object.entries(s.hunks).filter(([, v]) => v === 'accepted').map(([k]) => k)
        return round({ ...add(s, notice('neutral', `已模拟应用 ${applied.length} 处改动到${sc.applyTarget}。这还不是验收：请运行验收核对原始的完成标准。`)), phase: 'applied', applied, until: undefined }, `v${s.version} 已应用（模拟）`)
      }
      if (s.phase === 'verifying') {
        const failId = a.failVerify ? sc.checks.find(c => c.failText && !c.manual)?.id : undefined
        const checks = Object.fromEntries(sc.checks.map(c => [c.id, c.manual ? 'manual' : c.id === failId ? 'fail' : 'pass'])) as Session['checks']
        if (failId) return round({ ...add(s, notice('bad', `验收未通过：${sc.checks.find(c => c.id === failId)!.failText}`)), checks, phase: 'verifyFailed', until: undefined }, '验收未通过', 'bad')
        return round({ ...s, checks, phase: 'verified', until: undefined }, sc.checks.some(c => c.manual) ? '自动项通过 · 待人工确认' : '验收通过', sc.checks.some(c => c.manual) ? 'neutral' : 'ok')
      }
      return s
    }

    case 'stop':
      if (s.phase !== 'running') return s
      return { ...s, phase: 'stopping', until: at(SPEED.stop) }
    case 'disconnect':
      if (!['running', 'stopping', 'verifying', 'applying', 'revising'].includes(s.phase)) return s
      return round({ ...add(s, notice('bad', `与执行器的连接中断。第 ${s.step + 1} 步的结果未知——可能已完成，也可能没有。`)), phase: 'disconnected', unknownStep: s.step, until: undefined }, '连接中断', 'bad')
    case 'reconnect':
      if (s.phase !== 'disconnected') return s
      return { ...s, phase: 'checking', until: at(SPEED.check) }
    case 'resume':
      if (s.phase === 'reconciled') {
        const step = a.from === 'redo' ? s.unknownStep ?? s.step : s.step
        return { ...add(s, notice('neutral', a.from === 'redo' ? `你选择重做第 ${step + 1} 步。` : `你选择从第 ${step + 1} 步继续。`)), phase: 'running', step, unknownStep: undefined }
      }
      if (s.phase === 'stopped' && !s.handoff && s.step < sc.steps.length) return { ...add(s, notice('neutral', `从第 ${s.step + 1} 步继续。`)), phase: 'running' }
      return s
    case 'retry':
      if (s.phase !== 'failed') return s
      return { ...add(s, notice('neutral', `第 ${s.attempt + 1} 次尝试：重新运行第 ${(s.failedStep ?? s.step) + 1} 步（不改代码）。`)), phase: 'running', attempt: s.attempt + 1, step: s.failedStep ?? s.step, failedStep: undefined }
    case 'fix':
      if (s.phase === 'failed') return { ...add(s, { id: uid(), kind: 'agent', text: sc.failFix }), phase: 'running', attempt: s.attempt + 1, step: s.failedStep ?? s.step, failedStep: undefined }
      if (s.phase === 'verifyFailed' && sc.kind === 'report') return { ...add(s, notice('neutral', '针对未通过的验收项重新生成报表，完成后再验收。')), phase: 'running', step: 1, checks: {}, version: s.version + 1 }
      if (s.phase === 'verifyFailed') return { ...add(s, notice('neutral', '针对未通过的验收项修复，修复会作为新版本重新审阅。')), phase: 'revising', until: at(SPEED.revise), checks: {}, fixingVerify: true }
      return s
    case 'takeover':
      if (s.phase !== 'failed' && s.phase !== 'verifyFailed') return s
      return round({ ...add(s, notice('neutral', '已交给你处理。Pioneer 不会再写入这个工作区；已完成的改动保留在快照中，你可以在完成后回来继续。')), phase: 'stopped', handoff: true }, '用户接手')

    case 'hunk':
      if (s.phase !== 'review' || !(a.id in s.hunks)) return s
      return { ...s, hunks: { ...s.hunks, [a.id]: a.v }, rejectNotes: a.note !== undefined ? { ...s.rejectNotes, [a.id]: a.note } : s.rejectNotes }
    case 'hunkAll':
      if (s.phase !== 'review') return s
      return { ...s, hunks: Object.fromEntries(Object.entries(s.hunks).map(([k, v]) => [k, v === 'pending' ? 'accepted' : v])) }
    case 'apply': {
      const v = Object.values(s.hunks)
      if (s.phase !== 'review' || v.includes('pending') || !v.includes('accepted')) return s
      return { ...s, phase: 'applying', until: at(SPEED.apply) }
    }
    case 'revise': {
      if (s.phase !== 'review' || !Object.values(s.hunks).includes('rejected')) return s
      const notes = Object.values(s.rejectNotes).filter(Boolean)
      return { ...add(s, notice('neutral', `退回修改${notes.length ? `：${notes.join('；')}` : ''}。已接受的改动保留。`)), phase: 'revising', until: at(SPEED.revise) }
    }
    case 'verify':
      if (s.phase !== 'applied') return s
      return { ...s, phase: 'verifying', until: at(SPEED.verify), manualOk: false }
    case 'manual':
      if (s.phase !== 'verified') return s
      return { ...s, manualOk: a.v }
    case 'deliver':
      if (s.phase !== 'verified' || !s.manualOk) return s
      return round({ ...add(s, notice('ok', `已交付 v${s.version}。产物与验收记录保存在本机（模拟）。`)), phase: 'delivered' }, `v${s.version} 已交付`, 'ok')
  }
  return s
}
