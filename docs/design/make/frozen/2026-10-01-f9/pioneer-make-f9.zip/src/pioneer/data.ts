/* ────────────────────────────────────────────────────────────
   Pioneer v5 prototype · data model
   Everything here is simulated. No file system, Git, model or network access.
   ──────────────────────────────────────────────────────────── */

/** module = a capability/content type. A panel is one module instance inside a group; the layout is the composition. */
export type ModuleId = 'chat' | 'context' | 'changes' | 'deliver' | 'preview' | 'log' | 'caps'
export type Edge = 'center' | 'left' | 'right' | 'top' | 'bottom'
export type PNode =
  | { k: 'group'; id: string; tabs: ModuleId[]; active: ModuleId }
  | { k: 'split'; id: string; dir: 'row' | 'col'; ratio: number; a: PNode; b: PNode }

export type Phase =
  | 'empty' | 'permission' | 'denied'
  | 'running' | 'stopping' | 'stopped' | 'failed'
  | 'disconnected' | 'checking' | 'reconciled'
  | 'review' | 'revising' | 'applying' | 'applied'
  | 'verifying' | 'verifyFailed' | 'verified' | 'delivered'

export type Decision = 'once' | 'session' | 'always' | 'deny'
/** composer-level permission mode, like a normal coding agent */
export type PermMode = 'read' | 'ask' | 'auto'

/** demo model list — labels only, the prototype never calls a model */
export const MODELS = [
  { id: 'astra-6-1-sol', name: 'Astra 6.1 Sol', note: '演示' },
  { id: 'claude-opus-5-5', name: 'Claude Opus 5.5', note: '最强 · 复杂任务' },
  { id: 'claude-sonnet-5-5', name: 'Claude Sonnet 5.5', note: '均衡 · 日常编码' },
  { id: 'claude-fable-5-1', name: 'Claude Fable 5.1', note: '长文与写作' },
]

export type Block =
  | { id: string; kind: 'user'; text: string; supplement?: 'queued' | 'read' }
  | { id: string; kind: 'permission'; perm: string; step: number; state: 'open' | Decision }
  | { id: string; kind: 'run'; attempt: number; version: number }
  | { id: string; kind: 'agent'; text: string; cta?: 'review' | 'deliver' }
  | { id: string; kind: 'notice'; tone: 'neutral' | 'warn' | 'bad' | 'ok'; text: string }

export type HunkState = 'pending' | 'accepted' | 'rejected'
export type CheckState = 'idle' | 'pass' | 'fail' | 'manual'

/** one workbench per session. The conversation is the default spine but just another panel: movable, groupable, closable. */
export type Layout = { root: PNode; focus: string; recent: ModuleId[]; preview?: string; /** last user request to reveal a module — the panel flashes once */ pulse?: { m: ModuleId; n: number } }
export type Ctx = { id: string; label: string; meta: string; state: 'in' | 'suggested' | 'stale' | 'removed'; source: string[] }

export type Session = {
  id: string
  title: string
  workspace: string
  script: ScriptId
  phase: Phase
  step: number
  attempt: number
  version: number
  intentRev: number
  blocks: Block[]
  draft: string
  queued: string[]
  hunks: Record<string, HunkState>
  rejectNotes: Record<string, string>
  applied: string[]
  checks: Record<string, CheckState>
  manualOk: boolean
  until?: number
  unknownStep?: number
  reconciledDone?: boolean
  failedStep?: number
  handoff?: boolean
  /** revising because acceptance failed → next version is the acceptance fix, not a review revision */
  fixingVerify?: boolean
  readOnlyPlan?: boolean
  permMode: PermMode
  /** demo-only model label; nothing is called */
  model: string
  /** permissions allowed for the rest of this session (incl. workspace-remembered ones at send time) */
  allowed: string[]
  allowOnce?: string
  layout: Layout
  context: Ctx[]
  updated: number
  rounds: { at: number; label: string; tone: 'ok' | 'bad' | 'neutral' }[]
}

export type Workspace = {
  id: string
  name: string
  path: string
  kind: string
  cover: 'code' | 'map' | 'doc' | 'image'
  tint: string
  note: string
  readOnly?: boolean
  unavailable?: string
  added: number
}

/* ───────── scripts: three believable tasks with different shapes ───────── */

export type ScriptId = 'invoice' | 'tiles' | 'digest' | 'recon'
export type Perm = { id: string; object: string; action: string; scope: string; icon: string }
export type Step = { label: string; kind: 'read' | 'think' | 'write' | 'exec'; detail: string; log: string[]; writes?: string[] }
export type Hunk = { id: string; file: string; range: string; why: string; lines: [string, string][] }
export type Check = { id: string; label: string; how: string; manual?: boolean; failText?: string; evidence?: string[] }
/** how results are reviewed: code changes go through hunks; reports are previewed and checked; answers just cite sources */
export type TaskKind = 'code' | 'doc' | 'report'
export type Artifact = { id: string; name: string; type: string; size: string; preview: string[]; table?: { cols: string[]; rows: string[][]; foot?: string[] } }

export type Script = {
  id: ScriptId
  kind: TaskKind
  ask: string
  intent: { goal: string; change: string; avoid: string; done: string }
  perms: Perm[]
  steps: Step[]
  failStep: number
  failLog: string[]
  /** agent's fix note for the run failure — must address exactly what failLog reports */
  failFix: string
  versions: Record<number, Hunk[]>
  checks: Check[]
  artifacts: Artifact[]
  summary: string
  applyTarget: string
}

export const SCRIPTS: Record<ScriptId, Script> = {
  invoice: {
    id: 'invoice', kind: 'code',
    ask: '发票导出在大账期会内存溢出，请改成流式写入，CSV 格式保持不变。',
    intent: {
      goal: '大账期导出不再内存溢出；CSV 列、顺序与转义规则保持不变。',
      change: 'src/export/invoice.ts · 新增 src/export/csv-stream.ts',
      avoid: '数据库结构、API 路由、已发布的历史导出文件',
      done: '120 万行导出峰值内存 < 300 MB；现有 export 测试全部通过；取消导出不残留游标',
    },
    perms: [
      { id: 'write', object: 'src/export/', action: '修改 1 个文件、新建 1 个文件', scope: '写入前自动快照，可整体回滚', icon: 'file' },
      { id: 'exec', object: 'pnpm test export', action: '在本机终端运行', scope: '无网络 · 超时 120 秒', icon: 'terminal' },
    ],
    steps: [
      { label: '读取 invoice.ts 与 3 个调用点', kind: 'read', detail: '只读 · 412 行', log: ['read src/export/invoice.ts (412 lines)', 'grep exportInvoices → 3 call sites', 'read docs/billing/periods.md'] },
      { label: '规划：buildAll() 改为逐页流式写入', kind: 'think', detail: '第 {rev} 轮', log: ['plan: paginate(size=500) → writer.writeRows', 'keep INVOICE_HEADERS order', 'abort → release cursor'] },
      { label: '修改 src/export/invoice.ts', kind: 'write', detail: '+38 −21', log: ['snapshot #a41f created', 'write src/export/invoice.ts (+38 −21)'], writes: ['src/export/invoice.ts'] },
      { label: '新建 src/export/csv-stream.ts', kind: 'write', detail: '+46', log: ['write src/export/csv-stream.ts (+46)'], writes: ['src/export/csv-stream.ts'] },
      { label: '运行 pnpm test export', kind: 'exec', detail: '本机终端', log: ['$ pnpm test export', 'PASS export/invoice.spec.ts (14)', 'PASS export/csv.spec.ts (9)', 'Tests: 23 passed'] },
      { label: '汇总改动与验收建议', kind: 'think', detail: '', log: ['summary ready · 3 hunks'] },
    ],
    failStep: 4,
    failLog: ['$ pnpm test export', '✕ export › cancels mid-stream', '    Expected cursor released, received 1 open', 'Tests: 1 failed, 22 passed'],
    failFix: '我读了失败日志：取消导出时 abort 回调没有释放数据库游标，测试里残留 1 个。已在回调里补上 releaseCursor，重新运行该步。',
    versions: {
      1: [
        { id: 'h1', file: 'src/export/invoice.ts', range: '@@ -42,18 +42,22 @@', why: '不再一次性把整个账期装进内存', lines: [[' ', 'export async function exportInvoices(period: Period, out: Writable) {'], ['-', '  const rows = await repo.findAll(period)'], ['-', '  const csv = rows.map(toCsvRow).join("\\n")'], ['-', '  out.write(csv)'], ['+', '  const writer = createCsvStream(out, INVOICE_HEADERS)'], ['+', '  for await (const page of repo.paginate(period, { size: 500 })) {'], ['+', '    await writer.writeRows(page.map(toCsvRow))'], ['+', '  }'], ['+', '  await writer.close()'], [' ', '}']] },
        { id: 'h2', file: 'src/export/invoice.ts', range: '@@ -88,6 +92,9 @@', why: '取消导出时释放数据库游标', lines: [[' ', '  signal?.addEventListener("abort", () => {'], ['-', '    out.destroy()'], ['+', '    writer.abort(signal.reason)'], ['+', '    repo.releaseCursor(period.id)'], [' ', '  })']] },
        { id: 'h3', file: 'src/export/csv-stream.ts', range: '新文件 · +46', why: '带背压的 CSV 写入器，供其它导出复用', lines: [['+', 'export function createCsvStream(out: Writable, headers: string[]) {'], ['+', '  let started = false'], ['+', '  return {'], ['+', '    async writeRows(rows: string[][]) {'], ['+', '      if (!started) { await write(out, headers.join(",") + "\\n"); started = true }'], ['+', '      for (const r of rows) if (!out.write(r.join(",") + "\\n")) await once(out, "drain")'], ['+', '    },'], ['+', '    /* … 34 行 … */']] },
      ],
      2: [
        { id: 'h2b', file: 'src/export/invoice.ts', range: '@@ -88,6 +92,11 @@', why: '按你的意见：先等写入器落盘再释放游标，避免截断', lines: [[' ', '  signal?.addEventListener("abort", async () => {'], ['-', '    out.destroy()'], ['+', '    await writer.abort(signal.reason)'], ['+', '    try { await writer.flushed } finally {'], ['+', '      repo.releaseCursor(period.id)'], ['+', '    }'], [' ', '  })']] },
      ],
      3: [
        { id: 'h4', file: 'src/export/csv-stream.ts', range: '@@ -12,4 +12,7 @@', why: '验收失败修复：空账期也写出表头', lines: [['+', '  async close() {'], ['+', '    if (!started) await write(out, headers.join(",") + "\\n")'], [' ', '    await end(out)'], ['+', '  },']] },
      ],
    },
    checks: [
      { id: 'c1', label: '120 万行账期导出，峰值内存 < 300 MB', how: '模拟基准 · 212 MB' },
      { id: 'c2', label: '现有 export 测试全部通过', how: '23 / 23 通过', failText: '1 项失败：empty period writes header only' },
      { id: 'c3', label: '取消导出后无残留游标', how: '需要你在预发环境确认', manual: true },
    ],
    artifacts: [
      { id: 'a1', name: 'PR 草稿 · 流式发票导出.md', type: 'Markdown', size: '2.1 KB', preview: ['# 流式发票导出', '', '## 为什么', '9 月账期 120 万行导出在 2 GB 实例上 OOM。', '', '## 改了什么', '- exportInvoices 逐页（500 行）写入', '- 新增 createCsvStream，带背压', '- 取消时等待落盘再释放游标', '', '## 验证', '- 峰值内存 212 MB（模拟基准）', '- export 测试 23/23'] },
      { id: 'a2', name: 'export-bench.json', type: '基准结果', size: '14 KB', preview: ['{', '  "rows": 1200000,', '  "peakRssMb": 212,', '  "durationSec": 41.8,', '  "baseline": { "peakRssMb": 1874 }', '}'] },
    ],
    summary: '完成了。导出现在按 500 行一页流式写入，CSV 列顺序与转义规则未变。共 3 处改动等你审阅——第 2 处涉及取消逻辑，建议重点看。',
    applyTarget: '工作区文件（模拟）',
  },
  tiles: {
    id: 'tiles', kind: 'code',
    ask: '离线瓦片缓存超过 8 GB 时清理最久未访问的瓦片，用户收藏的区域不能删。',
    intent: {
      goal: '缓存上限 8 GB，超出时按 LRU 清理；收藏区域内的瓦片永不清理。',
      change: 'src-tauri/src/cache/evict.rs · cache/mod.rs 注册任务',
      avoid: '瓦片下载逻辑、收藏数据结构、前端设置页',
      done: '模拟 12 GB 缓存清理到 ≤ 8 GB；收藏区域瓦片 100% 保留；cargo test cache 通过',
    },
    perms: [
      { id: 'write', object: 'src-tauri/src/cache/', action: '新建 1 个文件、修改 1 个文件', scope: '写入前自动快照，可整体回滚', icon: 'file' },
      { id: 'exec', object: 'cargo test cache', action: '在本机终端运行', scope: '无网络 · 超时 300 秒', icon: 'terminal' },
    ],
    steps: [
      { label: '读取 cache/mod.rs 与 favorites.rs', kind: 'read', detail: '只读 · 2 文件', log: ['read src-tauri/src/cache/mod.rs', 'read src-tauri/src/favorites.rs'] },
      { label: '规划：按 last_access 排序，跳过收藏 bbox', kind: 'think', detail: '第 {rev} 轮', log: ['plan: sqlite index on last_access', 'skip tiles intersecting favorite bbox'] },
      { label: '新建 cache/evict.rs', kind: 'write', detail: '+64', log: ['snapshot #7c02 created', 'write src-tauri/src/cache/evict.rs (+64)'], writes: ['src-tauri/src/cache/evict.rs'] },
      { label: '修改 cache/mod.rs 注册清理任务', kind: 'write', detail: '+9 −1', log: ['write src-tauri/src/cache/mod.rs (+9 −1)'], writes: ['src-tauri/src/cache/mod.rs'] },
      { label: '运行 cargo test cache', kind: 'exec', detail: '本机终端', log: ['$ cargo test cache', 'running 11 tests', 'test result: ok. 11 passed'] },
      { label: '汇总改动与验收建议', kind: 'think', detail: '', log: ['summary ready · 2 hunks'] },
    ],
    failStep: 4,
    failLog: ['$ cargo test cache', 'test evict::keeps_favorites ... FAILED', "thread panicked at 'tile 14/13421/6203 evicted'", 'test result: FAILED. 10 passed; 1 failed'],
    failFix: '我读了失败日志：收藏区域边缘的瓦片 14/13421/6203 被清理了，判断只看了瓦片中心点。已改为先跳过所有收藏瓦片再清理，重新运行该步。',
    versions: {
      1: [
        { id: 't1', file: 'src-tauri/src/cache/evict.rs', range: '新文件 · +64', why: '按最近访问时间清理，收藏区域跳过', lines: [['+', 'pub fn evict(db: &Db, cap: u64, favs: &[BBox]) -> Result<u64> {'], ['+', '    let mut size = db.total_size()?;'], ['+', '    for t in db.tiles_by_last_access()? {'], ['+', '        if size <= cap { break }'], ['+', '        if favs.iter().any(|b| b.contains(&t)) { continue }'], ['+', '        size -= db.remove(&t)?;'], ['+', '    }'], ['+', '    Ok(size)'], ['+', '}']] },
        { id: 't2', file: 'src-tauri/src/cache/mod.rs', range: '@@ -31,3 +31,11 @@', why: '启动后与每 6 小时检查一次', lines: [[' ', 'pub fn init(app: &AppHandle) {'], ['+', '    let cap = 8 * GIB;'], ['+', '    schedule(Duration::from_secs(6 * 3600), move || evict(&db(), cap, &favorites()));'], [' ', '}']] },
      ],
      2: [
        { id: 't1b', file: 'src-tauri/src/cache/evict.rs', range: '@@ -5,1 +5,1 @@', why: '按你的意见：收藏判断用瓦片边界相交而不是中心点', lines: [['-', '        if favs.iter().any(|b| b.contains(&t)) { continue }'], ['+', '        if favs.iter().any(|b| b.intersects(&t.bounds())) { continue }']] },
      ],
      3: [
        { id: 't3', file: 'src-tauri/src/cache/evict.rs', range: '@@ -2,1 +2,2 @@', why: '验收失败修复：清理期间暂停下载写入，避免统计漂移', lines: [['+', '    let _guard = db.pause_writes();'], [' ', '    let mut size = db.total_size()?;']] },
      ],
    },
    checks: [
      { id: 'k1', label: '12 GB 模拟缓存清理到 ≤ 8 GB', how: '模拟 · 7.94 GB', failText: '清理后 8.31 GB：清理中仍有下载写入' },
      { id: 'k2', label: '收藏区域瓦片全部保留', how: '3 个收藏区 · 41,208 / 41,208' },
      { id: 'k3', label: '在真机上确认清理不卡顿 UI', how: '需要你在设备上观察', manual: true },
    ],
    artifacts: [
      { id: 'b1', name: '缓存清理说明.md', type: 'Markdown', size: '1.4 KB', preview: ['# 离线瓦片缓存清理', '', '- 上限 8 GB，每 6 小时检查', '- 按 last_access 由旧到新', '- 与收藏区域边界相交的瓦片跳过'] },
    ],
    summary: '完成了。新增按最近访问时间的清理任务，收藏区域会被跳过。2 处改动等你审阅；收藏判断目前用的是包含关系，你可能想改成相交。',
    applyTarget: '工作区文件（模拟）',
  },
  digest: {
    id: 'digest', kind: 'doc',
    ask: '把 Q3 复盘的 12 篇草稿整理成一页纪要，列出三个最大的风险。',
    intent: {
      goal: '一页纪要：结论、三项最大风险（附出处）、待决事项。',
      change: '不改动文件夹；纪要保存到 Pioneer 产物库',
      avoid: '原始草稿（文件夹只读）、任何外部分享',
      done: '每条风险都能定位到原文段落；篇幅 ≤ 1 页；没有原文之外的数字',
    },
    perms: [
      { id: 'read', object: 'C:\\Users\\lin\\Documents\\Q3\\', action: '读取 12 个 Markdown 文件', scope: '只读 · 不写入、不上传', icon: 'book' },
    ],
    steps: [
      { label: '读取 12 篇草稿', kind: 'read', detail: '只读 · 18,240 字', log: ['read 12 files (18,240 chars)'] },
      { label: '抽取结论与风险，记录出处', kind: 'think', detail: '第 {rev} 轮', log: ['extract: 9 claims, 7 risks', 'rank by mentions × severity'] },
      { label: '生成纪要草稿', kind: 'write', detail: '产物库 · 不写入文件夹', log: ['artifact: Q3-复盘纪要.md'], writes: ['产物 / Q3-复盘纪要.md'] },
      { label: '逐条核对出处', kind: 'exec', detail: '本地比对', log: ['verify citations 7/7 matched'] },
      { label: '汇总', kind: 'think', detail: '', log: ['summary ready'] },
    ],
    failStep: 3,
    failLog: ['verify citations', '✕ 风险 2「渠道返点」出处未找到：08-渠道.md 已在读取后被修改', 'matched 6 / 7'],
    failFix: '我读了失败日志：08-渠道.md 在我读取后被修改，风险 2 的出处对不上。已重新读取该文件并重新核对引用，重新运行该步。',
    versions: {
      1: [
        { id: 'd1', file: '产物 / Q3-复盘纪要.md', range: '新产物 · 31 行', why: '一页纪要初稿', lines: [['+', '# Q3 复盘纪要'], ['+', '结论：增长主要来自老客户续费（+18%），新客获取成本上升 32%。'], ['+', '## 三项最大风险'], ['+', '1. 华东大客户集中度 41%  —— 03-客户.md §2'], ['+', '2. 渠道返点政策 11 月到期 —— 08-渠道.md §1'], ['+', '3. 交付人力缺口 6 人   —— 11-交付.md §4'], ['+', '## 待决'], ['+', '- 是否续签渠道返点（10/20 前）']] },
      ],
      2: [
        { id: 'd1b', file: '产物 / Q3-复盘纪要.md', range: '修订 · 第 2 项', why: '按你的意见：风险 2 换成更有依据的现金流项', lines: [['-', '2. 渠道返点政策 11 月到期 —— 08-渠道.md §1'], ['+', '2. 回款周期拉长至 74 天   —— 06-财务.md §3']] },
      ],
      3: [
        { id: 'd2', file: '产物 / Q3-复盘纪要.md', range: '修订 · 出处', why: '验收失败修复：补上段落行号', lines: [['-', '1. 华东大客户集中度 41%  —— 03-客户.md §2'], ['+', '1. 华东大客户集中度 41%  —— 03-客户.md §2 (L18–24)']] },
      ],
    },
    checks: [
      { id: 'g1', label: '每条风险都能定位到原文段落', how: '3 / 3 出处可打开', failText: '风险 1 只定位到章节，未定位到段落' },
      { id: 'g2', label: '纪要不超过一页', how: '31 行 · A4 0.8 页' },
      { id: 'g3', label: '你确认结论措辞可以对内发出', how: '需要你阅读后确认', manual: true },
    ],
    artifacts: [
      { id: 'n1', name: 'Q3-复盘纪要.md', type: 'Markdown', size: '1.9 KB', preview: ['# Q3 复盘纪要', '', '结论：增长主要来自老客户续费（+18%），新客获取成本上升 32%。', '', '## 三项最大风险', '1. 华东大客户集中度 41% — 03-客户.md §2', '2. 回款周期拉长至 74 天 — 06-财务.md §3', '3. 交付人力缺口 6 人 — 11-交付.md §4'] },
    ],
    summary: '纪要初稿好了，三项风险都附了出处。第 2 项「渠道返点」依据较弱（只有一篇提到），你可以退回让我换一项。',
    applyTarget: 'Pioneer 产物库（文件夹只读，不会写入）',
  },
  recon: {
    id: 'recon', kind: 'report',
    ask: '生成 9 月对账差异报表，按渠道汇总。',
    intent: { goal: '按渠道汇总 9 月账单与到账差异', change: '只读数据库；报表保存到产物库', avoid: '任何写库操作', done: '差异合计与总账一致' },
    perms: [{ id: 'exec', object: 'pnpm report recon --period 2026-09', action: '在本机终端运行（只读查询）', scope: '无网络 · 超时 120 秒', icon: 'terminal' }],
    steps: [
      { label: '读取 9 月账单与到账流水', kind: 'read', detail: '只读 · 2 张表', log: ['read invoices where period=2026-09 → 48,213 rows', 'read settlements where period=2026-09 → 47,960 rows'] },
      { label: '按渠道对齐并计算差异', kind: 'think', detail: '第 {rev} 轮', log: ['join on invoice_no', 'group by channel', '253 unmatched rows'] },
      { label: '运行 pnpm report recon', kind: 'exec', detail: '本机终端 · 只读', log: ['$ pnpm report recon --period 2026-09', 'wrote artifacts/recon-2026-09.xlsx (sim)', 'total diff ¥ 18,406.20'] },
      { label: '核对合计与总账', kind: 'think', detail: '', log: ['ledger diff ¥ 18,406.20 = report total ✓'] },
    ],
    failStep: 2,
    failLog: ['$ pnpm report recon --period 2026-09', '✕ channel "线下-华南" has 0 settlements', 'report aborted'],
    failFix: '线下-华南 9 月尚未导入到账流水，我会把它标为「待到账」单列，不计入差异合计。',
    versions: { 1: [] },
    checks: [
      { id: 'r1', label: '差异合计与总账一致', how: '¥ 18,406.20 = 总账差异', evidence: ['总账 2026-09 应收 − 实收 = ¥ 18,406.20', '报表合计行 = ¥ 18,406.20', '来源：ledger_monthly (只读查询 #q-0930-1)'] },
      { id: 'r2', label: '每个渠道都有差异明细', how: '6 / 6 渠道', evidence: ['明细页共 253 行，覆盖 6 个渠道', '每行可追溯 invoice_no'] },
      { id: 'r3', label: '未匹配记录单独列出', how: '253 行 · 另附 sheet', evidence: ['sheet「未匹配」253 行', '其中 41 行为跨月到账，已标注'] },
      { id: 'r4', label: '你确认口径可以发给财务', how: '9 月 30 日 18:10 由你确认', manual: true, evidence: ['确认人：你（本机）', '确认时间：2026-09-30 18:10'] },
    ],
    artifacts: [
      { id: 'p1', name: '9 月对账差异报表.xlsx', type: '表格 · 3 页', size: '86 KB', preview: [],
        table: { cols: ['渠道', '应收', '实收', '差异', '笔数'], rows: [
          ['线上-自营', '¥ 1,284,300.00', '¥ 1,281,912.40', '¥ 2,387.60', '61'],
          ['线上-分销', '¥ 642,118.50', '¥ 636,004.10', '¥ 6,114.40', '88'],
          ['线下-华东', '¥ 911,540.00', '¥ 909,880.00', '¥ 1,660.00', '24'],
          ['线下-华南', '¥ 503,276.00', '¥ 497,940.80', '¥ 5,335.20', '47'],
          ['企业直签', '¥ 1,820,000.00', '¥ 1,818,240.00', '¥ 1,760.00', '9'],
          ['海外', '¥ 214,880.00', '¥ 213,731.00', '¥ 1,149.00', '24'],
        ], foot: ['合计', '¥ 5,376,114.50', '¥ 5,357,708.30', '¥ 18,406.20', '253'] } },
      { id: 'p2', name: '对账口径说明.md', type: 'Markdown', size: '1.2 KB', preview: ['# 9 月对账口径', '', '- 以开票日期归属账期', '- 到账以银行回单日期为准', '- 跨月到账单列，不计入当月差异', '- 退款按原渠道冲减'] },
    ],
    summary: '报表已生成：6 个渠道差异合计 ¥ 18,406.20，与总账一致。253 条未匹配记录单列在第 3 页。',
    applyTarget: 'Pioneer 产物库',
  },
}

export const scriptFor = (ws: string): ScriptId => (ws === 'atlas' ? 'tiles' : ws === 'notes' ? 'digest' : 'invoice')

export const DEFAULT_WORKSPACES: Workspace[] = [
  { id: 'billing', name: 'billing-service', path: 'D:\\work\\billing-service', kind: 'TypeScript · Node 22', cover: 'code', tint: '#dce9df', note: '发票导出与对账', added: 1 },
  { id: 'atlas', name: 'atlas-desktop', path: 'D:\\work\\atlas-desktop', kind: 'Rust · Tauri 2', cover: 'map', tint: '#e4e6e3', note: '离线地图客户端', added: 2 },
  { id: 'notes', name: 'Q3 复盘草稿', path: 'C:\\Users\\lin\\Documents\\Q3', kind: 'Markdown · 12 篇', cover: 'doc', tint: '#f1e9de', note: '只读文件夹', readOnly: true, added: 3 },
  { id: 'brand', name: 'hazel-assets', path: 'E:\\design\\hazel\\2026\\autumn-campaign\\exports\\final-final', kind: '图像 · 214 项', cover: 'image', tint: '#ebdada', note: '素材整理', unavailable: '驱动器 E: 未连接', added: 4 },
]

/** Simulated folder picker — not the real file system. */
export const FAKE_FS = [
  { path: 'D:\\work\\ledger-api', kind: 'Go 1.23', cover: 'code' as const, tint: '#dfe5ea' },
  { path: 'D:\\work\\design-tokens', kind: 'JSON · 86 项', cover: 'doc' as const, tint: '#eceae4' },
  { path: 'C:\\Users\\lin\\Pictures\\2026-09', kind: '图像 · 1,204 项', cover: 'image' as const, tint: '#ebdada' },
]

export const CAPS = [
  { id: 'read', label: '读取工作区文件', state: 'ok', reason: '本机执行器内置' },
  { id: 'write', label: '写入工作区文件', state: 'ok', reason: '每次任务需要授权', perm: true },
  { id: 'exec', label: '运行终端命令', state: 'ok', reason: '每次任务需要授权', perm: true },
  { id: 'net', label: '网络访问', state: 'unset', reason: '未配置代理与白名单' },
  { id: 'browser', label: '浏览器自动化', state: 'unset', reason: '未安装扩展' },
  { id: 'git', label: '推送到远程仓库', state: 'off', reason: '原型不连接 Git 远程' },
] as const

let n = 0
export const uid = (p = 'b') => `${p}${Date.now().toString(36)}${(n++).toString(36)}`

export const group = (tabs: ModuleId[], active = tabs[0]): PNode => ({ k: 'group', id: uid('g'), tabs, active })
/** default composition: just the conversation. Everything else is added on demand. */
export const baseLayout = (): Layout => { const g = group(['chat']); return { root: g, focus: g.id, recent: [] } }
const sideBySide = (side: ModuleId[], ratio: number): Layout => {
  const a = group(['chat']), b = group(side)
  return { root: { k: 'split', id: uid('x'), dir: 'row', ratio, a, b }, focus: a.id, recent: [] }
}

export function ctxFor(script: ScriptId): Ctx[] {
  if (script === 'tiles') return [
    { id: 'x1', label: 'src-tauri/src/cache/mod.rs', meta: '自动 · 88 行', state: 'in', source: ['pub mod store;', 'pub fn init(app: &AppHandle) {', '    // TODO: eviction', '}'] },
    { id: 'x2', label: 'src-tauri/src/favorites.rs', meta: '自动 · 140 行', state: 'in', source: ['pub struct BBox { min: LatLng, max: LatLng }', 'impl BBox { pub fn contains(&self, t: &Tile) -> bool { … } }'] },
    { id: 'x3', label: 'docs/cache-policy.md', meta: '建议加入', state: 'suggested', source: ['# 缓存策略', '上限默认 8 GB，可在设置中调整。'] },
  ]
  if (script === 'digest') return [
    { id: 'x1', label: 'Q3\\*.md（12 篇）', meta: '你附加的', state: 'in', source: ['01-总览.md', '02-增长.md', '03-客户.md', '…', '12-下季度.md'] },
    { id: 'x2', label: 'Q3\\08-渠道.md', meta: '读取后被修改', state: 'stale', source: ['## 渠道返点', '（此段落于 09:42 被删除）'] },
  ]
  if (script === 'recon') return [
    { id: 'x1', label: 'db: invoices / settlements（2026-09）', meta: '只读查询', state: 'in', source: ['SELECT channel, SUM(amount) FROM invoices', "WHERE period = '2026-09' GROUP BY channel"] },
    { id: 'x2', label: 'docs/billing/periods.md', meta: '你附加的', state: 'in', source: ['# 账期', '每月 1 日 00:00 (UTC+8) 切分。'] },
    { id: 'x3', label: 'ledger_monthly · 总账', meta: '建议加入', state: 'suggested', source: ['2026-09  应收 5,376,114.50  实收 5,357,708.30'] },
  ]
  return [
    { id: 'x1', label: 'src/export/invoice.ts', meta: '自动 · 412 行', state: 'in', source: ['export async function exportInvoices(period: Period, out: Writable) {', '  const rows = await repo.findAll(period)', '  const csv = rows.map(toCsvRow).join("\\n")', '  out.write(csv)', '}'] },
    { id: 'x2', label: 'docs/billing/periods.md', meta: '你附加的', state: 'in', source: ['# 账期', '每月 1 日 00:00 (UTC+8) 切分。', '大客户单期可达 120 万行。'] },
    { id: 'x3', label: 'src/db/repo.ts', meta: '建议加入', state: 'suggested', source: ['export const repo = {', '  findAll, paginate, releaseCursor,', '}'] },
    { id: 'x4', label: 'wiki: 导出规范（旧链接）', meta: '来源失效 · 404', state: 'stale', source: ['无法读取：链接已失效。'] },
  ]
}

export function newSession(title: string, workspace: string): Session {
  const script = scriptFor(workspace)
  return {
    id: uid('s'), title, workspace, script, phase: 'empty', step: 0, attempt: 1, version: 1, intentRev: 0,
    blocks: [], draft: '', queued: [], permMode: 'ask', model: 'claude-opus-5-5', allowed: [], hunks: {}, rejectNotes: {}, applied: [], checks: {}, manualOk: false,
    layout: baseLayout(), context: ctxFor(script), updated: Date.now(), rounds: [],
  }
}

export function seedSessions(): Session[] {
  const now = Date.now()
  const live = newSession('流式发票导出', 'billing')
  live.id = 's-live'
  live.draft = SCRIPTS.invoice.ask
  live.updated = now - 12 * 60e3
  live.layout = sideBySide(['context', 'log'], 0.64)

  const recon: Session = {
    ...newSession('9 月对账差异报表', 'billing'), id: 's-recon', phase: 'delivered', step: 4, updated: now - 26 * 3600e3,
    blocks: [
      { id: 'r1', kind: 'user', text: '生成 9 月对账差异报表，按渠道汇总。' },
      { id: 'r2', kind: 'agent', text: '报表已生成，4 项验收标准均通过，已交付到产物库。' },
      { id: 'r3', kind: 'notice', tone: 'ok', text: '9 月 30 日 18:12 交付 · 记录保存在本机' },
    ],
    script: 'recon', context: ctxFor('recon'), version: 1, manualOk: true,
    checks: { r1: 'pass', r2: 'pass', r3: 'pass', r4: 'manual' },
    rounds: [{ at: now - 26.2 * 3600e3, label: '报表已生成 · 待验收', tone: 'neutral' }, { at: now - 26.1 * 3600e3, label: '验收通过', tone: 'ok' }, { at: now - 26 * 3600e3, label: 'v1 已交付', tone: 'ok' }],
  }
  recon.blocks = [
    { id: 'r1', kind: 'user', text: SCRIPTS.recon.ask },
    { id: 'r1p', kind: 'permission', perm: 'exec', step: 2, state: 'once' },
    { id: 'r1r', kind: 'run', attempt: 1, version: 1 },
    { id: 'r2', kind: 'agent', text: SCRIPTS.recon.summary, cta: 'deliver' },
    { id: 'r3', kind: 'notice', tone: 'ok', text: '9 月 30 日 18:12 交付 v1 · 报表与验收记录保存在本机（模拟）' },
  ]

  const tiles = newSession('瓦片缓存清理', 'atlas')
  tiles.id = 's-tiles'
  tiles.phase = 'review'
  tiles.step = 6
  tiles.intentRev = 1
  tiles.updated = now - 3 * 3600e3
  tiles.hunks = { t1: 'pending', t2: 'accepted' }
  tiles.layout = sideBySide(['changes', 'deliver'], 0.46)
  tiles.blocks = [
    { id: 'u1', kind: 'user', text: SCRIPTS.tiles.ask },
    { id: 'u3', kind: 'permission', perm: 'write', step: 2, state: 'session' },
    { id: 'u4', kind: 'run', attempt: 1, version: 1 },
    { id: 'u5', kind: 'agent', text: SCRIPTS.tiles.summary, cta: 'review' },
  ]

  const digest = newSession('Q3 复盘纪要', 'notes')
  digest.id = 's-digest'
  digest.permMode = 'read'
  digest.phase = 'stopped'
  digest.step = 2
  digest.intentRev = 1
  digest.updated = now - 4 * 86400e3
  digest.draft = '先别生成纪要，我想加一条：风险要按金额影响排序。'
  digest.blocks = [
    { id: 'g1', kind: 'user', text: SCRIPTS.digest.ask },
    { id: 'g4', kind: 'run', attempt: 1, version: 1 },
    { id: 'g5', kind: 'notice', tone: 'neutral', text: '你在第 3 步前停止了任务。已读取的内容保留在上下文中，没有生成任何产物。' },
  ]
  return [live, recon, tiles, digest]
}

export const rel = (t: number) => {
  const d = (Date.now() - t) / 60e3
  if (d < 1) return '刚刚'
  if (d < 60) return `${Math.round(d)} 分钟前`
  if (d < 1440) return `${Math.round(d / 60)} 小时前`
  return `${Math.round(d / 1440)} 天前`
}
