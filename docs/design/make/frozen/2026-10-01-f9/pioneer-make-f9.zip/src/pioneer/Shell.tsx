import { useState } from 'react'
import type { Session, Workspace } from './data'
import { isActive } from './flow'
import { elide, phaseInfo } from './Session'
import { Button, Icon, Kbd, Mark, ProtoTag } from './ui'
import type { PetState } from './Pet'

export type Win = 'normal' | 'maximized' | 'fullscreen' | 'minimized' | 'closed' | 'quit'
export type Preset = 'wide' | 'narrow' | 'short'

const DOT = { run: 'bg-navy', ok: 'bg-mint-ink', warn: 'bg-gold', bad: 'bg-berry', neutral: 'bg-silver', local: 'bg-control' }

/* ───────── title bar ───────── */

export function TitleBar(p: {
  win: Win; setWin: (w: Win) => void; focused: boolean; closeWindow: () => void
  sessions: Session[]; openIds: string[]; active: string; setActive: (id: string) => void; closeTab: (id: string) => void
  reorder: (from: string, to: string) => void; rename: (id: string, t: string) => void
  closed: Session[]; reopen: (id: string) => void
  onNew: () => void; narrow: boolean; pet: PetState; togglePet: () => void; onNotes: () => void; onPalette: () => void; onSettings: () => void
}) {
  const [hover, setHover] = useState(false)
  const [drag, setDrag] = useState<string | null>(null)
  const [edit, setEdit] = useState<string | null>(null)
  const [menu, setMenu] = useState(false)
  const full = p.win === 'fullscreen'
  const max = p.win === 'maximized'
  const tabs = p.openIds.map(id => p.sessions.find(s => s.id === id)).filter(Boolean) as Session[]
  return (
    <div onDoubleClick={e => { if (e.target === e.currentTarget && !full) p.setWin(max ? 'normal' : 'maximized') }}
      className="h-11 shrink-0 flex items-center gap-2 pl-4 pr-2 bg-canvas border-b border-silver/70 relative z-40" title="">
      <div className="flex items-center gap-2 mr-2" onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)} role="group" aria-label="窗口控制">
        <Light color="#ec6a5e" glyph="×" hover={hover} inactive={!p.focused} label="关闭窗口（应用继续在托盘运行，不会退出）" onClick={p.closeWindow} />
        <Light color="#f4bf4f" glyph="−" hover={hover} inactive={!p.focused} label={full ? '全屏时不可最小化' : '最小化'} onClick={() => p.setWin('minimized')} disabled={full} />
        <Light color="#61c554" glyph={full ? '↙' : '↗'} hover={hover} inactive={!p.focused} label={full ? '退出全屏 (F11)' : '全屏 (F11) · 最大化请双击标题栏'} onClick={() => p.setWin(full ? 'normal' : 'fullscreen')} />
      </div>

      <div className="flex-1 min-w-0 flex items-center gap-1 overflow-x-auto scroll-quiet" role="tablist" aria-label="会话标签" onDoubleClick={e => e.stopPropagation()}>
        <button role="tab" aria-selected={p.active === 'home'} onClick={() => p.setActive('home')} title="工作区 (Alt+0)"
          className={`ring-focus h-8 px-2.5 rounded-lg inline-flex items-center gap-1.5 text-[12.5px] font-medium shrink-0 ${p.active === 'home' ? 'bg-paper text-ink shadow-[0_0_0_1px_var(--color-silver)]' : 'text-ink-2 hover:bg-muted'}`}>
          <Icon name="grid" size={14} />{!p.narrow && '工作区'}
        </button>
        <span className="w-px h-4 bg-silver mx-1 shrink-0" />
        {tabs.map(s => {
          const ph = phaseInfo(s)
          const on = p.active === s.id
          return (
            <div key={s.id} role="tab" aria-selected={on} tabIndex={0} draggable={edit !== s.id}
              onDragStart={e => { setDrag(s.id); e.dataTransfer.effectAllowed = 'move' }} onDragEnd={() => setDrag(null)}
              onDragOver={e => { e.preventDefault(); if (drag && drag !== s.id) p.reorder(drag, s.id) }}
              onClick={() => p.setActive(s.id)} onDoubleClick={() => setEdit(s.id)}
              onKeyDown={e => { if (e.target !== e.currentTarget) return; if (e.key === 'Enter') p.setActive(s.id); if (e.key === 'F2') setEdit(s.id) }}
              onAuxClick={e => e.button === 1 && p.closeTab(s.id)}
              title={`${s.title} · ${ph.label} · 双击重命名 · 拖动排序`}
              className={`ring-focus group h-8 pl-2.5 pr-1 rounded-lg inline-flex items-center gap-2 text-[12.5px] cursor-default shrink-0 ${p.narrow ? 'max-w-[140px]' : 'max-w-[200px]'} ${on ? 'bg-paper text-ink shadow-[0_0_0_1px_var(--color-silver)]' : 'text-ink-2 hover:bg-muted'} ${drag === s.id ? 'opacity-50' : ''}`}>
              <span className={`size-1.5 rounded-full shrink-0 ${DOT[ph.tone]} ${ph.pulse ? 'anim-pulse' : ''}`} aria-label={ph.label} />
              {edit === s.id ? (
                <input autoFocus defaultValue={s.title} maxLength={40} aria-label="重命名标签" onClick={e => e.stopPropagation()}
                  onBlur={e => { p.rename(s.id, e.target.value); setEdit(null) }}
                  onKeyDown={e => { e.stopPropagation(); if (e.nativeEvent.isComposing) return; if (e.key === 'Enter') (e.target as HTMLInputElement).blur(); if (e.key === 'Escape') setEdit(null) }}
                  className="w-28 h-6 rounded border border-control bg-paper px-1 outline-none text-ink" />
              ) : <span className="truncate">{s.title}</span>}
              <button onClick={e => { e.stopPropagation(); p.closeTab(s.id) }} className={`ring-focus size-5 grid place-items-center rounded text-ink-2 hover:bg-silver/60 ${on ? 'opacity-100' : 'opacity-0 group-hover:opacity-100 focus:opacity-100'}`} aria-label={`关闭标签 ${s.title}（不删除会话、不停止任务）`} title="关闭标签 (Alt+W) · 不删除、不停止">
                <Icon name="x" size={11} />
              </button>
            </div>
          )
        })}
        <button onClick={p.onNew} className="ring-focus size-8 rounded-lg grid place-items-center text-ink-2 hover:bg-muted shrink-0" title="新会话 (Alt+N)" aria-label="新会话"><Icon name="plus" size={14} /></button>
      </div>

      <div className="flex items-center gap-0.5 shrink-0 relative">
        {(tabs.length > 3 || p.closed.length > 0) && (
          <button onClick={() => setMenu(m => !m)} aria-expanded={menu} aria-haspopup="menu" className="ring-focus h-8 px-1.5 rounded-lg text-ink-2 hover:bg-muted inline-flex items-center gap-0.5 text-[11.5px]" title="全部标签与最近关闭">
            <span className="font-mono">{tabs.length}</span><Icon name="down" size={12} />
          </button>
        )}
        {menu && (
          <div role="menu" className="anim-rise absolute top-10 right-0 w-72 max-h-[360px] overflow-auto scroll-quiet rounded-xl bg-paper border border-silver shadow-xl p-1.5 text-[13px]" onMouseLeave={() => setMenu(false)} onKeyDown={e => e.key === 'Escape' && setMenu(false)}>
            <div className="px-2.5 pt-1 pb-1 text-[11px] text-ink-2">打开的标签 · {tabs.length}</div>
            {tabs.map(s => <button key={s.id} role="menuitem" onClick={() => { p.setActive(s.id); setMenu(false) }} className="ring-focus w-full text-left px-2.5 h-8 rounded-md hover:bg-muted flex items-center gap-2"><span className={`size-1.5 rounded-full ${DOT[phaseInfo(s).tone]}`} /><span className="truncate flex-1">{s.title}</span>{p.active === s.id && <Icon name="check" size={12} />}</button>)}
            {p.closed.length > 0 && <>
              <div className="px-2.5 pt-2 pb-1 text-[11px] text-ink-2 border-t border-silver/60 mt-1">最近关闭 · Alt+Shift+T</div>
              {p.closed.slice(-5).reverse().map(s => <button key={s.id} role="menuitem" onClick={() => { p.reopen(s.id); setMenu(false) }} className="ring-focus w-full text-left px-2.5 h-8 rounded-md hover:bg-muted flex items-center gap-2"><Icon name="undo" size={12} className="text-control" /><span className="truncate flex-1">{s.title}</span><span className="text-[11px] text-ink-2">{phaseInfo(s).label}</span></button>)}
            </>}
          </div>
        )}
        {!p.narrow && <button onClick={p.onPalette} className="ring-focus h-8 px-2 rounded-lg text-[12px] text-ink-2 hover:bg-muted inline-flex items-center gap-2"><Icon name="search" size={13} />命令 <Kbd>Ctrl K</Kbd></button>}
        <button onClick={p.togglePet} aria-pressed={p.pet === 'out'} className={`ring-focus size-8 rounded-lg grid place-items-center hover:bg-muted ${p.pet === 'out' ? '' : 'opacity-50'}`} title={p.pet === 'out' ? '收起桌宠' : '叫回桌宠'} aria-label="桌宠开关">
          <img src="/assets/hazel/jelly-outline.svg" alt="" className="size-[18px]" />
        </button>
        <button onClick={p.onSettings} className="ring-focus size-8 rounded-lg grid place-items-center text-ink-2 hover:bg-muted" title="设置 (Alt+,)" aria-label="设置"><Icon name="gear" /></button>
        <button onClick={p.onNotes} className="ring-focus size-8 rounded-lg grid place-items-center text-ink-2 hover:bg-muted" title="设计说明" aria-label="设计说明"><Icon name="info" /></button>
      </div>
    </div>
  )
}

/** Traffic light: normal (colour), hover (glyph), inactive window (grey), disabled (grey, no glyph). */
function Light({ color, glyph, hover, inactive, label, onClick, disabled }: { color: string; glyph: string; hover: boolean; inactive: boolean; label: string; onClick: () => void; disabled?: boolean }) {
  const bg = disabled ? '#dcdbd6' : inactive && !hover ? '#cfcfcb' : color
  return (
    <button onClick={onClick} disabled={disabled} aria-label={label} title={label}
      className="ring-focus size-3 rounded-full grid place-items-center text-[9px] leading-none font-bold text-black/55 disabled:cursor-not-allowed" style={{ background: bg, boxShadow: 'inset 0 0 0 .5px rgba(0,0,0,.18)' }}>
      <span className={hover && !disabled ? 'opacity-100' : 'opacity-0'}>{glyph}</span>
    </button>
  )
}

export function StatusBar({ cur, ws, short, running, save, retry, connected, onKeys }: { cur?: Session; ws?: Workspace; short: boolean; running: number; save: 'ok' | 'error' | 'pending'; retry: () => void; connected: boolean; onKeys: () => void }) {
  if (short && save !== 'error') return null
  return (
    <div className="h-7 shrink-0 flex items-center gap-4 px-4 border-t border-silver/70 bg-canvas text-[11.5px] text-ink-2 overflow-hidden">
      <span className={`inline-flex items-center gap-1.5 shrink-0 ${connected ? '' : 'text-berry'}`}><Icon name="wifi" size={12} />{connected ? '本机执行器 · 模拟' : '执行器未连接'}</span>
      {ws && <span className="font-mono truncate min-w-0" title={ws.path}>{elide(ws.path, 52)}</span>}
      <span className="shrink-0">{running ? `${running} 个任务运行中` : '空闲'}</span>
      <span className="flex-1" />
      {save === 'error'
        ? <span role="status" className="inline-flex items-center gap-1.5 text-berry shrink-0"><Icon name="alert" size={12} />未保存 · 本地存储写入失败<button onClick={retry} className="ring-focus underline">重试</button></span>
        : <span className="shrink-0">{save === 'pending' ? '保存中…' : '已保存到本机'}</span>}
      <ProtoTag className="shrink-0" />
      <button onClick={onKeys} className="ring-focus inline-flex items-center gap-1 hover:text-ink shrink-0"><Icon name="keyboard" size={12} />快捷键</button>
    </div>
  )
}

/* ───────── overlays ───────── */

export function Overlay({ children, close, className = '', label }: { children: React.ReactNode; close: () => void; className?: string; label: string }) {
  return (
    <div className="absolute inset-0 z-50 bg-ink/15 grid place-items-start justify-center pt-[10vh] px-4" onMouseDown={e => e.target === e.currentTarget && close()}>
      <div role="dialog" aria-modal aria-label={label} className={`anim-rise w-full rounded-2xl bg-paper border border-silver shadow-[0_24px_60px_-20px_rgba(37,44,59,.45)] overflow-hidden ${className}`}>{children}</div>
    </div>
  )
}

export const CMDS = [
  ['home', '回到工作区', 'Alt 0'], ['new', '新会话', 'Alt N'], ['dock', '面板：打开、关闭、恢复', 'Alt \\'], ['reopen', '重新打开关闭的标签', 'Alt ⇧ T'],
  ['settings', '设置', 'Alt ,'], ['pet', '开启 / 关闭桌宠', ''], ['full', '全屏', 'F11'], ['keys', '查看快捷键', 'Alt /'], ['notes', '设计说明', ''], ['demo', '演示模式：开 / 关', 'Alt ⇧ D'], ['quit', '退出 Pioneer…', 'Alt Q'],
] as const

export function Palette({ close, run }: { close: () => void; run: (k: string) => void }) {
  const [q, setQ] = useState('')
  const [i, setI] = useState(0)
  const list = CMDS.filter(c => c[1].includes(q))
  return (
    <Overlay close={close} className="max-w-[520px]" label="命令面板">
      <div className="flex items-center gap-2 px-4 h-12 border-b border-silver/70">
        <Icon name="search" className="text-control" />
        <input autoFocus value={q} onChange={e => { setQ(e.target.value); setI(0) }} placeholder="输入命令…" aria-label="命令" className="flex-1 bg-transparent outline-none text-[15px]"
          onKeyDown={e => {
            if (e.nativeEvent.isComposing) return
            if (e.key === 'ArrowDown') { e.preventDefault(); setI(x => Math.min(list.length - 1, x + 1)) }
            if (e.key === 'ArrowUp') { e.preventDefault(); setI(x => Math.max(0, x - 1)) }
            if (e.key === 'Enter' && list[i]) run(list[i][0])
            if (e.key === 'Escape') close()
          }} />
      </div>
      <ul className="max-h-[340px] overflow-auto scroll-quiet p-1.5">
        {list.map((c, k) => (
          <li key={c[0]}><button onMouseEnter={() => setI(k)} onClick={() => run(c[0])} className={`w-full flex items-center justify-between px-3 h-9 rounded-lg text-[13.5px] ${k === i ? 'bg-muted' : ''} ${c[0] === 'quit' ? 'text-berry' : ''}`}>
            {c[1]}{c[2] && <Kbd>{c[2]}</Kbd>}
          </button></li>
        ))}
        {!list.length && <li className="px-3 py-6 text-center text-[13px] text-ink-2">没有匹配的命令</li>}
      </ul>
    </Overlay>
  )
}

export function Shortcuts({ close }: { close: () => void }) {
  const rows = [
    ['发送', 'Ctrl Enter（可在设置改为 Enter）'], ['停止运行中的任务', '连按两次 Esc'], ['命令面板', 'Ctrl K'], ['工作区', 'Alt 0'],
    ['新会话', 'Alt N'], ['关闭标签（不停止任务）', 'Alt W'], ['恢复关闭的标签', 'Alt ⇧ T'], ['移动标签', 'Alt ⇧ ← →'], ['重命名标签', '双击 / F2'], ['面板', 'Alt \\'],
    ['设置', 'Alt ,'], ['全屏 / 退出全屏', 'F11'], ['最大化', '双击标题栏'], ['关闭标签', '鼠标中键'], ['退出应用', 'Alt Q'],
  ]
  return (
    <Overlay close={close} className="max-w-[480px]" label="快捷键">
      <div className="px-5 pt-5 pb-1 flex items-center justify-between"><h2 className="text-[16px] font-medium">键盘</h2><Button size="sm" variant="quiet" icon="x" onClick={close} aria-label="关闭" autoFocus /></div>
      <p className="px-5 text-[12px] text-ink-2 mb-2">浏览器会占用 Ctrl+W / N / T / Q，所以原型用 Alt；原生应用改回 Ctrl。输入法选词时 Enter 不会发送。</p>
      <ul className="px-5 pb-5 grid gap-y-0.5 max-h-[50vh] overflow-auto scroll-quiet">
        {rows.map(([a, b]) => <li key={a} className="flex items-center justify-between h-8 text-[13.5px] border-b border-silver/50 last:border-0"><span>{a}</span><Kbd>{b}</Kbd></li>)}
      </ul>
    </Overlay>
  )
}

export function QuitDialog({ running, unsaved, cancel, quit, close }: { running: Session[]; unsaved: boolean; cancel: () => void; quit: () => void; close: () => void }) {
  return (
    <Overlay close={cancel} className="max-w-[460px]" label="退出确认">
      <div className="p-5">
        <h2 className="text-[16px] font-medium mb-2">退出 Pioneer？</h2>
        {running.length > 0 && <p className="text-[14px] leading-[22px] text-ink-2">{running.length} 个任务进行中：{running.map(r => `「${r.title}」`).join('')}。退出会请求<b className="text-ink font-medium">停止</b>它们，已写入的内容保留在快照里，下次可以从停止处继续。</p>}
        {unsaved && <p role="alert" className="mt-2 rounded-lg border border-berry/30 bg-rose/40 px-3 py-2 text-[13px] text-berry">最近的改动没能写入本地存储。现在退出，草稿与标签可能回到上次保存的状态。</p>}
        <p className="text-[13px] leading-5 text-ink-2 mt-2">只想让窗口消失？关闭窗口即可，任务会在后台继续。</p>
      </div>
      <div className="px-5 py-3 bg-canvas border-t border-silver/70 flex flex-wrap justify-end gap-2">
        <Button size="sm" variant="quiet" onClick={cancel} autoFocus>取消</Button>
        <Button size="sm" onClick={close}>只关闭窗口</Button>
        <Button size="sm" variant="danger" onClick={quit}>{running.length ? '停止任务并退出' : '仍然退出'}</Button>
      </div>
    </Overlay>
  )
}

export function QuitScreen({ onRelaunch, sessions }: { onRelaunch: () => void; sessions: Session[] }) {
  const paused = sessions.filter(s => s.phase === 'stopped' || s.phase === 'stopping').length
  return (
    <div className="text-center flex flex-col items-center gap-3">
      <div className="font-mono text-[11px] uppercase tracking-wider text-ink/50">Pioneer 已退出 · 原型模拟</div>
      <p className="text-[13px] text-ink/70 max-w-[320px]">{sessions.length} 个会话与布局保存在本机{paused ? `，${paused} 个任务已停止，可从停止处继续` : ''}。</p>
      <Button variant="primary" onClick={onRelaunch}>重新启动 Pioneer</Button>
    </div>
  )
}

export type Demo = { failRun: boolean; failVerify: boolean; saveFail: boolean }

export function DemoControls(p: {
  open: boolean; setOpen: (v: boolean) => void; preset: Preset; setPreset: (p: Preset) => void
  cur?: Session; disconnect: () => void; demo: Demo; setDemo: (d: Partial<Demo>) => void
  corrupt: () => void; firstUse: boolean; setFirstUse: (b: boolean) => void; reset: () => void
}) {
  if (!p.open) return null
  const seg = (k: Preset, l: string) => <button onClick={() => p.setPreset(k)} aria-pressed={p.preset === k} className={`h-6 px-2 rounded text-[11px] ${p.preset === k ? 'bg-paper text-ink' : 'text-paper/70 hover:text-paper'}`}>{l}</button>
  const chk = (on: boolean, set: (b: boolean) => void, l: string) => <label className="flex items-center gap-2 h-7 px-2 rounded-md bg-paper/10 mb-1 cursor-pointer"><input type="checkbox" checked={on} onChange={e => set(e.target.checked)} className="accent-[#dce9df]" />{l}</label>
  const canDc = !!p.cur && isActive(p.cur)
  return (
    <div className="anim-rise absolute left-3 bottom-2 z-[60] w-[200px] rounded-xl text-paper p-3 text-[11.5px] shadow-xl" style={{ background: 'rgba(37,44,59,.92)' }} aria-label="演示控制（非产品界面）">
      <div className="flex items-center justify-between mb-2"><span className="font-mono uppercase tracking-wider text-[10px] text-paper/60">演示控制 · 非产品 UI</span><button onClick={() => p.setOpen(false)} aria-label="收起演示控制"><Icon name="x" size={11} /></button></div>
      <div className="text-paper/60 mb-1">窗口尺寸</div>
      <div className="flex gap-0.5 p-0.5 rounded-md bg-paper/10 mb-3">{seg('wide', '宽屏')}{seg('narrow', '窄窗')}{seg('short', '短窗')}</div>
      <div className="text-paper/60 mb-1">注入异常</div>
      <button disabled={!canDc} onClick={p.disconnect} title={canDc ? '' : '当前会话没有进行中的步骤'} className="w-full text-left h-7 px-2 rounded-md bg-paper/10 hover:bg-paper/15 disabled:opacity-35 mb-1">断开连接（当前会话）</button>
      {chk(p.demo.failRun, b => p.setDemo({ failRun: b }), '下次运行测试失败')}
      {chk(p.demo.failVerify, b => p.setDemo({ failVerify: b }), '下次验收失败')}
      {chk(p.demo.saveFail, b => p.setDemo({ saveFail: b }), '本地保存失败')}
      <div className="text-paper/60 mt-2 mb-1">数据</div>
      {chk(p.firstUse, p.setFirstUse, '首次使用（无工作区）')}
      <button onClick={p.corrupt} className="w-full text-left h-7 px-2 rounded-md bg-paper/10 hover:bg-paper/15 mb-1">写入损坏数据并重载</button>
      <button onClick={p.reset} className="w-full text-left h-7 px-2 rounded-md hover:bg-paper/10 text-paper/80">重置原型数据…</button>
    </div>
  )
}

export function Taskbar({ win, restore, minimize, running, tray, setTray, askQuit, demoOpen, toggleDemoPanel, exitDemo }: { win: Win; restore: () => void; minimize: () => void; running: number; tray: boolean; setTray: (b: boolean) => void; askQuit: () => void; demoOpen: boolean; toggleDemoPanel: () => void; exitDemo: () => void }) {
  return (
    <div className="h-11 shrink-0 bg-[#e9eae7]/90 backdrop-blur border-t border-black/5 flex items-center px-3 gap-2 relative z-[55]">
      <div className="w-44 flex items-center gap-1">
        <button onClick={toggleDemoPanel} aria-expanded={demoOpen} className={`ring-focus h-7 px-2.5 rounded-md text-[11px] font-mono ${demoOpen ? 'bg-navy text-paper' : 'bg-black/5 text-ink/70 hover:bg-black/10'}`}>演示控制</button>
        <button onClick={exitDemo} className="ring-focus h-7 px-2 rounded-md text-[11px] text-ink/60 hover:bg-black/5" title="退出演示模式 · Alt+Shift+D">退出演示</button>
      </div>
      <div className="flex-1 flex justify-center">
        <button onClick={() => (['minimized', 'closed', 'quit'].includes(win) ? restore() : minimize())}
          className="ring-focus relative size-9 rounded-lg grid place-items-center hover:bg-black/5" title={win === 'quit' ? '启动 Pioneer' : win === 'closed' ? '打开 Pioneer 窗口' : 'Pioneer'} aria-label="任务栏：Pioneer">
          <Mark size={22} />
          {win !== 'quit' && <span className={`absolute bottom-0.5 h-[3px] rounded-full bg-navy transition-all ${win === 'closed' ? 'w-0' : win === 'minimized' ? 'w-1.5' : 'w-4'}`} />}
        </button>
      </div>
      <div className="w-44 flex justify-end relative">
        {win !== 'quit' && (
          <button onClick={() => setTray(!tray)} className="ring-focus h-8 px-2 rounded-md hover:bg-black/5 inline-flex items-center gap-1.5 text-[11.5px] text-ink-2" title="托盘：Pioneer" aria-label="托盘菜单">
            <Mark size={14} />{running > 0 && <span className="size-1.5 rounded-full bg-navy anim-pulse" />}
          </button>
        )}
        {tray && win !== 'quit' && (
          <div role="menu" className="anim-rise absolute bottom-11 right-0 w-64 rounded-xl bg-paper border border-silver shadow-xl p-1.5 text-[13px]">
            <div className="px-2.5 py-2 text-[12px] text-ink-2">{running ? `${running} 个任务在后台进行` : '没有进行中的任务'}</div>
            <button role="menuitem" onClick={restore} className="w-full text-left px-2.5 py-2 rounded-md hover:bg-muted">打开 Pioneer 窗口</button>
            <button role="menuitem" onClick={() => { setTray(false); askQuit() }} className="w-full text-left px-2.5 py-2 rounded-md hover:bg-muted text-berry">退出 Pioneer…</button>
          </div>
        )}
      </div>
    </div>
  )
}
