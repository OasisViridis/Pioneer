import { useState } from 'react'
import { CAPS, SCRIPTS, type Session, type Workspace } from './data'
import { type Action } from './flow'
import { type Op } from './layout'
import { Button, Icon, Status } from './ui'

/* Modules that live in panels. Each is self-contained and never changes the layout by itself. */


export function Context({ s, dispatch }: { s: Session; dispatch: (a: Action) => void }) {
  const [view, setView] = useState<string | null>(null)
  const groups = [['in', '已加入'], ['stale', '已过期'], ['suggested', '建议加入'], ['removed', '已移除']] as const
  return (
    <div className="flex flex-col gap-4">
      {groups.map(([g, l]) => {
        const items = s.context.filter(c => c.state === g)
        if (!items.length) return null
        return (
          <section key={g}>
            <h4 className="text-[11px] text-ink-2 uppercase tracking-[.08em] mb-1.5">{l} · {items.length}</h4>
            <ul className="flex flex-col gap-1.5">
              {items.map(c => (
                <li key={c.id} className={`rounded-lg border px-2.5 py-2 ${g === 'stale' ? 'border-gold/50 bg-gold-soft/40' : 'border-silver'}`}>
                  <div className="flex items-center gap-2">
                    <Icon name={g === 'stale' ? 'alert' : 'file'} size={13} className={g === 'stale' ? 'text-gold' : 'text-control'} />
                    <span className={`font-mono text-[12px] truncate flex-1 ${g === 'removed' ? 'line-through text-ink-2' : ''}`} title={c.label}>{c.label}</span>
                  </div>
                  <div className="flex items-center gap-1 mt-1 pl-5">
                    <span className="text-[11px] text-ink-2 flex-1">{c.meta}</span>
                    <button className="ring-focus text-[11.5px] text-ink-2 hover:text-ink px-1" onClick={() => setView(view === c.id ? null : c.id)}>{view === c.id ? '收起' : '查看来源'}</button>
                    {g === 'in' || g === 'stale' ? <button className="ring-focus text-[11.5px] text-ink-2 hover:text-berry px-1" onClick={() => dispatch({ t: 'ctx', id: c.id, state: 'removed' })}>移除</button>
                      : <button className="ring-focus text-[11.5px] text-mint-ink hover:underline px-1" onClick={() => dispatch({ t: 'ctx', id: c.id, state: 'in' })}>加入</button>}
                  </div>
                  {view === c.id && <pre className="mt-2 rounded-md bg-canvas font-mono text-[11px] leading-[17px] px-2 py-1.5 overflow-x-auto scroll-quiet text-ink-2">{c.source.join('\n')}</pre>}
                </li>
              ))}
            </ul>
          </section>
        )
      })}
      <p className="text-[11px] text-ink-2">上下文变化会在下一次运行生效；运行中的步骤不受影响。</p>
    </div>
  )
}

export function Caps({ s, ws, grants, setGrant }: { s: Session; ws: Workspace; grants: string[]; setGrant: (p: string, on: boolean) => void }) {
  const sc = SCRIPTS[s.script]
  const tone = { ok: ['ok', '可用'], unset: ['warn', '未配置'], off: ['neutral', '不可用'] } as const
  return (
    <div className="flex flex-col gap-4">
      <section>
        <h4 className="text-[11px] text-ink-2 uppercase tracking-[.08em] mb-1.5">执行器能力 · 能做什么</h4>
        <ul className="flex flex-col divide-y divide-silver/60 rounded-lg border border-silver">
          {CAPS.map(c => {
            const readonlyBlock = ws.readOnly && c.id === 'write'
            const [t, l] = readonlyBlock ? tone.off : tone[c.state]
            return (
              <li key={c.id} className="px-2.5 py-2 flex items-start gap-2">
                <div className="flex-1 min-w-0"><div className="text-[12.5px]">{c.label}</div><div className="text-[11px] text-ink-2">{readonlyBlock ? '此工作区为只读文件夹' : c.reason}</div></div>
                <Status tone={t}>{l}</Status>
              </li>
            )
          })}
        </ul>
      </section>
      <section>
        <h4 className="text-[11px] text-ink-2 uppercase tracking-[.08em] mb-1.5">已记住的授权 · {ws.name}</h4>
        {sc.perms.filter(p => grants.includes(p.id)).length === 0 ? (
          <p className="text-[12px] text-ink-2 rounded-lg border border-dashed border-silver px-3 py-3">没有。每次任务都会逐项询问。</p>
        ) : (
          <ul className="flex flex-col gap-1.5">
            {sc.perms.filter(p => grants.includes(p.id)).map(p => (
              <li key={p.id} className="rounded-lg border border-silver px-2.5 py-2 flex items-center gap-2">
                <Icon name={p.icon} size={13} className="text-control" />
                <span className="font-mono text-[11.5px] flex-1 truncate">{p.object}</span>
                <Button size="sm" variant="quiet" onClick={() => setGrant(p.id, false)}>撤销</Button>
              </li>
            ))}
          </ul>
        )}
        <p className="text-[11px] text-ink-2 mt-2">能力是执行器“能不能”，授权是你“允不允许”。撤销后下次运行会重新询问。</p>
      </section>
    </div>
  )
}

/** artifact preview — reports render as a table, documents as text; selection is part of the session layout */
export function Preview({ s, op }: { s: Session; op: (o: Op) => void }) {
  const sc = SCRIPTS[s.script]
  const ready = sc.kind === 'report' ? ['applied', 'verifying', 'verifyFailed', 'verified', 'delivered'].includes(s.phase) : Object.keys(s.hunks).length > 0
  if (!ready) return <p className="m-4 text-[12.5px] text-ink-2">此任务还没有产物。中间产物会在执行卡片里标出。</p>
  const a = sc.artifacts.find(x => x.id === s.layout.preview) ?? sc.artifacts[0]
  const status = s.phase === 'delivered' ? '已交付' : sc.kind === 'report' ? '草稿 · 待验收' : '草稿'
  return (
    <div className="flex-1 min-h-0 flex flex-col">
      <div role="tablist" aria-label="产物" className="shrink-0 flex items-center gap-1 px-2 py-1.5 border-b border-silver/60 overflow-x-auto scroll-quiet">
        {sc.artifacts.map(x => (
          <button key={x.id} role="tab" aria-selected={x.id === a.id} onClick={() => op({ op: 'preview', id: x.id })}
            className={`ring-focus shrink-0 h-7 px-2 rounded-md inline-flex items-center gap-1.5 text-[12px] ${x.id === a.id ? 'bg-muted text-ink' : 'text-ink-2 hover:text-ink'}`}>
            <Icon name="file" size={12} />{x.name}
          </button>
        ))}
      </div>
      <div className="flex-1 min-h-0 overflow-auto scroll-quiet">
        <div className="px-4 py-3 flex items-baseline gap-2 flex-wrap">
          <h3 className="text-[14px] font-medium">{a.name}</h3>
          <span className="text-[11.5px] text-ink-2">{a.type} · {a.size} · v{s.version} · {status}</span>
        </div>
        {a.table ? (
          <div className="px-4 pb-4">
            <table className="w-full text-[12.5px] border-separate border-spacing-0">
              <thead><tr>{a.table.cols.map((c, i) => <th key={c} scope="col" className={`sticky top-0 bg-canvas font-medium text-ink-2 text-[11.5px] px-2.5 py-1.5 border-y border-silver ${i ? 'text-right' : 'text-left'}`}>{c}</th>)}</tr></thead>
              <tbody>{a.table.rows.map(r => <tr key={r[0]} className="hover:bg-canvas/70">{r.map((c, i) => <td key={i} className={`px-2.5 py-1.5 border-b border-silver/60 ${i ? 'text-right font-mono text-[12px] tabular-nums' : ''} ${i === 3 ? 'text-ink' : i ? 'text-ink-2' : ''}`}>{c}</td>)}</tr>)}</tbody>
              {a.table.foot && <tfoot><tr>{a.table.foot.map((c, i) => <td key={i} className={`px-2.5 py-2 font-medium ${i ? 'text-right font-mono text-[12px] tabular-nums' : ''}`}>{c}</td>)}</tr></tfoot>}
            </table>
            <p className="mt-2 text-[11px] text-ink-2">另有「差异明细」「未匹配」两页（原型仅展示汇总页）。</p>
          </div>
        ) : (
          <pre className="mx-4 mb-4 rounded-lg bg-canvas font-mono text-[12px] leading-[19px] px-3 py-2.5 overflow-x-auto scroll-quiet whitespace-pre-wrap">{a.preview.join('\n')}</pre>
        )}
      </div>
    </div>
  )
}

/** execution log — every step of the latest run plus the session's record of rounds */
export function Log({ s }: { s: Session }) {
  const sc = SCRIPTS[s.script]
  const runs = s.blocks.filter(b => b.kind === 'run').length
  if (!runs) return <p className="m-4 text-[12.5px] text-ink-2">还没有运行过。</p>
  const live = !['empty'].includes(s.phase)
  const reached = live ? Math.min(s.step, sc.steps.length) : sc.steps.length
  return (
    <div className="flex-1 min-h-0 overflow-auto scroll-quiet bg-ink text-[#e6e4de] font-mono text-[11.5px] leading-[18px] p-3" role="log" aria-label="执行日志">
      <div className="text-[#a9b0ad] mb-2">第 {runs} 次运行 · {sc.steps.length} 步 · 模拟执行器</div>
      {sc.steps.slice(0, Math.max(reached + (s.phase === 'running' || s.phase === 'failed' ? 1 : 0), 0)).map((st, i) => {
        const fail = s.phase === 'failed' && i === s.failedStep
        const now = s.phase === 'running' && i === s.step
        return (
          <div key={i} className="mb-2">
            <div className={fail ? 'text-[#f0a7a0]' : now ? 'text-paper' : 'text-[#c9e3cf]'}>{fail ? '✕' : now ? '›' : '✓'} {String(i + 1).padStart(2, '0')} {st.label}</div>
            {(fail ? sc.failLog : now ? [] : st.log).map((l, k) => <div key={k} className="pl-5 text-[#b9beba] whitespace-pre-wrap break-words">{l}</div>)}
          </div>
        )
      })}
      {s.rounds.length > 0 && <div className="mt-3 pt-2 border-t border-paper/10 text-[#a9b0ad]">{s.rounds.map((r, i) => <div key={i}>{new Date(r.at).toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' })}  {r.label}</div>)}</div>}
    </div>
  )
}
