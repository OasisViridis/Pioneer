import { Button, THEMES } from './ui'

const SECTIONS = [
  ['四种对象，各自独立', '窗口、标签、会话、任务互不绑定。红灯只关窗口（托盘继续），退出才停任务；关闭标签只是放回工作区。全屏与最大化分开：绿灯 = 全屏，双击标题栏 = 最大化；全屏时黄灯禁用；点击桌面时窗口变为非活动，三灯变灰。'],
  ['没有确认，就不算完成', '状态链：发送 → 运行（需要写入或执行时就地询问）→ 审阅 → 已应用（模拟）→ 验收 → 交付。每一步都要显式事件推进；“审阅通过”“已应用”“验收通过”“已交付”是四个不同的格子。发送栏左侧的权限菜单：只读 / 写入前询问 / 自动。'],
  ['授权：逐项、无默认', '每项写明对象 / 动作 / 范围。仅此次 / 记住（此工作区）/ 拒绝，全部决定前提交按钮不可用。“记住”的授权在面板 › 能力中可撤销；能力（执行器能不能）与授权（你允不允许）分开展示。'],
  ['不确定就停下来问', '断连 → 结果未知 → 重新连接后先核对 → 由你选择“继续 / 重做 / 停止”，从不自动重放。停止需二次确认（按钮或连按两次 Esc），然后等待执行器确认。失败给出原因、原样重试、让 Agent 修复、我来接手四条路。'],
  ['可组合面板工作台', '模块（对话、上下文、改动、产物预览、验收与交付、执行日志、能力）是内容；面板是模块在标签组里的一个实例；布局是分栏树。对话是默认主干但同样可移动、合并、关闭。标签可拖到另一组的中间合并、四边拆分；拖动的每一步都有替代：标签 ⋯ 菜单 / 右键 / Shift+F10、「面板」菜单（Alt+\\）、分隔条方向键。关闭面板不删会话、不停任务，可在「最近关闭」恢复。新结果只更新对话里的结果卡片与状态，从不自动开面板、切页签、重排或滚走。窄窗一次显示一个面板，布局树保留。'],
  ['会话即标签，布局随会话', '标签可新建、双击重命名、拖动或 Alt+Shift+←/→ 排序、关闭与恢复，溢出时有列表菜单。每个会话自带布局树、草稿与内容，切换标签互不影响。'],
  ['Hazel 只在留白处', '装饰槽按会话 / 页面 ID 固定主题（12 套），与任务状态无关；工作区封面只展示内容类型。一屏最多一张，桌宠出现时欢迎插画让位。'],
  ['演示模式', '默认产品视图没有测试浮层：窗口铺满，没有模拟桌面与任务栏。设置 › 连接、命令面板或 Alt+Shift+D 开启后，才出现模拟 Windows 桌面、任务栏、窗口关闭 / 恢复与异常注入；演示控制从任务栏左侧打开，不遮挡交通灯。'],
  ['dsh-manqu-pet 宿主适配', '整区宿主层 pointer-events:none，只有桌宠本体可点击。指针移到桌宠上时，若下方是真实控件（按钮、标签、分隔条、输入）或正在拖放面板，桌宠立即淡出并让点击穿透；它压在控件上时保持半透明。单击互动、双击收起、右键 / 回车菜单、拖动并记住位置；输入时淡出，待决定时收到边缘。仍是适配原型而非真实插件。'],
  ['可恢复的本地数据', '只读写 pioneer-proto-* 键。数据损坏时原样备份并提示；保存失败显示“未保存”并可重试，退出时会提醒。重置需二次确认，并列出将删除的键。'],
  ['适合回贴 Figma 的画面', '① 工作区首页（含搜索空结果、首次使用、不可用工作区）② 发送栏权限菜单 ③ 就地授权卡④ 运行中 + 补充说明排队 ⑤ 断连 → 核对 → 选择 ⑥ 失败四出路 ⑦ 审阅：部分接受 + 退回理由 ⑧ v2 再审阅 ⑨ 交付：已应用未验收 / 验收失败 / 待人工确认 / 已交付 ⑩ 退出确认（任务 + 未保存）⑪ 面板拆分 / 合并 / 拖放提示 ⑫ 报表任务：预览 + 证据 ⑬ 窄窗单面板 ⑭ 演示模式（桌面、任务栏、控制）。'],
  ['限制', 'React 交互原型，不是原生 Figma 组件；v2/v3 原稿未改动。执行器、文件夹、Git、模型均为模拟，界面以“原型 · 模拟”标注。浏览器中快捷键用 Alt，原生应用改回 Ctrl。'],
]

export default function Notes({ close }: { close: () => void }) {
  return (
    <div className="absolute inset-0 z-40 flex justify-end bg-ink/15" onMouseDown={e => e.target === e.currentTarget && close()}>
      <aside role="dialog" aria-label="设计说明" className="anim-rise w-full max-w-[520px] h-full bg-paper border-l border-silver overflow-auto scroll-quiet">
        <div className="sticky top-0 bg-paper/95 backdrop-blur px-7 pt-7 pb-4 border-b border-silver/60 flex items-start gap-4">
          <div className="flex-1">
            <div className="text-[12px] text-ink-2 mb-1">Pioneer v5 候选 · 设计说明</div>
            <h2 className="font-serif text-[24px] leading-8 font-medium">安静的工作台，连续的会话</h2>
          </div>
          <Button size="sm" variant="quiet" icon="x" onClick={close} aria-label="关闭说明" />
        </div>
        <div className="px-7 py-6 flex flex-col gap-6">
          {SECTIONS.map(([h, b], i) => (
            <section key={h} className="grid grid-cols-[28px_1fr] gap-x-2">
              <span className="font-mono text-[11px] text-control pt-[3px]">{String(i + 1).padStart(2, '0')}</span>
              <div><h3 className="text-[14px] font-medium mb-1">{h}</h3><p className="text-[14px] leading-[22px] text-ink-2">{b}</p></div>
            </section>
          ))}
          <section>
            <h3 className="text-[12px] text-ink-2 mb-3">装饰槽素材（按会话 ID 轮换，每屏一张）</h3>
            <div className="grid grid-cols-6 gap-3">
              {THEMES.map(t => (
                <figure key={t.key} className="flex flex-col items-center gap-1">
                  <div className="size-14 rounded-lg bg-canvas grid place-items-center"><img src={t.src} alt="" className="size-10 object-contain" /></div>
                  <figcaption className="text-[10.5px] text-ink-2 text-center leading-tight">{t.label}</figcaption>
                </figure>
              ))}
            </div>
          </section>
          <section className="grid grid-cols-6 gap-2">
            {[['canvas', '#f6f5f1'], ['paper', '#fdfcfa'], ['ink', '#2c3547'], ['navy', '#333c50'], ['silver', '#d9d7d2'], ['mint', '#dce9df'], ['gold', '#c6af94'], ['berry', '#944b59'], ['rose', '#ebdada'], ['muted', '#eeedea'], ['control', '#858d92'], ['mint-ink', '#2f5e45']].map(([n, c]) => (
              <div key={n}><div className="h-8 rounded-md border border-black/5" style={{ background: c }} /><div className="text-[10px] font-mono text-ink-2 mt-1">{n}</div></div>
            ))}
          </section>
        </div>
      </aside>
    </div>
  )
}
