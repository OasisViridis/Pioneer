import { useEffect, useRef, useState } from 'react'
import { Icon } from './ui'

export type PetState = 'off' | 'out' | 'tucked'
export type PetPrefs = { state: PetState; pos: { r: number; b: number }; remember: boolean; bubbles: boolean }

const HOME = { r: 28, b: 96 }
/** anything the user can operate: if it sits under the pet, the pet lets clicks through */
const LIVE = 'button, a[href], input, textarea, select, label, summary, [role="tab"], [role="separator"], [role="menuitem"], [role="menuitemcheckbox"], [data-group] [data-tabs], [contenteditable="true"], [data-zone]'
const under = (pet: HTMLElement, x: number, y: number) => document.elementsFromPoint(x, y).find(e => !pet.contains(e)) as HTMLElement | undefined
const LINES = ['我在这儿，不打扰你。', '想换个位置？拖我就好。', '双击我可以先收到边上。', '累了的话，记得喝口水。']

/**
 * dsh-manqu-pet adaptation · host layer (prototype, not the real plugin).
 * Host: a full-area layer with pointer-events:none — only the pet itself takes clicks.
 * Behaviour: drag / click talks / double-click tucks / menu. The host decides *when* the pet must yield;
 * the pet never conveys task status.
 */
export default function PetHost({ prefs, setPrefs, typing, reason, hidden }: { prefs: PetPrefs; setPrefs: (p: Partial<PetPrefs>) => void; typing: boolean; reason?: string; hidden: boolean }) {
  const [pos, setPos] = useState(prefs.remember ? prefs.pos : HOME)
  const [squish, setSquish] = useState(0)
  const [line, setLine] = useState<string | null>(null)
  const [menu, setMenu] = useState(false)
  const [summoned, setSummoned] = useState<string | undefined>()
  const moved = useRef(false)
  const clickT = useRef<number | undefined>(undefined)
  const host = useRef<HTMLDivElement>(null)
  const petEl = useRef<HTMLDivElement>(null)
  // the pet is a normal, clickable thing on empty ground. When it ends up on controls (a dropped panel, a resize,
  // the user's own drop) or the pointer heads for a control it covers, it hops to the nearest empty spot.
  const [hop, setHop] = useState(false)
  const [dragging, setDragging] = useState(false)
  const posRef = useRef(pos)
  posRef.current = pos
  const busy = useRef(false)
  useEffect(() => {
    const blocked = (el: HTMLElement, x: number, y: number) => !!under(el, x, y)?.closest(LIVE)
    const covers = (el: HTMLElement, l: number, t: number, w: number, h: number) =>
      [-0.06, 0.3, 0.7, 1.06].some(fx => [-0.06, 0.3, 0.7, 1.06].some(fy => blocked(el, l + w * fx, t + h * fy)))
    const relocate = () => {
      const el = petEl.current, hs = host.current
      if (!el || !hs || busy.current) return
      const H = hs.getBoundingClientRect(), R = el.getBoundingClientRect()
      const p = posRef.current
      const cand: { r: number; b: number; d: number }[] = []
      for (let r = 4; r <= H.width - R.width - 4; r += 28) for (let b = 4; b <= H.height - R.height - 4; b += 28) cand.push({ r, b, d: Math.hypot(r - p.r, b - p.b) })
      cand.sort((x, y) => x.d - y.d)
      const spot = cand.find(c => !covers(el, H.right - c.r - R.width, H.bottom - c.b - R.height, R.width, R.height))
      if (!spot) return
      setHop(true); setPos({ r: spot.r, b: spot.b }); setTimeout(() => setHop(false), 420)
    }
    const check = () => {
      const el = petEl.current
      if (!el || busy.current || document.body.dataset.paneldrag) return
      const r = el.getBoundingClientRect()
      if (covers(el, r.left, r.top, r.width, r.height)) relocate()
    }
    const mv = (e: PointerEvent) => {
      const el = petEl.current
      if (!el || busy.current) return
      // panel drags see straight through the pet
      el.style.pointerEvents = document.body.dataset.paneldrag ? 'none' : 'auto'
      const r = el.getBoundingClientRect()
      const near = e.clientX > r.left - 36 && e.clientX < r.right + 36 && e.clientY > r.top - 36 && e.clientY < r.bottom + 36
      if (near && !document.body.dataset.paneldrag && covers(el, r.left, r.top, r.width, r.height)) relocate()
    }
    window.addEventListener('pointermove', mv, { capture: true, passive: true })
    const t = window.setInterval(check, 900)
    return () => { window.removeEventListener('pointermove', mv, { capture: true }); window.clearInterval(t) }
  }, [])
  useEffect(() => { if (reason !== summoned) setSummoned(undefined) }, [reason])
  useEffect(() => { if (!line) return; const t = setTimeout(() => setLine(null), 2600); return () => clearTimeout(t) }, [line])
  useEffect(() => { if (!prefs.remember) setPos(HOME) }, [prefs.remember])

  if (prefs.state === 'off' || hidden) return null
  const yieldTo = !!reason && reason !== summoned
  const state = prefs.state

  const down = (e: React.PointerEvent) => {
    if (e.button !== 0) return
    const h = host.current!.getBoundingClientRect()
    const el = (e.currentTarget as HTMLElement).getBoundingClientRect()
    const dx = e.clientX - el.right, dy = e.clientY - el.bottom
    const sx = e.clientX, sy = e.clientY
    moved.current = false
    busy.current = true
    setDragging(true)
    let last = pos
    const mv = (ev: PointerEvent) => {
      if (Math.abs(ev.clientX - sx) + Math.abs(ev.clientY - sy) > 4) moved.current = true
      if (!moved.current) return
      last = { r: Math.min(h.width - 110, Math.max(4, h.right - ev.clientX + dx)), b: Math.min(h.height - 120, Math.max(4, h.bottom - ev.clientY + dy)) }
      setPos(last)
    }
    const up = () => {
      window.removeEventListener('pointermove', mv); window.removeEventListener('pointerup', up)
      busy.current = false; setDragging(false)
      if (moved.current) { setSquish(k => k + 1); if (prefs.remember) setPrefs({ pos: last }) }
    }
    window.addEventListener('pointermove', mv); window.addEventListener('pointerup', up)
  }
  const click = () => {
    if (moved.current) return
    window.clearTimeout(clickT.current)
    // wait to tell a single click from a double click
    clickT.current = window.setTimeout(() => { setSquish(k => k + 1); if (prefs.bubbles) setLine(LINES[(squish + 1) % LINES.length]); setMenu(false) }, 220)
  }
  const dbl = () => { window.clearTimeout(clickT.current); setPrefs({ state: 'tucked' }) }

  return (
    <div ref={host} data-pet-host className="absolute inset-0 z-30 pointer-events-none overflow-hidden" aria-label="桌宠图层（原型）">
      {state === 'tucked' || yieldTo ? (
        <button onClick={() => (state === 'tucked' ? setPrefs({ state: 'out' }) : setSummoned(reason))}
          title={yieldTo && state !== 'tucked' ? `${reason}，灰泽满先让开。点我叫回` : '叫回灰泽满'} aria-label="叫回桌宠"
          className="ring-focus pointer-events-auto absolute right-0 bottom-28 h-14 w-5 rounded-l-lg bg-mint border border-r-0 border-mint-2 grid place-items-center text-mint-ink hover:w-7 transition-all">
          <Icon name="chevron" size={12} className="rotate-180" />
        </button>
      ) : (
        <div ref={petEl} data-pet className={`absolute ${hop ? 'transition-[right,bottom,opacity] duration-400 ease-[cubic-bezier(.3,1.4,.5,1)]' : 'transition-opacity duration-200'}`}
          style={{ right: pos.r, bottom: pos.b, opacity: typing ? 0.25 : 1, pointerEvents: typing ? 'none' : 'auto' }}>
          {line && <div className="anim-rise absolute bottom-full right-2 mb-1 whitespace-nowrap rounded-xl rounded-br-sm bg-paper border border-silver px-3 py-1.5 text-[12.5px] shadow-sm">{line}</div>}
          {menu && (
            <div className="anim-rise absolute bottom-full right-0 mb-2 w-52 rounded-xl bg-paper border border-silver shadow-lg p-1 text-[12.5px]" role="menu" onKeyDown={e => e.key === 'Escape' && setMenu(false)}>
              <div className="px-2.5 pt-1.5 pb-1 text-[10.5px] font-mono text-ink-2">dsh-manqu-pet · 适配原型</div>
              <button autoFocus role="menuitem" onClick={() => { setPrefs({ state: 'tucked' }); setMenu(false) }} className="ring-focus w-full text-left px-2.5 py-1.5 rounded-md hover:bg-muted">收到边上 <span className="text-ink-2">· 双击</span></button>
              <button role="menuitem" onClick={() => { setPos(HOME); setPrefs({ pos: HOME }); setMenu(false) }} className="ring-focus w-full text-left px-2.5 py-1.5 rounded-md hover:bg-muted">回到角落</button>
              <button role="menuitem" onClick={() => { setPrefs({ state: 'off' }); setMenu(false) }} className="ring-focus w-full text-left px-2.5 py-1.5 rounded-md hover:bg-muted">关闭桌宠 <span className="text-ink-2">· 设置中可重开</span></button>
            </div>
          )}
          <button
            onPointerDown={down} onClick={click} onDoubleClick={dbl}
            onContextMenu={e => { e.preventDefault(); setMenu(m => !m) }}
            onKeyDown={e => { if (e.key === 'Enter' || e.key === ' ' || e.key === 'ContextMenu') { e.preventDefault(); setMenu(m => !m) } }}
            className="ring-focus block rounded-2xl cursor-grab active:cursor-grabbing select-none touch-none"
            aria-label="桌宠灰泽满：拖动移动，单击互动，双击收起，右键或回车打开菜单" aria-haspopup="menu"
          >
            <img key={squish} src="/assets/ref/hazel-jelly.png" alt="" draggable={false} className={`w-[100px] h-auto transition-transform duration-150 ${dragging && moved.current ? 'scale-[1.06] -rotate-3 drop-shadow-[0_12px_16px_rgba(44,53,71,.24)]' : 'drop-shadow-[0_6px_10px_rgba(44,53,71,.18)]'} ${squish ? 'anim-squish' : 'anim-bob'}`} style={{ transformOrigin: '50% 100%' }} />
          </button>
        </div>
      )}
    </div>
  )
}
